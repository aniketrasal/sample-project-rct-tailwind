"""Calibration Certificate Verifier - checks a certificate against IN REL 002 (20 rules).

Vercel entry point: `app` (Flask). Needs the environment variables SECRET_KEY, ADMIN_PASSWORD and a Postgres
DATABASE_URL (Vercel -> Storage -> Neon). Missing settings show a "Setup needed" page instead of crashing.
"""
import io
import json
import os
import secrets
import time
import traceback
import uuid
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import (Flask, Response, abort, flash, g, jsonify, redirect, render_template, request, session, url_for)
from werkzeug.exceptions import HTTPException
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash

import db
import extract
import hashlib
import hmac
import mailer
import re
import report
import rules

MAX_UPLOAD = int(4.5 * 1024 * 1024)          # Vercel rejects request bodies above ~4.5 MB
APP_TZ = os.environ.get("APP_TZ", "Asia/Kolkata")


def now():
    """Current local time (naive). Vercel servers run in UTC, so use the configured time zone."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo(APP_TZ)).replace(tzinfo=None)
    except Exception:
        off = timedelta(hours=5, minutes=30) if APP_TZ == "Asia/Kolkata" else timedelta(0)
        return (datetime.now(timezone.utc) + off).replace(tzinfo=None)


def today():
    return now().date()


def _flag(name, default="0"):
    return os.environ.get(name, default).strip().lower() in ("1", "true", "yes", "on")


# ---- the editable form (key, label, kind, help) ---------------------------------------
OPTIONAL = {"ulr", "instr_model", "instr_qty", "calibrator_name", "calibrator_function", "results_internal",
            "results_depth", "wi_ok", "competency_ok", "reference_std", "challan", "wo_no", "results_unit_text",
            "nabl_symbol", "end_marker", "approver_signature", "calibration_kind", "instr_class", "instr_grade",
            "dim_L", "dim_h1", "results_external", "results_params", "acc_ranges", "acc_empe", "acc_smpe",
            "acc_formulas", "instr_lc", "pages_found", "page_total", "nabl_from_ulr", "instr_lc_applicable",
            "lab_name", "lab_address", "lab_location"}
GROUPS = [
    ("Calibration source", "rules 1, 2", [
        ("calibration_kind", "Calibrated by", "select:nabl=NABL accredited lab,internal=Internal (no NABL)", ""),
        ("nabl_no", "NABL lab number", "text", "e.g. CC-2656"),
        ("nabl_symbol", "NABL symbol is on the certificate", "check", "Tick if the NABL logo is printed"),
        ("wi_ok", "Internal: calibration work instruction exists", "check", "Only for internal calibration (ISO/IEC 17025)"),
        ("competency_ok", "Internal: calibration personnel are competent", "check", "Only for internal calibration (ISO/IEC 17025)"),
    ]),
    ("Certificate and lab", "rules 3a, 3b, 3c", [
        ("title", "Title", "text", ""), ("lab_name", "Lab name", "text", ""),
        ("lab_address", "Lab address", "text", ""), ("lab_location", "Calibration location", "text", "In Lab / Site"),
        ("cert_no", "Certificate no.", "text", ""), ("ulr", "ULR", "text", "optional"),
        ("page_text", "Page numbering", "text", "e.g. 1 of 1"),
        ("end_marker", "End of certificate is clearly marked", "check", "e.g. '*** End of certificate ***'"),
    ]),
    ("Customer and method", "rules 3d, 3e", [
        ("customer_name", "Calibrated for", "text", ""), ("customer_address", "Customer address", "text", ""),
        ("method_no", "Calibration procedure no.", "text", ""), ("reference_std", "Reference standard", "text", ""),
    ]),
    ("Instrument", "rules 3f, 4, 6", [
        ("instr_type", "Type of instrument", "text", ""),
        ("instr_class", "Instrument class (for rule 6)", "select:dimensional=Dimensional (Vernier, Micrometer),"
                                                       "gdt=GD&T (Surface plate, V block),electrical=Electrical,"
                                                       "thermal=Thermal", ""),
        ("instr_ident", "Identification", "text", ""), ("instr_make", "Make", "text", ""),
        ("instr_model", "Model no.", "text", "optional"), ("instr_serial", "Mfr. serial no.", "text", ""),
        ("instr_range", "Range", "text", "e.g. 0 To 200 mm"), ("instr_lc", "Least count", "text", "e.g. 0.01 mm"),
        ("instr_qty", "Quantity", "text", "optional"),
        ("instr_grade", "Grade (V-block, surface plate...)", "text", "e.g. 0, 1 or 2 - needed when the certificate lists limits per grade"),
        ("dim_L", "Length L (mm)", "decimal", "for limits like 3 + (L/250); from the size 100X90X75, L = 100"),
        ("dim_h1", "Height h1 (mm)", "decimal", "for limits like 2 + (h1/100); from 100X90X75, h1 = 75"),
    ]),
    ("Dates", "rule 3g", [
        ("challan", "Challan no.", "text", ""), ("wo_no", "W.O. no.", "text", ""),
        ("receipt_date", "Receipt date", "date", "dd/mm/yyyy"), ("cal_date", "Calibration date", "date", "dd/mm/yyyy"),
        ("due_date", "Due date", "date", "dd/mm/yyyy"), ("issue_date", "Issue date", "date", "dd/mm/yyyy"),
    ]),
    ("Results and acceptance limits", "rules 3h, 4, extra check", [
        ("results_external", "External measurement", "area", "One line per point: measured, observed, error (um)"),
        ("results_internal", "Internal measurement", "area", "One line per point: measured, observed, error (um)"),
        ("results_depth", "Depth measurement", "area", "One line per point: measured, observed, error (um)"),
        ("results_params", "Measured parameters (V-block etc.)", "area", "One line per parameter: name | value (um)"),
        ("acc_formulas", "Grade limits (formulas)", "area", "First line: Grade | Parallelism | Squareness. Then: 2 | 12+(L/50) | 10+(h1/25)"),
        ("results_unit_text", "Units line", "text", "e.g. Observed Reading in mm & Error in um"),
        ("acc_ranges", "Acceptance ranges (mm)", "text", "e.g. 0-50, 50-200, 200-400, 400-600"),
        ("acc_empe", "EMPE (um)", "text", "e.g. 20, 30, 40, 50 - used for external measurement"),
        ("acc_smpe", "SMPE (um)", "text", "e.g. 30, 50, 60, 70 - used for internal and depth"),
    ]),
    ("Authorisation, environment, uncertainty", "rules 3i to 3m, 6", [
        ("approver_name", "Approved by - name", "text", ""), ("approver_function", "Approved by - function", "text", ""),
        ("approver_signature", "Approver's signature is present", "check", "Auto-detected, tick if the certificate is signed"),
        ("calibrator_name", "Calibrated by - name", "text", "optional"),
        ("calibrator_function", "Calibrated by - function", "text", "optional"),
        ("statement_text", "'Results relate only to items calibrated' statement", "text", ""),
        ("env_temp", "Temperature (C)", "decimal", ""), ("env_humidity", "Humidity (%RH)", "decimal", ""),
        ("unc_value", "Uncertainty +/-", "decimal", ""), ("unc_unit", "Uncertainty unit", "text", "um or mm"),
        ("unc_conf", "Confidence level (%)", "decimal", "95.45 or 95"), ("k_factor", "Coverage factor k", "decimal", ""),
    ]),
    ("Standards / masters used", "rules 3n, 3o", [
        ("standards", "One per line: description | ID | certificate no. | traceability | valid up to", "area", ""),
    ]),
]
ALL_FIELDS = [(k, kind) for _, _, fs in GROUPS for k, _, kind, _ in fs]


# ---- configuration check ----------------------------------------------------------------
class SetupNeeded(Exception):
    pass


def config_problems():
    out = []
    if db.ON_VERCEL and not os.environ.get("SECRET_KEY", "").strip():
        out.append(dict(key="SECRET_KEY", what="A long random text that protects sign-in cookies.",
                        how='Vercel -> Project -> Settings -> Environment Variables -> add SECRET_KEY. '
                            'Generate one with: python3 -c "import secrets;print(secrets.token_hex(32))"'))
    if db.backend() == "":
        out.append(dict(key="DATABASE_URL", what="The Postgres database where labs, results and certificates are saved.",
                        how="Vercel -> Project -> Storage -> Create Database -> Neon (free). "
                            "It adds DATABASE_URL automatically. Then Deployments -> Redeploy."))
    return out


def create_app():
    app = Flask(__name__)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    app.secret_key = os.environ.get("SECRET_KEY", "").strip() or secrets.token_hex(32)   # real one is required online
    app.config.update(
        MAX_CONTENT_LENGTH=MAX_UPLOAD,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=_flag("CERTV_SECURE_COOKIES", "1"),
        PERMANENT_SESSION_LIFETIME=timedelta(hours=int(os.environ.get("SESSION_HOURS", "12"))),
        TEMPLATES_AUTO_RELOAD=False,
    )
    state = {"ready": False}

    # ------------------------------------------------------------ plumbing
    def con():
        if "db" not in g:
            g.db = db.connect()
        return g.db

    @app.teardown_appcontext
    def close(_):
        c = g.pop("db", None)
        if c:
            c.close()

    @app.template_filter("dmy")
    def dmy(s):
        d = rules.pdate(s)
        return d.strftime("%d/%m/%Y") if d else (s or "")

    @app.template_filter("dt")
    def dt(s):
        return (s or "")[:16].replace("T", " ")

    def csrf():
        if "csrf" not in session:
            session["csrf"] = secrets.token_hex(16)
        return session["csrf"]

    @app.context_processor
    def inject():
        return dict(csrf_token=csrf, today=today(), valid_date=lambda x: rules.pdate(x) is not None)

    def wants_json():
        return request.headers.get("X-Requested-With") == "fetch"

    @app.after_request
    def headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        resp.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval' blob: https://cdn.jsdelivr.net; "
            "worker-src 'self' blob: https://cdn.jsdelivr.net; "
            "connect-src 'self' blob: data: https://cdn.jsdelivr.net https://tessdata.projectnaptha.com; "
            "frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        if request.is_secure:
            resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
        if "uid" in session:
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def ensure_ready():
        if state["ready"]:
            return
        db.init_db(generate_password_hash("admin"), reset_admin=_flag("RESET_ADMIN_PASSWORD"))
        state["ready"] = True

    @app.route("/healthz")
    def healthz():
        problems = config_problems()
        info = {"status": "ok", "database": db.backend() or "not configured", "problems": [p["key"] for p in problems],
                "email": "configured" if mailer.configured() else "NOT configured (add SMTP_HOST, SMTP_USER, SMTP_PASSWORD)"}
        if problems:
            info["status"] = "setup needed"
            return info, 503
        try:
            ensure_ready()
            con().execute("SELECT 1").fetchone()
        except SetupNeeded:
            info.update(status="setup needed", problems=["ADMIN_PASSWORD"])
            return info, 503
        except db.DBUnavailable as e:
            info.update(status="database unreachable", error=str(e))
            return info, 503
        return info

    @app.route("/favicon.ico")
    def favicon():
        return Response(status=204)

    @app.before_request
    def guard():
        if request.endpoint in ("healthz", "favicon"):
            return
        problems = config_problems()
        if problems:
            return render_template("setup.html", problems=problems), 503
        ensure_ready()
        if request.endpoint in PUBLIC:
            if request.method == "POST" and not secrets.compare_digest(
                    request.form.get("_csrf", ""), session.get("csrf", "")):
                abort(400, "Your page was open for too long. Go back, reload and try again.")
            return
        if "uid" not in session:
            if wants_json():
                return jsonify(ok=False, error="Your session expired - please sign in again."), 401
            return redirect(url_for("login", next=request.full_path.rstrip("?")))
        if request.method == "POST" and not secrets.compare_digest(
                request.form.get("_csrf", "") or request.headers.get("X-CSRF-Token", ""), session.get("csrf", "")):
            abort(400, "Your page was open for too long. Go back, reload and try again.")
        g.user = con().execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()
        if not g.user:
            session.clear()
            return redirect(url_for("login"))
        if g.user["must_setup"] and request.endpoint not in ("setup", "setup_verify", "logout"):
            return redirect(url_for("setup"))

    # ---- friendly errors (never a bare "500 FUNCTION_INVOCATION_FAILED")
    @app.errorhandler(SetupNeeded)
    def _setup(e):
        return render_template("setup.html", problems=[dict(
            key="ADMIN_PASSWORD", what="The password for the first user (admin). Used only on the very first start.",
            how="Vercel -> Project -> Settings -> Environment Variables -> add ADMIN_PASSWORD, then Redeploy.")]), 503

    @app.errorhandler(db.DBUnavailable)
    def _dbdown(e):
        app.logger.error("Database unavailable: %s", e)
        return render_template("error.html", code=503, title="Database not reachable",
                               text="The app could not connect to its database. Check DATABASE_URL in Vercel "
                                    "(Settings -> Environment Variables) and that the Neon database is active.",
                               detail=str(e)), 503

    @app.errorhandler(HTTPException)
    def _http(e):
        texts = {400: "The request could not be processed.", 403: "You do not have permission for this.",
                 404: "That page does not exist.", 413: "The file is too large. Use a photo or PDF under 4 MB.",
                 429: "Too many attempts. Wait a bit and try again."}
        if wants_json():
            return jsonify(ok=False, error=e.description if e.code == 400 else texts.get(e.code, e.name)), e.code
        return render_template("error.html", code=e.code, title=e.name, text=texts.get(e.code, e.description),
                               detail=e.description if e.code == 400 else ""), e.code

    @app.errorhandler(Exception)
    def _boom(e):
        ref = uuid.uuid4().hex[:8]
        app.logger.error("Unhandled error %s: %s", ref, traceback.format_exc())
        if wants_json():
            return jsonify(ok=False, error=f"Something went wrong (ref {ref}).", detail=f"{type(e).__name__}: {str(e)[:160]}"), 500
        return render_template("error.html", code=500, title="Something went wrong",
                               text=f"The error was saved in the server log. Reference: {ref}.",
                               detail=(f"{type(e).__name__}: {e}" if _flag("CERTV_DEBUG") else "")), 500

    def admin_only(f):
        @wraps(f)
        def w(*a, **k):
            if g.user["role"] != "admin":
                abort(403)
            return f(*a, **k)
        return w

    # ------------------------------------------------------------ rule context
    def make_ctx():
        c = con()
        labs = [dict(r) for r in c.execute("SELECT * FROM labs").fetchall()]
        scopes = {}
        for r in c.execute("SELECT * FROM lab_scope").fetchall():
            scopes.setdefault(r["lab_id"], []).append(dict(r))
        return rules.Ctx(labs=labs, scopes=scopes, today=today(),
                         instruments=[dict(r) for r in c.execute("SELECT * FROM instruments").fetchall()],
                         env_limits=[dict(r) for r in c.execute("SELECT * FROM env_limits").fetchall()])

    def get_v(vid):
        v = con().execute("SELECT * FROM verifications WHERE id=?", (vid,)).fetchone()
        if not v:
            abort(404)
        return v

    def run_checks(vid):
        """Run all rules, keep reviewer overrides, store results and the overall result."""
        c = con()
        v = get_v(vid)
        d = json.loads(v["data_json"] or "{}")
        final = v["status"] == "final"
        results = rules.evaluate(d, make_ctx(), verifier=dict(name=v["verifier_name"], remark=v["verifier_remark"]),
                                 finalizing=final)
        old = {r["code"]: r for r in c.execute("SELECT * FROM check_results WHERE verification_id=?", (vid,)).fetchall()}
        eff = []
        for r in results:
            o = old.get(r["code"])
            if o and o["overridden"]:
                status, pending, over = o["status"], 0, 1
            else:
                status, pending, over = r["status"], int(r["pending"]), 0
            c.upsert("check_results", ["verification_id", "code"], verification_id=vid, code=r["code"],
                     title=r["title"], auto_status=r["status"], status=status, reason=r["reason"],
                     pending=pending, overridden=over)
            eff.append(dict(status=status, pending=pending))
        result = rules.overall(eff)
        c.execute("UPDATE verifications SET result=? WHERE id=?", (result, vid))
        c.commit()
        return result

    def lab_label(d):
        lab = make_ctx().lab_by_nabl(d.get("nabl_no", "")) if d.get("nabl_no") else None
        return f"{lab['name'] if lab else d.get('lab_name', '')} ({d.get('nabl_no') or 'internal'})"

    # ------------------------------------------------------------ auth
    MAX_FAILS, WINDOW = 8, 15 * 60
    CODE_TTL, CODE_TRIES, CODE_COOLDOWN, CODES_PER_HOUR = 10 * 60, 5, 45, 6
    USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,29}$")
    EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")

    def _hash_code(purpose, email, code):
        return hmac.new(app.secret_key.encode() if isinstance(app.secret_key, str) else app.secret_key,
                        f"{purpose}|{email}|{code}".encode(), hashlib.sha256).hexdigest()

    def issue_code(purpose, email, user_id=None, payload=""):
        """Makes a 6-digit code (stored hashed). Returns (code, problem text)."""
        c, t = con(), time.time()
        last = c.execute("SELECT MAX(created) FROM email_codes WHERE purpose=? AND email=?", (purpose, email)).fetchone()[0]
        if last and t - last < CODE_COOLDOWN:
            return None, f"Please wait {int(CODE_COOLDOWN - (t - last)) + 1} seconds before asking for another code."
        n = c.execute("SELECT COUNT(*) FROM email_codes WHERE email=? AND created>?", (email, t - 3600)).fetchone()[0]
        if n >= CODES_PER_HOUR:
            return None, "Too many codes were requested for this e-mail. Try again in an hour."
        c.execute("DELETE FROM email_codes WHERE purpose=? AND email=?", (purpose, email))
        c.execute("DELETE FROM email_codes WHERE expires<?", (t,))
        code = f"{secrets.randbelow(1000000):06d}"
        c.insert("email_codes", purpose=purpose, user_id=user_id, email=email, code_hash=_hash_code(purpose, email, code),
                 payload=payload, created=t, expires=t + CODE_TTL, attempts=0)
        c.commit()
        return code, ""

    def check_code(purpose, email, code):
        """Returns (row or None, message)."""
        c = con()
        row = c.execute("SELECT * FROM email_codes WHERE purpose=? AND email=? ORDER BY id DESC", (purpose, email)).fetchone()
        if not row or row["expires"] < time.time():
            return None, "This code has expired. Ask for a new one."
        if row["attempts"] >= CODE_TRIES:
            c.execute("DELETE FROM email_codes WHERE id=?", (row["id"],)); c.commit()
            return None, "Too many wrong attempts. Ask for a new code."
        if not hmac.compare_digest(row["code_hash"], _hash_code(purpose, email, re.sub(r"\D", "", code or ""))):
            c.execute("UPDATE email_codes SET attempts=attempts+1 WHERE id=?", (row["id"],)); c.commit()
            left = CODE_TRIES - row["attempts"] - 1
            return None, f"That code is not correct ({left} tries left)." if left > 0 else "That code is not correct. Ask for a new code."
        return row, ""

    def consume(row):
        con().execute("DELETE FROM email_codes WHERE id=?", (row["id"],)); con().commit()

    def mail_code(to, code, what, minutes=10):
        return mailer.send(to, f"Your Cert Verifier code: {code}",
                           f"Your verification code is {code}\n\n{what}\nIt works for {minutes} minutes. "
                           "If you did not ask for this, ignore this e-mail - nothing changes.\n\nCert Verifier")

    def mail_problem(err):
        return ("The code could not be e-mailed. " + (err or "") +
                " Check the e-mail settings (see DEPLOY.md, step 'E-mail').")

    def check_password_rules(pw, pw2=None, username=""):
        if len(pw) < 8:
            return "The password needs at least 8 characters."
        if pw.lower() in ("admin", "password", "12345678", "admin123", username):
            return "Choose a password that is harder to guess."
        if pw2 is not None and pw != pw2:
            return "The two passwords are not the same."
        return ""

    PUBLIC = {"login", "forgot", "forgot_reset", "forgot_username"}

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            c = con()
            ip, un = request.remote_addr or "?", request.form.get("username", "").strip().lower()
            t = time.time()
            c.execute("DELETE FROM login_attempts WHERE ts < ?", (t - WINDOW,))
            fails = c.execute("SELECT COUNT(*) FROM login_attempts WHERE ip=? OR username=?", (ip, un)).fetchone()[0]
            if fails >= MAX_FAILS:
                c.commit()
                flash("Too many failed sign-ins. Wait 15 minutes and try again.", "error")
                return render_template("login.html", first_run=False), 429
            u = c.execute("SELECT * FROM users WHERE lower(username)=? OR (lower(email)=? AND email<>'')", (un, un)).fetchone()
            if u and check_password_hash(u["pw_hash"], request.form.get("password", "")):
                c.execute("DELETE FROM login_attempts WHERE ip=? OR username=?", (ip, un))
                c.commit()
                session.clear()
                session.permanent = True
                session["uid"] = u["id"]
                if u["must_setup"]:
                    return redirect(url_for("setup"))
                nxt = request.args.get("next", "")
                return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("home"))
            c.execute("INSERT INTO login_attempts(ip, username, ts) VALUES (?,?,?)", (ip, un, t))
            c.commit()
            flash("Wrong username or password.", "error")
        return render_template("login.html", first_run=bool(con().execute(
            "SELECT 1 FROM users WHERE username='admin' AND must_setup=1").fetchone()))


    # ---- first sign-in: choose your own username, password and a verified e-mail
    @app.route("/setup", methods=["GET", "POST"])
    def setup():
        if not g.user["must_setup"]:
            return redirect(url_for("home"))
        ok_mail = mailer.configured()
        form = {"username": "", "full_name": g.user["full_name"] if g.user["full_name"] != "Administrator" else "", "email": ""}
        if request.method == "POST":
            form = {k: request.form.get(k, "").strip() for k in ("username", "full_name", "email")}
            form["username"] = form["username"].lower()
            pw, pw2 = request.form.get("password", ""), request.form.get("password2", "")
            only = os.environ.get("ADMIN_EMAIL", "").strip().lower()
            c = con()
            err = ""
            if not USERNAME_RE.match(form["username"]):
                err = "Username: 3-30 letters, numbers, dot, dash or underscore."
            elif form["username"] == "admin":
                err = "Please choose a different username than 'admin'."
            elif c.execute("SELECT 1 FROM users WHERE lower(username)=? AND id<>?", (form["username"], g.user["id"])).fetchone():
                err = "That username is already taken."
            elif len(form["full_name"]) < 2:
                err = "Enter your name."
            elif not EMAIL_RE.match(form["email"]):
                err = "Enter a valid e-mail address."
            elif only and form["email"].lower() != only:
                err = "This installation only accepts the owner's e-mail address."
            else:
                err = check_password_rules(pw, pw2, form["username"])
            if not err and not ok_mail:
                err = "E-mail sending is not set up yet (see DEPLOY.md, step 'E-mail')."
            if not err:
                code, err = issue_code("setup", form["email"].lower(), g.user["id"], json.dumps(
                    {"username": form["username"], "full_name": form["full_name"], "pw_hash": generate_password_hash(pw),
                     "email": form["email"]}))
            if not err:
                sent, merr = mail_code(form["email"], code, "Use it to finish setting up your Cert Verifier account.")
                if not sent:
                    err = mail_problem(merr)
                    con().execute("DELETE FROM email_codes WHERE purpose='setup' AND email=?", (form["email"].lower(),)); con().commit()
            if err:
                flash(err, "error")
            else:
                session["setup_email"] = form["email"].lower()
                flash(f"We sent a 6-digit code to {form['email']}.", "ok")
                return redirect(url_for("setup_verify"))
        return render_template("setup_account.html", form=form, mail_ok=ok_mail)

    @app.route("/setup/verify", methods=["GET", "POST"])
    def setup_verify():
        email = session.get("setup_email", "")
        if not g.user["must_setup"] or not email:
            return redirect(url_for("setup"))
        if request.method == "POST":
            if request.form.get("resend"):
                row = con().execute("SELECT * FROM email_codes WHERE purpose='setup' AND email=? ORDER BY id DESC", (email,)).fetchone()
                if not row:
                    return redirect(url_for("setup"))
                p = json.loads(row["payload"])
                code, err = issue_code("setup", email, g.user["id"], row["payload"])
                if not err:
                    sent, merr = mail_code(p["email"], code, "Use it to finish setting up your Cert Verifier account.")
                    err = "" if sent else mail_problem(merr)
                flash(err or f"A new code was sent to {p['email']}.", "error" if err else "ok")
                return redirect(url_for("setup_verify"))
            row, err = check_code("setup", email, request.form.get("code", ""))
            if err:
                flash(err, "error")
            else:
                p = json.loads(row["payload"])
                c = con()
                if c.execute("SELECT 1 FROM users WHERE lower(username)=? AND id<>?", (p["username"], g.user["id"])).fetchone():
                    flash("That username was taken in the meantime. Please choose another.", "error")
                    return redirect(url_for("setup"))
                c.execute("UPDATE users SET username=?, full_name=?, pw_hash=?, email=?, email_verified=1, must_setup=0 WHERE id=?",
                          (p["username"], p["full_name"], p["pw_hash"], p["email"], g.user["id"]))
                consume(row)
                c.commit()
                session.pop("setup_email", None)
                mailer.send(p["email"], "Your Cert Verifier account is ready",
                            f"Hello {p['full_name']},\n\nYour account is ready. Your username is: {p['username']}\n"
                            "If you forget your username or password, use the 'Forgot' links on the sign-in page.\n\nCert Verifier")
                flash("Your account is ready. Welcome!", "ok")
                return redirect(url_for("home"))
        return render_template("setup_verify.html", email=email)

    # ---- forgot password / username
    @app.route("/forgot", methods=["GET", "POST"])
    def forgot():
        if request.method == "POST":
            who = request.form.get("who", "").strip().lower()
            session["reset_who"] = who
            u = con().execute("SELECT * FROM users WHERE (lower(username)=? OR lower(email)=?) AND email<>'' AND must_setup=0",
                              (who, who)).fetchone() if who else None
            if not u and who and con().execute("SELECT 1 FROM users WHERE lower(username)=? AND must_setup=1", (who,)).fetchone():
                flash("This account is not set up yet, so it has no e-mail. Sign in with admin / admin first and "
                      "finish the first-login set-up.", "error")
                return redirect(url_for("login"))
            if u and not mailer.configured():
                flash("E-mail sending is not set up (SMTP settings missing in Vercel).", "error")
                return redirect(url_for("forgot"))
            if u:
                code, err = issue_code("reset", u["email"].lower(), u["id"])
                if code:
                    sent, merr = mail_code(u["email"], code, f"Use it to choose a new password for the account '{u['username']}'.")
                    if not sent:
                        app.logger.error("reset mail failed: %s", merr)
                        flash(mail_problem(merr), "error")
                        return redirect(url_for("forgot"))
                elif err:
                    flash(err, "error")
                    return redirect(url_for("forgot"))
            flash("If an account matches, a 6-digit code was sent to its e-mail address.", "ok")
            return redirect(url_for("forgot_reset"))
        return render_template("forgot.html", mail_ok=mailer.configured())

    @app.route("/forgot/reset", methods=["GET", "POST"])
    def forgot_reset():
        who = session.get("reset_who", "")
        if not who:
            return redirect(url_for("forgot"))
        if request.method == "POST":
            c = con()
            u = c.execute("SELECT * FROM users WHERE (lower(username)=? OR lower(email)=?) AND email<>'' AND must_setup=0",
                          (who, who)).fetchone()
            pw, pw2 = request.form.get("password", ""), request.form.get("password2", "")
            err = check_password_rules(pw, pw2, u["username"] if u else "")
            if not err:
                if not u:
                    err = "That code is not correct. Ask for a new code."
                else:
                    row, err = check_code("reset", u["email"].lower(), request.form.get("code", ""))
            if err:
                flash(err, "error")
            else:
                c.execute("UPDATE users SET pw_hash=? WHERE id=?", (generate_password_hash(pw), u["id"]))
                c.execute("DELETE FROM login_attempts WHERE username=?", (u["username"].lower(),))
                consume(row)
                c.commit()
                session.pop("reset_who", None)
                mailer.send(u["email"], "Your Cert Verifier password was changed",
                            f"The password of '{u['username']}' was just changed. If this was not you, reset it again "
                            "and tell your administrator.\n\nCert Verifier")
                flash("Password changed. Sign in with the new password.", "ok")
                return redirect(url_for("login"))
        return render_template("forgot_reset.html")

    @app.route("/forgot-username", methods=["GET", "POST"])
    def forgot_username():
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            if EMAIL_RE.match(email) and mailer.configured():
                rows = con().execute("SELECT username FROM users WHERE lower(email)=? AND must_setup=0", (email,)).fetchall()
                code, err = (None, "")
                if rows:
                    code, err = issue_code("username", email)
                if rows and code:
                    mailer.send(email, "Your Cert Verifier username",
                                "Your username: " + ", ".join(r["username"] for r in rows) +
                                "\n\nIf you did not ask for this, ignore this e-mail.\n\nCert Verifier")
            flash("If an account uses that e-mail address, we sent the username to it.", "ok")
            return redirect(url_for("login"))
        return render_template("forgot_username.html", mail_ok=mailer.configured())

    # ---- change e-mail (needs a code sent to the new address)
    @app.post("/account/email")
    def account_email():
        email = request.form.get("email", "").strip()
        if not EMAIL_RE.match(email):
            flash("Enter a valid e-mail address.", "error")
        elif not mailer.configured():
            flash("E-mail sending is not set up yet.", "error")
        else:
            code, err = issue_code("email", email.lower(), g.user["id"], email)
            if code:
                sent, merr = mail_code(email, code, "Use it to confirm this e-mail address for your Cert Verifier account.")
                err = "" if sent else mail_problem(merr)
            if err:
                flash(err, "error")
            else:
                session["new_email"] = email.lower()
                flash(f"We sent a code to {email}. Enter it below.", "ok")
        return redirect(url_for("account"))

    @app.post("/account/email/verify")
    def account_email_verify():
        email = session.get("new_email", "")
        row, err = check_code("email", email, request.form.get("code", "")) if email else (None, "Enter the e-mail address first.")
        if err:
            flash(err, "error")
        else:
            con().execute("UPDATE users SET email=?, email_verified=1 WHERE id=?", (email, g.user["id"]))
            consume(row)
            con().commit()
            session.pop("new_email", None)
            flash("E-mail address saved.", "ok")
        return redirect(url_for("account"))

    @app.route("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    @app.route("/more")
    def more():
        return render_template("more.html")

    @app.route("/account", methods=["GET", "POST"])
    def account():
        if request.method == "POST":
            if not check_password_hash(g.user["pw_hash"], request.form["old"]):
                flash("Current password is wrong.", "error")
            elif len(request.form["new"]) < 8:
                flash("New password must be at least 8 characters.", "error")
            else:
                con().execute("UPDATE users SET pw_hash=? WHERE id=?",
                              (generate_password_hash(request.form["new"]), g.user["id"]))
                con().commit()
                flash("Password changed.", "ok")
        return render_template("account.html", pending_email=session.get("new_email", ""), mail_ok=mailer.configured())

    @app.route("/users", methods=["GET", "POST"])
    @admin_only
    def users():
        c = con()
        if request.method == "POST":
            un, fn, pw = request.form["username"].strip().lower(), request.form["full_name"].strip(), request.form["password"]
            role = "admin" if request.form.get("role") == "admin" else "user"
            em = request.form.get("email", "").strip()
            if not un or not fn or len(pw) < 8:
                flash("Username, full name and a password of 8+ characters are required.", "error")
            elif em and not EMAIL_RE.match(em):
                flash("That e-mail address does not look right.", "error")
            else:
                exists = c.execute("SELECT 1 FROM users WHERE lower(username)=?", (un,)).fetchone()
                if exists:
                    c.execute("UPDATE users SET pw_hash=?, full_name=?, role=?, email=CASE WHEN ?<>'' THEN ? ELSE email END WHERE lower(username)=?",
                              (generate_password_hash(pw), fn, role, em, em, un))
                else:
                    c.insert("users", username=un, full_name=fn, pw_hash=generate_password_hash(pw), role=role, email=em,
                             email_verified=0, must_setup=0)
                c.commit()
                flash(f"User {un} {'updated (password reset)' if exists else 'added'}.", "ok")
        return render_template("users.html", users=c.execute("SELECT * FROM users ORDER BY username").fetchall())

    # ------------------------------------------------------------ home / history
    @app.route("/")
    def home():
        c = con()
        counts = {(r[0] or "-"): r[1] for r in c.execute(
            "SELECT result, COUNT(*) FROM verifications WHERE status='final' GROUP BY result").fetchall()}
        recent = c.execute("SELECT * FROM verifications ORDER BY id DESC LIMIT 6").fetchall()
        drafts = c.execute("SELECT COUNT(*) FROM verifications WHERE status<>'final'").fetchone()[0]
        soon = []
        for lab in c.execute("SELECT * FROM labs").fetchall():
            vt = rules.pdate(lab["valid_to"])
            if vt and vt <= today() + timedelta(days=90):
                soon.append((lab, vt))
        return render_template("home.html", counts=counts, recent=recent, soon=soon, drafts=drafts,
                               nlabs=c.execute("SELECT COUNT(*) FROM labs").fetchone()[0], load=json.loads)

    @app.route("/history")
    def history():
        q = request.args.get("q", "").strip().lower()
        res = request.args.get("result", "")
        rows = []
        for v in con().execute("SELECT * FROM verifications ORDER BY id DESC LIMIT 500").fetchall():
            d = json.loads(v["data_json"] or "{}")
            hay = " ".join([d.get("cert_no", ""), d.get("instr_ident", ""), d.get("customer_name", ""),
                            d.get("lab_name", ""), v["file_name"] or ""]).lower()
            if q and q not in hay:
                continue
            if res and v["result"] != res:
                continue
            rows.append((v, d))
        return render_template("history.html", rows=rows, q=q, res=res)

    # ------------------------------------------------------------ verification flow
    def sniff(data):
        if data[:5] == b"%PDF-":
            return "application/pdf"
        if data[:3] == b"\xff\xd8\xff":
            return "image/jpeg"
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            return "image/png"
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp"
        return ""

    def fail(msg, code=400, **extra):
        if wants_json():
            return jsonify(ok=False, error=msg, **extra), code
        flash(msg, "error")
        return redirect(url_for("verify_new"))

    @app.route("/verify/new", methods=["GET", "POST"])
    def verify_new():
        if request.method == "GET":
            return render_template("new.html")
        f = request.files.get("file")
        data = f.read() if f else b""
        if not data:
            return fail("Choose a PDF or a photo of the certificate.")
        if len(data) > MAX_UPLOAD - 100_000:
            return fail("The file is larger than 4 MB. Use a smaller PDF, or a photo (photos are shrunk automatically).", 413)
        mime = sniff(data)
        if not mime:
            return fail("Unsupported file. Use a PDF, JPG or PNG.")
        fields, text, note = {}, "", ""
        if mime == "application/pdf" and request.form.get("ocr_text", "").strip():
            # scanned PDF: the browser rendered the pages and read them with OCR
            ocr = request.form["ocr_text"].replace("\x00", "")[:60000]
            try:
                fields = extract.fields_from_ocr(ocr, request.form.get("right_text", "").replace("\x00", "")[:3000],
                                                 request.form.get("left_text", "").replace("\x00", "")[:3000],
                                                 request.form.get("sig_ink"), (request.form.get("head_text", "") or "").replace("\x00", "")[:1500],
                                                     (request.form.get("ocr_alt", "") or "").replace("\x00", "")[:60000])
                text = ocr
            except Exception:
                app.logger.error("OCR text could not be parsed: %s", traceback.format_exc())
                fields, text = {}, ocr
                note = "The text was read but could not be sorted into fields. Fill in the fields by hand."
        elif mime == "application/pdf":
            try:
                fields, text = extract.read_pdf(data, trust_layer=bool(request.form.get("use_text_layer")))
            except Exception as e:
                app.logger.warning("PDF read failed: %s", e)
                fields = None
            if fields is None:
                if wants_json() and not request.form.get("manual"):
                    return jsonify(ok=False, scanned_pdf=True, error="This PDF is a scan (no selectable text). "
                                   "Upload a photo / JPG of the page instead, or enter the values by hand."), 422
                fields, note = {}, "This PDF has no selectable text, so nothing could be read automatically. Fill in the fields by hand."
        else:
            ocr = (request.form.get("ocr_text", "") or "").replace("\x00", "")[:60000]
            if ocr.strip():
                try:
                    fields = extract.fields_from_ocr(ocr, (request.form.get("right_text", "") or "").replace("\x00", "")[:3000],
                                                     (request.form.get("left_text", "") or "").replace("\x00", "")[:3000],
                                                     request.form.get("sig_ink"), (request.form.get("head_text", "") or "").replace("\x00", "")[:1500],
                                                     (request.form.get("ocr_alt", "") or "").replace("\x00", "")[:60000])
                    text = ocr
                except Exception:
                    app.logger.error("OCR text could not be parsed: %s", traceback.format_exc())
                    fields, text = {}, ocr
                    note = "The text was read but could not be sorted into fields. Fill in the fields by hand."
            else:
                note = "The photo could not be read automatically. Fill in the fields by hand."
        c = con()
        vid = c.insert("verifications", created_by=g.user["full_name"], created_at=now().isoformat(timespec="seconds"),
                       file_name=(f.filename or "certificate")[:120], data_json=json.dumps(fields),
                       ocr_text=(text + ("\n\n=== second reading ===\n" + request.form.get("ocr_alt", "").replace("\x00", "") if request.form.get("ocr_alt") else ""))[:60000])
        c.upsert("verification_files", ["verification_id"], verification_id=vid, mime=mime, data=data)
        c.commit()
        msg = note or "Certificate read. Please check the values - amber fields were not found."
        if wants_json():
            return jsonify(ok=True, url=url_for("verify_edit", vid=vid), message=msg, warn=bool(note))
        flash(msg, "warn" if note else "ok")
        return redirect(url_for("verify_edit", vid=vid))

    @app.route("/verify/<int:vid>/edit", methods=["GET", "POST"])
    def verify_edit(vid):
        v = get_v(vid)
        d = json.loads(v["data_json"] or "{}")
        if request.method == "POST":
            for k, kind in ALL_FIELDS:
                d[k] = ("on" if request.form.get(k) else "") if kind == "check" else request.form.get(k, "").strip()
            d["instr_name_raw"] = d.get("instr_type", "")
            con().execute("UPDATE verifications SET data_json=?, status=CASE WHEN status='final' THEN 'final' ELSE 'checked' END WHERE id=?",
                          (json.dumps(d), vid))
            con().commit()
            run_checks(vid)
            return redirect(url_for("verify_view", vid=vid))
        f = con().execute("SELECT mime FROM verification_files WHERE verification_id=?", (vid,)).fetchone()
        return render_template("edit.html", v=v, d=d, groups=GROUPS, optional=OPTIONAL, file_mime=f["mime"] if f else "")

    @app.route("/verify/<int:vid>")
    def verify_view(vid):
        v = get_v(vid)
        d = json.loads(v["data_json"] or "{}")
        checks = con().execute("SELECT * FROM check_results WHERE verification_id=?", (vid,)).fetchall()
        if not checks:
            return redirect(url_for("verify_edit", vid=vid))
        order = {c: i for i, c in enumerate(rules.ORDER)}
        checks = sorted(checks, key=lambda r: order.get(r["code"], 99))
        log = con().execute("SELECT * FROM change_log WHERE verification_id=? ORDER BY id DESC", (vid,)).fetchall()
        ctx = make_ctx()
        lab = ctx.lab_by_nabl(d.get("nabl_no", "")) if d.get("nabl_no") else None
        need_lab = d.get("calibration_kind") != "internal" and bool(d.get("nabl_no")) and not lab
        need_scope = bool(lab) and any(c["code"] == "2" and c["pending"] and c["status"] == "N/A" for c in checks)
        counts = {s: sum(1 for c in checks if c["status"] == s) for s in ("OK", "NOT OK", "N/A")}
        attention = sum(1 for c in checks if c["status"] != "OK")
        return render_template("view.html", v=v, d=d, checks=checks, log=log, need_lab=need_lab, lab=lab,
                               need_scope=need_scope, counts=counts, attention=attention)

    @app.post("/verify/<int:vid>/override")
    def verify_override(vid):
        get_v(vid)
        code, new = request.form["code"], request.form["new_status"]
        reason = request.form.get("reason", "").strip()
        c = con()
        row = c.execute("SELECT * FROM check_results WHERE verification_id=? AND code=?", (vid, code)).fetchone()
        if not row or new not in ("OK", "NOT OK", "N/A", "AUTO"):
            abort(400)
        if not reason:
            flash("A reason is required to change a result.", "error")
            return redirect(url_for("verify_view", vid=vid) + f"#rule-{code}")
        if new == "AUTO":
            c.execute("UPDATE check_results SET status=auto_status, overridden=0 WHERE verification_id=? AND code=?", (vid, code))
            new_eff = row["auto_status"]
        else:
            c.execute("UPDATE check_results SET status=?, overridden=1, pending=0 WHERE verification_id=? AND code=?",
                      (new, vid, code))
            new_eff = new
        c.insert("change_log", verification_id=vid, ts=now().isoformat(timespec="seconds"), by_user=g.user["full_name"],
                 code=code, old_status=row["status"], new_status=new_eff + (" (back to automatic)" if new == "AUTO" else " (manual)"),
                 reason=reason)
        c.execute("UPDATE verifications SET revision=revision+1 WHERE id=?", (vid,))
        c.commit()
        run_checks(vid)
        flash(f"Rule {code}: {row['status']} to {new_eff}. Saved in the log.", "ok")
        return redirect(url_for("verify_view", vid=vid) + f"#rule-{code}")

    @app.post("/verify/<int:vid>/rerun")
    def verify_rerun(vid):
        get_v(vid)
        run_checks(vid)
        flash("Checks re-run with the latest lab list, scope and instruments.", "ok")
        return redirect(url_for("verify_view", vid=vid))

    @app.post("/verify/<int:vid>/finalize")
    def verify_finalize(vid):
        get_v(vid)
        name, remark = request.form.get("verifier_name", "").strip(), request.form.get("verifier_remark", "").strip()
        if not name or not remark:
            flash("Verifier name and remark are required (rule 5).", "error")
            return redirect(url_for("verify_view", vid=vid) + "#signoff")
        c = con()
        c.execute("UPDATE verifications SET status='final', verifier_name=?, verifier_remark=?, verified_at=? WHERE id=?",
                  (name, remark, now().isoformat(timespec="seconds"), vid))
        c.commit()
        result = run_checks(vid)
        if result == "PENDING":
            c.execute("UPDATE verifications SET status='checked', verified_at='' WHERE id=?", (vid,))
            c.commit()
            run_checks(vid)
            flash("Cannot sign off yet - some checks are still pending (lab or scope missing). Complete them first.", "error")
        else:
            flash(f"Signed off. Result: {result}.", "ok")
        return redirect(url_for("verify_view", vid=vid))

    @app.route("/verify/<int:vid>/report.pdf")
    def verify_report(vid):
        v = get_v(vid)
        d = json.loads(v["data_json"] or "{}")
        order = {c: i for i, c in enumerate(rules.ORDER)}
        checks = sorted((dict(r) for r in con().execute("SELECT * FROM check_results WHERE verification_id=?", (vid,)).fetchall()),
                        key=lambda r: order.get(r["code"], 99))
        log = [dict(r) for r in con().execute("SELECT * FROM change_log WHERE verification_id=? ORDER BY id", (vid,)).fetchall()]
        pdf = report.build_pdf(dict(v), d, checks, log, lab_label(d), now=now())
        return Response(pdf, mimetype="application/pdf",
                        headers={"Content-Disposition": f'inline; filename="Verification_V{vid:05d}.pdf"'})

    @app.route("/verify/<int:vid>/file")
    def verify_file(vid):
        get_v(vid)
        f = con().execute("SELECT mime, data FROM verification_files WHERE verification_id=?", (vid,)).fetchone()
        if not f:
            abort(404)
        return Response(bytes(f["data"]), mimetype=f["mime"], headers={"Content-Disposition": "inline"})

    @app.post("/verify/<int:vid>/delete")
    @admin_only
    def verify_delete(vid):
        get_v(vid)
        con().execute("DELETE FROM verifications WHERE id=?", (vid,))
        con().commit()
        flash("Verification deleted.", "ok")
        return redirect(url_for("history"))

    # ------------------------------------------------------------ labs
    def lab_state(lab):
        vt = rules.pdate(lab["valid_to"])
        if lab["status"] != "Active":
            return lab["status"], "bad"
        if not vt:
            return "No validity date", "warn"
        if vt < today():
            return "Expired", "bad"
        if vt <= today() + timedelta(days=90):
            return "Expires soon", "warn"
        return "Valid", "good"

    @app.route("/labs")
    def labs():
        rows = []
        for lab in con().execute("SELECT * FROM labs ORDER BY name").fetchall():
            n = con().execute("SELECT COUNT(*) FROM lab_scope WHERE lab_id=?", (lab["id"],)).fetchone()[0]
            rows.append((lab, lab_state(lab), n))
        return render_template("labs.html", rows=rows)

    def save_lab(lab_id=None):
        f = request.form
        name, nabl = f["name"].strip(), db.norm_nabl(f["nabl_no"])
        if not name or not nabl:
            raise ValueError("Lab name and NABL number are required.")
        vals = dict(name=name, nabl_no=nabl, address=f.get("address", "").strip(),
                    valid_from=f.get("valid_from", "").strip() or None, valid_to=f.get("valid_to", "").strip() or None,
                    status=f.get("status", "Active") if f.get("status") in ("Active", "Suspended", "Withdrawn") else "Active",
                    notes=f.get("notes", "").strip())
        c = con()
        dup = c.execute("SELECT id FROM labs WHERE nabl_no=?", (nabl,)).fetchone()
        if dup and dup["id"] != lab_id:
            raise ValueError(f"A lab with number {nabl} already exists.")
        if lab_id:
            sets = ",".join(f"{k}=?" for k in vals)
            c.execute(f"UPDATE labs SET {sets} WHERE id=?", list(vals.values()) + [lab_id])
        else:
            lab_id = c.insert("labs", **vals)
        c.commit()
        return lab_id

    @app.route("/labs/new", methods=["GET", "POST"])
    def lab_new():
        if request.method == "POST":
            try:
                lid = save_lab()
                flash("Lab added. Now add its scope (instrument types, ranges, CMC).", "ok")
                return redirect(url_for("lab_edit", lid=lid) + "#scope")
            except ValueError as e:
                flash(str(e), "error")
        return render_template("lab_form.html", lab=request.form or {}, scopes=[], new=True)

    @app.route("/labs/<int:lid>", methods=["GET", "POST"])
    def lab_edit(lid):
        lab = con().execute("SELECT * FROM labs WHERE id=?", (lid,)).fetchone() or abort(404)
        if request.method == "POST":
            try:
                save_lab(lid)
                flash("Lab saved.", "ok")
                return redirect(url_for("lab_edit", lid=lid))
            except ValueError as e:
                flash(str(e), "error")
        scopes = con().execute("SELECT * FROM lab_scope WHERE lab_id=? ORDER BY instrument_type, range_max", (lid,)).fetchall()
        return render_template("lab_form.html", lab=lab, scopes=scopes, new=False, state=lab_state(lab))

    @app.post("/labs/<int:lid>/scope")
    def scope_add(lid):
        f = request.form
        try:
            rmax, rmin = float(f["range_max"]), float(f.get("range_min") or 0)
            cmc = float(f["cmc_um"]) if f.get("cmc_um", "").strip() else None
            if not f["instrument_type"].strip():
                raise ValueError
        except (ValueError, KeyError):
            flash("Scope needs an instrument type and a numeric range.", "error")
            return redirect(url_for("lab_edit", lid=lid) + "#scope")
        con().insert("lab_scope", lab_id=lid, instrument_type=f["instrument_type"].strip(), range_min=rmin,
                     range_max=rmax, unit=f.get("unit", "mm"), cmc_um=cmc)
        con().commit()
        flash("Scope line added.", "ok")
        return redirect(url_for("lab_edit", lid=lid) + "#scope")

    @app.post("/labs/<int:lid>/scope/<int:sid>/delete")
    def scope_delete(lid, sid):
        con().execute("DELETE FROM lab_scope WHERE id=? AND lab_id=?", (sid, lid))
        con().commit()
        return redirect(url_for("lab_edit", lid=lid) + "#scope")

    @app.post("/labs/<int:lid>/delete")
    @admin_only
    def lab_delete(lid):
        con().execute("DELETE FROM labs WHERE id=?", (lid,))
        con().commit()
        flash("Lab deleted.", "ok")
        return redirect(url_for("labs"))

    @app.post("/labs/quick-add")
    def lab_quick_add():
        vid = int(request.form["vid"])
        try:
            save_lab()
        except ValueError as e:
            flash(str(e), "error")
            return redirect(url_for("verify_view", vid=vid))
        run_checks(vid)
        flash("Lab added. Checks re-run - now add the lab's scope to finish rule 2.", "ok")
        return redirect(url_for("verify_view", vid=vid))

    # ------------------------------------------------------------ instruments & env limits
    @app.route("/instruments", methods=["GET", "POST"])
    def instruments():
        c = con()
        if request.method == "POST":
            f = request.form
            try:
                c.upsert("instruments", ["ident"], ident=f["ident"].strip(), name=f.get("name", "").strip(),
                         range_min=float(f.get("range_min") or 0), range_max=float(f["range_max"]), unit=f.get("unit", "mm"),
                         grade=f.get("grade", "").strip())
                if not f["ident"].strip():
                    raise ValueError
                c.commit()
                flash("Instrument saved.", "ok")
            except (ValueError, KeyError):
                c.rollback()
                flash("Identification and a numeric range are required.", "error")
        return render_template("instruments.html", rows=c.execute("SELECT * FROM instruments ORDER BY ident").fetchall())

    @app.post("/instruments/<int:iid>/delete")
    def instrument_delete(iid):
        con().execute("DELETE FROM instruments WHERE id=?", (iid,))
        con().commit()
        return redirect(url_for("instruments"))

    @app.route("/settings/environment", methods=["GET", "POST"])
    @admin_only
    def env_settings():
        c = con()
        if request.method == "POST":
            try:
                for r in c.execute("SELECT key FROM env_limits").fetchall():
                    k = r["key"]

                    def num(n):
                        s = request.form.get(f"{n}_{k}", "").strip()
                        return float(s) if s else None
                    nom = num("nom")
                    c.execute("UPDATE env_limits SET temp_nom=?, temp_tol=?, rh_max=? WHERE key=?",
                              (nom, num("tol") if nom is not None else None, num("rh"), k))
                c.commit()
                flash("Limits saved.", "ok")
            except ValueError:
                c.rollback()
                flash("Limits must be numbers.", "error")
        return render_template("env.html", rows=c.execute("SELECT * FROM env_limits ORDER BY key").fetchall())

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)), debug=False)
