"""Whole scanned-PDF flow in real Chromium. The two CDN libraries are replaced by stand-ins:
pdf.js -> hands out the pages rendered by pdftoppm; Tesseract.js -> runs the tesseract program on the canvas.
Usage: python3 browser_scan_flow.py <scan.pdf> <outdir> [grade]"""
import base64, glob, json, os, re, subprocess, sys, tempfile
from playwright.sync_api import sync_playwright
PDF, OUT = sys.argv[1], sys.argv[2]; B = "http://127.0.0.1:5066"
tmp = tempfile.mkdtemp(); subprocess.run(["pdftoppm", "-r", "200", "-png", PDF, tmp + "/pg"], check=True)
pages = [base64.b64encode(open(f, "rb").read()).decode() for f in sorted(glob.glob(tmp + "/pg-*.png"))]
PDFJS = """window.pdfjsLib={GlobalWorkerOptions:{},getDocument:function(){return {promise:Promise.resolve({numPages:%d,getPage:function(n){
 var src=%s[n-1]; return Promise.resolve({getViewport:function(o){return {width:1654*o.scale,height:2339*o.scale}},
 render:function(p){ return {promise:new Promise(function(res){ var im=new Image(); im.onload=function(){ var c=p.canvasContext.canvas; p.canvasContext.drawImage(im,0,0,c.width,c.height); res(); }; im.src='data:image/png;base64,'+src; })}; }}); }})}}};""" % (len(pages), json.dumps(pages))
TESS = """window.Tesseract={createWorker:async function(){ var psm='6'; return {setParameters:async function(p){ if(p.tessedit_pageseg_mode) psm=p.tessedit_pageseg_mode; },
 recognize:async function(c){ var r=await fetch('https://cdn.jsdelivr.net/ocr?psm='+psm,{method:'POST',body:c.toDataURL('image/png')}); var j=await r.json(); return {data:j}; },
 terminate:async function(){} }; }};"""
def tess(png, psm):
    f = tmp + "/o.png"; open(f, "wb").write(png)
    txt = subprocess.run(["tesseract", f, "-", "--psm", psm, "-c", "preserve_interword_spaces=1"], capture_output=True, text=True).stdout
    tsv = subprocess.run(["tesseract", f, "-", "--psm", psm, "tsv"], capture_output=True, text=True).stdout.splitlines()[1:]
    words = []
    for l in tsv:
        p = l.split("\t")
        if len(p) == 12 and p[11].strip() and float(p[10]) > 0:
            x, y, w, h = map(int, p[6:10]); words.append({"text": p[11], "bbox": {"x0": x, "y0": y, "x1": x + w, "y1": y + h}})
    return {"text": txt, "words": words}
def handle(route):
    u = route.request.url
    if "pdf.min.js" in u: return route.fulfill(body=PDFJS, content_type="text/javascript")
    if "pdf.worker" in u: return route.fulfill(body="", content_type="text/javascript")
    if "tesseract" in u: return route.fulfill(body=TESS, content_type="text/javascript")
    if "/ocr" in u:
        png = base64.b64decode(route.request.post_data.split(",", 1)[1]); psm = re.search(r"psm=(\d)", u).group(1)
        return route.fulfill(body=json.dumps(tess(png, psm)), content_type="application/json", headers={"access-control-allow-origin": "*"})
    route.continue_()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 390, "height": 800}); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.route("https://cdn.jsdelivr.net/**", handle)
    pg.goto(B + "/login"); pg.fill("#u", "admin"); pg.fill("#p", "test-pass-123"); pg.click("button.btn"); pg.wait_for_url("**/")
    pg.goto(B + "/verify/new"); pg.set_input_files("#fil", PDF); pg.wait_for_url("**/edit", timeout=240000)
    g = os.environ.get("GRADE")
    if g: pg.evaluate("v=>document.querySelector(\"[name=instr_grade]\").value=v", g)
    pg.click("text=Run the 20 checks"); pg.wait_for_selector(".hero", timeout=30000); html = pg.content()
    pg.screenshot(path=OUT + "/scanflow.png", full_page=True)
    print("JS errors:", errs or "none"); open(OUT + "/scanflow.html", "w").write(html)
    b.close()
