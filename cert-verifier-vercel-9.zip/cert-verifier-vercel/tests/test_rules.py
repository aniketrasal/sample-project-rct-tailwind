import sys, copy
sys.path.insert(0, "/home/claude/cert-verifier-vercel")
from datetime import date
import rules as R

LAB = dict(id=1, name="Caliber Gauges And Instruments Laboratory LLP", nabl_no="CC-2656", valid_from="2024-03-01",
           valid_to="2027-02-28", status="Active", address="Pune")
SCOPE = {1: [dict(instrument_type="Vernier Caliper", range_min=0, range_max=300, unit="mm", cmc_um=10)]}
ENV = [dict(key="dimensional", label="Dimensional", temp_nom=20, temp_tol=2, rh_max=None),
       dict(key="gdt", label="GD&T", temp_nom=None, temp_tol=None, rh_max=None),
       dict(key="electrical", label="Electrical", temp_nom=25, temp_tol=4, rh_max=70),
       dict(key="thermal", label="Thermal", temp_nom=25, temp_tol=4, rh_max=70)]
BASE = dict(calibration_kind="nabl", nabl_no="CC-2656", nabl_symbol="on", title="Calibration Certificate",
    lab_name=LAB["name"], lab_address="S. No. 14/1, Pune - 411052", lab_location="In Lab", cert_no="C-004", page_text="1 of 1",
    end_marker="on", customer_name="Fleetguard", customer_address="Nandur, Pune 412202", method_no="CGIL-CP-04",
    reference_std="IS 16491", instr_type="Vernier Caliper (Digital)", instr_class="dimensional", instr_ident="X1",
    instr_make="Mitutoyo", instr_serial="1", instr_range="0 To 200 mm", instr_lc="0.01 mm", receipt_date="11/06/2026",
    cal_date="11/06/2026", due_date="10/06/2027", issue_date="13/06/2026",
    results_external="0,0,0\n20,19.99,-10\n50,49.99,-10\n100,99.99,-10\n150,149.99,-10\n200,199.99,-10",
    results_unit_text="Observed Reading in mm & Error in um", acc_ranges="0-50, 50-200, 200-400, 400-600",
    acc_empe="20, 30, 40, 50", acc_smpe="30, 50, 60, 70", approver_name="B", approver_function="QM",
    approver_signature="on", statement_text="pertains only to the items calibrated", env_temp="20.1", env_humidity="52",
    unc_value="16", unc_unit="um", unc_conf="95.45", k_factor="2",
    standards="Caliper Checker | CGIL/STD/02 | CGIL/2025/0904/D-003 | CC-2656 | 04/09/2027")
def run(**ch):
    d = copy.deepcopy(BASE); d.update(ch)
    res = R.evaluate(d, R.Ctx([LAB], SCOPE, [], ENV), finalizing=False)
    return {r["code"]: r for r in res}
def expect(name, code, status, **ch):
    got = run(**ch)[code]
    assert got["status"] == status, f"{name}: rule {code} expected {status}, got {got['status']} ({got['reason']})"
    print(f"ok  {name:55} -> {code} {status}")

base = run(); assert all(base[c]["status"] == "OK" for c in R.ORDER if c != "5"), {c: base[c]["status"] for c in R.ORDER}
print("ok  baseline: 20 checks all OK (rule 5 waits for sign-off)")
expect("no NABL number", "1", "N/A", nabl_no="")
expect("NABL number not in lab list", "1", "N/A", nabl_no="CC-9999")
expect("lab number matches but name differs", "1", "NOT OK", lab_name="Totally Different Metrology Pvt Ltd")
expect("internal calibration, checklist not ticked", "1", "NOT OK", calibration_kind="internal")
expect("internal calibration, checklist ticked", "1", "OK", calibration_kind="internal", wi_ok="on", competency_ok="on")
expect("calibrated after accreditation expired", "2", "NOT OK", cal_date="01/03/2027", receipt_date="01/03/2027", issue_date="02/03/2027", due_date="01/03/2028")
expect("calibrated before accreditation started", "2", "NOT OK", cal_date="01/01/2024", receipt_date="01/01/2024", issue_date="02/01/2024", due_date="01/01/2025")
expect("lab scope is no longer checked: any instrument type", "2", "OK", instr_type="Micrometer")
expect("lab scope is no longer checked: any range", "2", "OK", instr_range="0 To 600 mm")
expect("title missing", "3a", "N/A", title="")
expect("lab address missing", "3b", "N/A", lab_address="")
expect("certificate number missing", "3c", "N/A", cert_no="")
expect("last page number identifies the end (1 of 1)", "3c", "OK", end_marker="")
expect("page 1 of 2 uploaded alone, no marker", "3c", "N/A", end_marker="", page_text="1 of 2")
expect("customer name missing", "3d", "N/A", customer_name="")
expect("method missing", "3e", "N/A", method_no="")
expect("serial number missing", "3f", "N/A", instr_serial="")
expect("due date before calibration", "3g", "NOT OK", due_date="01/01/2026")
expect("issue date missing", "3g", "N/A", issue_date="")
expect("no results", "3h", "N/A", results_external="")
expect("approver signature missing", "3i", "N/A", approver_signature="")
expect("statement missing", "3j", "N/A", statement_text="")
expect("no environmental conditions", "3k", "N/A", env_temp="", env_humidity="")
expect("confidence 99%", "3l", "NOT OK", unc_conf="99")
expect("confidence 95% accepted", "3l", "OK", unc_conf="95")
expect("k missing", "3m", "N/A", k_factor="")
expect("no traceability", "3n", "N/A", standards="Caliper Checker | CGIL/STD/02 | CGIL/2025/0904/D-003 |  | 04/09/2027")
expect("master expired before calibration", "3o", "NOT OK", standards="Caliper Checker | A | B | CC-2656 | 01/06/2026")
expect("master validity not found", "3o", "N/A", standards="Caliper Checker | A | B | CC-2656 | ")
expect("calibrated points stop at 100 of 200", "4", "NOT OK", results_external="0,0,0\n50,49.99,-10\n100,99.99,-10")
expect("no points", "4", "N/A", results_external="")
expect("temperature 23.5 (limit 20+/-2)", "6", "NOT OK", env_temp="23.5")
expect("temperature missing", "6", "N/A", env_temp="")
expect("electrical: 26C 65% ok", "6", "OK", instr_class="electrical", env_temp="26", env_humidity="65")
expect("electrical: humidity 70 not below 70", "6", "NOT OK", instr_class="electrical", env_temp="26", env_humidity="70")
expect("GD&T ambient temperature, no number", "6", "OK", instr_class="gdt", env_temp="31")
expect("error 25um at 20mm exceeds +/-20", "X1", "NOT OK", results_external="20,19.975,-25")
expect("50mm uses the 0-50 band (+/-20): -22um", "X1", "NOT OK", results_external="50,49.978,-22")
expect("100mm uses 50-200 band (+/-30): -25um", "X1", "OK", results_external="100,99.975,-25")
expect("reported error does not match observed", "X1", "NOT OK", results_external="20,19.99,-5")
expect("acceptance table missing", "X1", "N/A", acc_ranges="", acc_empe="")
# V-block certificate (no letterhead, parameters + grade formulas)
VB = dict(BASE, nabl_no="CC-2656", nabl_symbol="", nabl_from_ulr="on", lab_name="", lab_address="", lab_location="In Lab",
    instr_type="V-Block", instr_class="gdt", instr_ident="FFPL/UL/VB/04", instr_make="Crystal", instr_serial="1485B",
    instr_range="100X90X75", instr_lc="", instr_lc_applicable="no", dim_L="100", dim_h1="75",
    results_external="", results_params="Parallelism of axis of V Block to base | 12\nParallelism of axis of V Block to Side | 12\nSymmetricity | 11\nSquareness w.r.t. A | 4",
    results_unit_text="Observed Value (in um)", acc_ranges="", acc_empe="", acc_smpe="",
    acc_formulas="Grade | Parallelism | Squareness\n0 | 3+(L/250) | 2+(h1/100)\n1 | 6+(L/100) | 4+(h1/50)\n2 | 12+(L/50) | 10+(h1/25)",
    approver_signature="", receipt_date="10/10/2026", cal_date="12/10/2026", due_date="11/10/2027", issue_date="13/10/2026",
    env_temp="20.1", env_humidity="52", unc_value="3.5", unc_unit="um",
    standards="Height Gauge | CGIL/EQP/12 | CGIL/2025/0102/A-002 | CC-2656 | 01/01/2027\nPlain Mandrel | CGIL/STD/30 | P/60/250067 | CC-2082 | 28/11/2027",
    page_total="2", pages_found="1,2")
LAB2 = dict(LAB, valid_to="2029-02-28")
def runvb(inst=(), **ch):
    d = copy.deepcopy(VB); d.update(ch)
    return {r["code"]: r for r in R.evaluate(d, R.Ctx([LAB2], {1: SCOPE[1] + [dict(instrument_type="V Block", range_min=0, range_max=500, unit="mm", cmc_um=3)]}, list(inst), ENV), finalizing=False)}
def vb(name, code, status, inst=(), **ch):
    got = runvb(inst, **ch)[code]
    assert got["status"] == status, f"{name}: rule {code} expected {status}, got {got['status']} ({got['reason']})"
    print(f"ok  {name:55} -> {code} {status}")
vb("vb: no letterhead -> NABL symbol not found", "1", "N/A")
vb("vb: lab name/address not on file", "3b", "N/A")
for c in ("3a","3c","3d","3e","3f","3g","3h","3j","3k","3l","3m","3n","3o","6"):
    vb("vb: "+c, c, "OK")
vb("vb: approver signature not found", "3i", "N/A")
vb("vb: parameters, not points -> rule 4 default OK (reviewer confirms)", "4", "OK")
vb("vb: grade unknown -> pending", "X1", "N/A")
assert runvb()["X1"]["pending"]
vb("vb: grade 2 passes", "X1", "OK", instr_grade="2")
vb("vb: grade 1 fails parallelism 12 > 7", "X1", "NOT OK", instr_grade="1")
vb("vb: grade 0 fails", "X1", "NOT OK", instr_grade="0")
vb("vb: grade from instrument list", "X1", "OK", inst=[dict(ident="FFPL/UL/VB/04", range_min=0, range_max=1, unit="mm", grade="2")])
vb("vb: page 2 lacks cert no.", "3c", "N/A", pages_found="1")
vb("vb: nabl symbol ticked in review -> OK", "1", "OK", nabl_symbol="on")
# overall logic
res = list(run().values()); res[4]["status"] = "NOT OK"; assert R.overall(res) == "NOT OK"
r2 = [dict(status="OK", pending=0), dict(status="N/A", pending=1)]; assert R.overall(r2) == "PENDING"
r3 = [dict(status="OK", pending=0), dict(status="N/A", pending=0)]; assert R.overall(r3) == "OK"
print("ok  overall: any NOT OK -> NOT OK; pending -> PENDING; N/A alone does not fail")
print("ALL RULE TESTS PASSED")
