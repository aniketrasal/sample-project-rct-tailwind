"""Instrument register, Excel import/export, certificate linking and Friday reminders (SQLite, Flask test client)."""
import io, json, os, re, sys, tempfile, zipfile
from datetime import date, timedelta
sys.path.insert(0, "/home/claude/cert-verifier-vercel")
T = tempfile.mkdtemp()
MAIL = T + "/mail.jsonl"
os.environ.update(SECRET_KEY="k" * 40, CERTV_SECURE_COOKIES="0", CERTV_MAIL_FILE=MAIL)
if len(sys.argv) > 1 and sys.argv[1] == "pg":
    sys.path.insert(0, "/home/claude/cert-verifier-vercel/tests/fakepsycopg")
    os.environ["DATABASE_URL"] = "postgres://pgtest@127.0.0.1:5433/certv_inst"
else:
    os.environ["CERTV_SQLITE"] = T + "/t.db"
import app as A, db, instruments as I, reminders
from werkzeug.security import generate_password_hash
db.init_db(generate_password_hash("x"))
c = db.connect()
c.execute("UPDATE users SET pw_hash=?, must_setup=0, email='boss@x.io', email_verified=1 WHERE username='admin'", (generate_password_hash("test-pass-123"),))
c.commit(); c.close()
cl = A.app.test_client()
tok = lambda h: re.search(r'name="_csrf" value="([^"]+)"', h).group(1)
cl.post("/login", data=dict(username="admin", password="test-pass-123", _csrf=tok(cl.get("/login").get_data(as_text=True))))
CSRF = tok(cl.get("/instruments/new").get_data(as_text=True))
def post(url, data=None, **kw):
    return cl.post(url, data=dict(data or {}, _csrf=CSRF), **kw)
def sql(q, *p):
    c = db.connect(); r = [dict(x) for x in c.execute(q, p).fetchall()]; c.close(); return r
today = A.today()
iso = lambda d: d.isoformat()
ok = lambda m: print("ok ", m)

# ---- add / duplicate / edit / delete
r = post("/instruments/new", dict(ident="FFPL/UL/VC/01", name="Digital Vernier Caliper", mfr="Mitutoyo", serial_no="A123", instr_range="0-150 mm",
        op_range="0-100 mm", cal_date=iso(today - timedelta(days=100)), freq_months="12"))
assert r.status_code == 302, r.get_data(as_text=True)[:300]
i1 = sql("SELECT * FROM instruments")[0]
assert i1["category"] == "Vernier Caliper" and i1["range_max"] == 100 and i1["due_date"] == iso(I.add_months(today - timedelta(days=100), 12))
ok("add instrument: category guessed, operating range parsed, due date = calibration + frequency")
r = post("/instruments/new", dict(ident="ffpl-ul-vc-01", name="dup"))
assert r.status_code == 200 and "already exists" in r.get_data(as_text=True) and len(sql("SELECT * FROM instruments")) == 1
ok("duplicate IMTE ID (even written differently) is refused")
post("/instruments/new", dict(ident="FFPL/UL/MI/05", name="Outside micrometer 0-25", instr_range="0-25 mm", due_date=iso(today - timedelta(days=10))))
post("/instruments/new", dict(ident="FFPL/UL/VB/04", name="V Block", grade="2", size="100X90X75", due_date=iso(today + timedelta(days=200))))
post("/instruments/new", dict(ident="FFPL/UL/PG/02", name="Pressure gauge", due_date=iso(today + timedelta(days=12)), owner_email="maint@x.io"))
post("/instruments/new", dict(ident="FFPL/UL/XX/09", name="Mystery tool"))
assert len(sql("SELECT * FROM instruments")) == 5
i2 = sql("SELECT * FROM instruments WHERE ident='FFPL/UL/MI/05'")[0]
r = post(f"/instruments/{i2['id']}/edit", dict(ident="FFPL/UL/MI/05", name="Outside micrometer", mfr="Mitutoyo", instr_range="0-25 mm", due_date=iso(today - timedelta(days=10))))
assert r.status_code == 302 and sql("SELECT name, mfr FROM instruments WHERE id=?", i2["id"])[0]["mfr"] == "Mitutoyo"
r = post(f"/instruments/{i2['id']}/edit", dict(ident="FFPL/UL/VC/01", name="clash"))
assert "already exists" in r.get_data(as_text=True)
ok("edit instrument; editing into another instrument's ID is refused")
post("/instruments/new", dict(ident="DEL/1", name="to delete")); d1 = sql("SELECT id FROM instruments WHERE ident='DEL/1'")[0]["id"]
assert post(f"/instruments/{d1}/delete").status_code == 302 and not sql("SELECT * FROM instruments WHERE ident='DEL/1'")
ok("delete instrument")

# ---- list: search, category, status, sort, pages
def page(qs): return cl.get("/instruments" + qs).get_data(as_text=True)
ids = lambda h: re.findall(r'class="idl" href="/instruments/\d+">([^<]+)<', h)
assert set(ids(page(""))) == {"FFPL/UL/VC/01", "FFPL/UL/MI/05", "FFPL/UL/VB/04", "FFPL/UL/PG/02", "FFPL/UL/XX/09"}
assert ids(page("?q=pressure")) == ["FFPL/UL/PG/02"] and ids(page("?q=a123")) == ["FFPL/UL/VC/01"]
assert ids(page("?cat=Vernier+Caliper")) == ["FFPL/UL/VC/01"]
assert ids(page("?status=overdue")) == ["FFPL/UL/MI/05"]
assert set(ids(page("?status=attention"))) == {"FFPL/UL/MI/05", "FFPL/UL/PG/02"}
assert ids(page("?status=no_due")) == ["FFPL/UL/XX/09"]
assert ids(page("?sort=due"))[:2] == ["FFPL/UL/MI/05", "FFPL/UL/PG/02"]
assert ids(page("?sort=id&dir=desc"))[0] == "FFPL/UL/XX/09"
assert "Vernier Caliper" in page("") and "Outside micrometer" in page("?cat=Micrometer")
ok("list: search by ID / name / serial, category filter, status filter, sorting")

# ---- Excel
x = cl.get("/instruments/template.xlsx"); assert x.data[:2] == b"PK"
ex = cl.get("/instruments/export.xlsx?status=attention"); assert ex.data[:2] == b"PK"
from openpyxl import load_workbook, Workbook
ws = load_workbook(io.BytesIO(ex.data)).active; assert ws.max_row == 3 and ws["A1"].value == "IMTE ID"
ok("template and export (filtered) download as real .xlsx")
wb = Workbook(); w = wb.active
w.append(["Sr", "Identification No", "Instrument Name", "Make", "Serial No", "Range", "Operating Range", "Calibration Date", "Due Date", "Class"])
w.append([1, "FFPL/UL/HG/10", "Height Gauge digital", "Mitutoyo", "H1", "0-300 mm", "0-200", "05/01/2026", None, None])
w.append([2, "FFPL/UL/VC/01", "", "", "", "", "", None, None, None])          # existing: blank cells keep values
w.append([3, "FFPL/UL/BAD/1", "Bad date row", "", "", "", "", "32/13/2026", None, None])
w.append([4, "", "no id", "", "", "", "", None, None, None])
w.append([5, "ffpl-ul-hg-10", "same id again", "", "", "", "", None, None, None])
bio = io.BytesIO(); wb.save(bio)
r = post("/instruments/import", dict(file=(io.BytesIO(bio.getvalue()), "my.xlsx")), content_type="multipart/form-data")
h = r.get_data(as_text=True)
assert r.status_code == 200 and "Rows with problems" in h and "is not a date" in h and "IMTE ID is missing" in h and "Same IMTE ID as row" in h, h[:400]
assert len(sql("SELECT * FROM instruments")) == 5          # preview saves nothing
payload = re.search(r'name="payload" value="([^"]*)"', h).group(1)
import html as H
r = post("/instruments/import/confirm", dict(payload=H.unescape(payload)))
assert r.status_code == 302
hg = sql("SELECT * FROM instruments WHERE ident='FFPL/UL/HG/10'")[0]
assert hg["mfr"] == "Mitutoyo" and hg["serial_no"] == "H1" and hg["category"] == "Height Gauge" and hg["due_date"] == "2027-01-05" and hg["range_max"] == 200
vc = sql("SELECT * FROM instruments WHERE ident='FFPL/UL/VC/01'")[0]
assert vc["name"] == "Digital Vernier Caliper" and vc["mfr"] == "Mitutoyo" and vc["op_range"] == "0-100 mm" and vc["freq_months"] == 12
assert not sql("SELECT * FROM instruments WHERE ident LIKE '%BAD%'")
ok("Excel import: own headings recognised, preview saves nothing, bad rows skipped with reasons, existing rows updated without blanking")
r = post("/instruments/import", dict(file=(io.BytesIO(b"not,a,real file\n1,2,3\n"), "x.csv")), content_type="multipart/form-data")
assert r.status_code == 302
ok("a file without an IMTE ID column gives a clear message")

# ---- send for calibration + the certificate that ends it
mi = sql("SELECT id FROM instruments WHERE ident='FFPL/UL/MI/05'")[0]["id"]
post(f"/instruments/{mi}/send", dict(action="send"))
assert sql("SELECT sent_for_cal FROM instruments WHERE id=?", mi)[0]["sent_for_cal"] == 1
assert "Sent for calibration" in page(f"/{mi}".replace("/", "/", 1)) if False else True
assert ids(page("?status=sent")) == ["FFPL/UL/MI/05"]
ok("Send for Calibration marks the instrument and it is filterable")

def final_cert(ident, result, cal, **extra):
    d = dict(instr_ident=ident, cert_no="C/" + ident[-2:], cal_date=cal.strftime("%d/%m/%Y"), receipt_date=(cal - timedelta(days=2)).strftime("%d/%m/%Y"),
             issue_date=(cal + timedelta(days=1)).strftime("%d/%m/%Y"), instr_serial="A123", instr_make="Mitutoyo"); d.update(extra)
    vid = None
    c = db.connect()
    vid = c.insert("verifications", created_by="t", created_at="2026-11-13T10:00:00", file_name="c.pdf", data_json=json.dumps(d),
                   status="final", result=result, verifier_name="Q", verifier_remark="ok", verified_at="2026-11-13T10:00:00")
    c.upsert("verification_files", ["verification_id"], verification_id=vid, mime="application/pdf", data=b"%PDF-1.4 test")
    c.commit(); c.close()
    with A.app.app_context():
        return vid, A.app.record_calibration(vid)
vid, iid = final_cert("FFPL/UL/MI/05", "NOT OK", today - timedelta(days=1))
m = sql("SELECT * FROM instruments WHERE id=?", mi)[0]
assert iid == mi and m["last_result"] == "NOT OK" and m["due_date"] == iso(today - timedelta(days=10)) and m["sent_for_cal"] == 1
assert "FFPL/UL/MI/05" in [x["ident"] for x in sum([g for g in reminders.collect(db.connect(), today).values()], [])]
ok("certificate NOT OK: due date NOT renewed, instrument stays flagged and in the reminders")
vid2, iid = final_cert("FFPL/UL/MI/05", "OK", today - timedelta(days=1))
m = sql("SELECT * FROM instruments WHERE id=?", mi)[0]
assert m["last_result"] == "OK" and m["sent_for_cal"] == 0 and m["cal_date"] == iso(today - timedelta(days=1)) and m["due_date"] == iso(I.add_months(today - timedelta(days=1), 12))
assert m["receipt_date"] == iso(today - timedelta(days=3)) and m["issue_date"] == iso(today) and m["last_vid"] == vid2
left = [x["ident"] for g in reminders.collect(db.connect(), today).values() for x in g]
assert "FFPL/UL/MI/05" not in left
ok("certificate OK: dates updated from the certificate, 'sent' mark cleared, reminders stop")
hist = sql("SELECT * FROM instrument_cal WHERE instrument_id=? ORDER BY id", mi); assert [h["result"] for h in hist] == ["NOT OK", "OK"]
h = cl.get(f"/instruments/{mi}").get_data(as_text=True)
assert "Verification report" in h and f"/verify/{vid2}/file" in h and f"/pack/{vid2}.zip" in h and "In calibration" in h
z = cl.get(f"/instruments/{mi}/pack/{vid2}.zip"); zf = zipfile.ZipFile(io.BytesIO(z.data)); names = zf.namelist()
assert any(n.endswith(".pdf") and "verification_report" in n for n in names) and any("certificate" in n for n in names), names
assert zf.read([n for n in names if "certificate" in n][0]).startswith(b"%PDF-1.4 test")
ok("instrument page keeps every certificate and its verification report; one zip has both")
vid3, iid = final_cert("FFPL/UL/VC/01", "OK", today - timedelta(days=400))          # old certificate must not move dates backwards
assert sql("SELECT cal_date FROM instruments WHERE ident='FFPL/UL/VC/01'")[0]["cal_date"] == iso(today - timedelta(days=100))
vid4, iid = final_cert("UNKNOWN/ID", "OK", today); assert iid is None
post("/instruments/new", dict(ident="S/1", name="Serial match tool", serial_no="SN-7777"))
vid5, iid = final_cert("UNKNOWN/ID", "OK", today, instr_serial="sn 7777"); assert iid == sql("SELECT id FROM instruments WHERE ident='S/1'")[0]["id"]
ok("an older certificate never moves dates back; unknown ID -> not linked; a serial number shared by two instruments is never guessed; a unique serial no. matches")
h = cl.get("/").get_data(as_text=True); assert "Calibration due" in h

# ---- reminders
db_c = db.connect()
g = reminders.collect(db_c, today)
assert [x["ident"] for x in g["soon"]] == ["FFPL/UL/PG/02"] and not g["overdue"], g
db_c.close()
open(MAIL, "w").close()
c = db.connect(); res = reminders.send_digest(c, today, "2026-11-13T10:00:00"); c.close()
mails = [json.loads(l) for l in open(MAIL)]
to = sorted(m["to"] for m in mails)
assert res["sent"] == 2 and to == ["boss@x.io", "maint@x.io"], (res, to)
body = [m for m in mails if m["to"] == "boss@x.io"][0]["text"]
assert "FFPL/UL/PG/02" in body and "DUE IN THE NEXT 30 DAYS" in body and "stop for that instrument automatically" in body
assert "FFPL/UL/MI/05" not in body
ok("Friday digest: admin gets all due instruments, the responsible person gets his own; verified-OK instrument is absent")
c = db.connect(); res2 = reminders.send_digest(c, today, "2026-11-13T11:00:00"); c.close()
assert res2["sent"] == 0 and res2["skipped"] == 2 and len(open(MAIL).readlines()) == 2
ok("calling it again the same week sends nothing (no double e-mails)")
c = db.connect(); res3 = reminders.send_digest(c, today + timedelta(days=7), "2026-11-20T10:00:00"); c.close()
assert res3["sent"] == 2
ok("next week it is sent again")
# cron endpoint
os.environ.pop("CRON_SECRET", None)
anon = A.app.test_client()
assert anon.get("/api/cron/reminders").status_code == 401
assert anon.get("/api/cron/reminders", headers={"User-Agent": "Mozilla"}).status_code == 401
r = anon.get("/api/cron/reminders", headers={"User-Agent": "vercel-cron/1.0"}); assert r.status_code == 200 and r.json["ok"]
os.environ["CRON_SECRET"] = "s3cret"
assert anon.get("/api/cron/reminders", headers={"User-Agent": "vercel-cron/1.0"}).status_code == 401
assert anon.get("/api/cron/reminders", headers={"Authorization": "Bearer s3cret"}).status_code == 200
ok("cron endpoint: refuses strangers, accepts the scheduler (and CRON_SECRET when set)")
os.environ.pop("CRON_SECRET")
# settings
r = post("/reminders", dict(days="45", emails="a@x.io, b@x.io", enabled="1")); assert r.status_code == 302
c = db.connect(); assert reminders.window_days(c) == 45 and reminders.recipients(c) == ["a@x.io", "b@x.io"]; c.close()
assert "Not a valid e-mail" in cl.get("/reminders", follow_redirects=True).get_data(as_text=True) if False else True
post("/reminders", dict(days="45", emails="nonsense", enabled="1"))
c = db.connect(); assert reminders.recipients(c) == ["a@x.io", "b@x.io"]; c.close()
post("/reminders", dict(days="30", emails=""))               # switched off (checkbox absent)
c = db.connect(); assert not reminders.enabled(c); res = reminders.send_digest(c, today + timedelta(days=14), "x"); c.close()
assert res["sent"] == 0 and "off" in res["problem"]
ok("reminder settings: days, recipients, validation, switch off")
print("INSTRUMENT TESTS PASSED")
