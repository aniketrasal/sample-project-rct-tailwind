"""Full flow through the Flask app. usage: test_e2e.py <sqlite|pg> <sample_dir>"""
import os, re, sys, json, tempfile
mode, S = sys.argv[1], sys.argv[2]
ROOT = "/home/claude/cert-verifier-vercel"
sys.path.insert(0, ROOT)
os.environ["CERTV_MAIL_FILE"] = tempfile.mkdtemp() + "/mail.jsonl"; os.environ["SECRET_KEY"] = "k" * 40; os.environ["CERTV_SECURE_COOKIES"] = "0"
if mode == "pg":
    sys.path.insert(0, ROOT + "/tests/fakepsycopg")
    os.environ["DATABASE_URL"] = "postgres://pgtest@127.0.0.1:5433/certv_e2e"
else:
    os.environ["CERTV_SQLITE"] = tempfile.mkdtemp() + "/t.db"
import app as A, db
app = A.app; app.config["TESTING"] = False; app.config["PROPAGATE_EXCEPTIONS"] = False
cl = app.test_client()
def tok(html): return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)
def csrf(): return tok(cl.get("/account").get_data(as_text=True))
def post(u, data=None, **k):
    d = dict(data or {}); d["_csrf"] = csrf(); return cl.post(u, data=d, follow_redirects=True, **k)
def sql(q, *a): c = db.connect(); r = c.execute(q, a).fetchall(); c.close(); return r

assert cl.get("/").status_code == 302 and "/login" in cl.get("/").headers["Location"]
assert cl.get("/healthz").get_json()["status"] == "ok"
def login(c, u, p, **k):
    t = tok(c.get("/login").get_data(as_text=True)); return c.post("/login", data={"username": u, "password": p, "_csrf": t}, **k)
r = login(cl, "admin", "nope", follow_redirects=True); assert b"Wrong username" in r.data
r = login(cl, "ADMIN", "admin", follow_redirects=True); assert b"Create your account" in r.data     # first login = set-up
t = tok(r.get_data(as_text=True))
cl.post("/setup", data={"_csrf": t, "full_name": "Test Owner", "username": "owner", "email": "o@example.com", "password": "test-pass-123", "password2": "test-pass-123"})
code = re.search(r"code is (\d{6})", [json.loads(l) for l in open(os.environ["CERTV_MAIL_FILE"])][-1]["text"]).group(1)
r = cl.post("/setup/verify", data={"_csrf": t, "code": code}, follow_redirects=True); assert b"Calibration certificates" in r.data
for u in ["/", "/history", "/labs", "/labs/new", "/instruments", "/settings/environment", "/users", "/account", "/more", "/verify/new"]:
    assert cl.get(u).status_code == 200, u
assert cl.post("/instruments", data={"ident": "x", "range_max": "1"}).status_code == 400        # CSRF
print("ok  login, throttle-free pages render, CSRF enforced")

# 1) browser-OCR upload of the photo (OCR text produced by real tesseract), unknown lab
H = {"X-Requested-With": "fetch"}
def upload(photo=True):
    f = open(f"{S}/sample_photo.jpg", "rb") if photo else open(f"{S}/sample_cert.pdf", "rb")
    d = {"_csrf": csrf(), "file": (f, "cert.jpg" if photo else "cert.pdf")}
    if photo: d.update(ocr_text=open(f"{S}/ocr_full.txt").read(), right_text=open(f"{S}/ocr_right.txt").read(),
                       left_text=open(f"{S}/ocr_left.txt").read(), sig_ink="0.03")
    return cl.post("/verify/new", data=d, content_type="multipart/form-data", headers=H)
r = upload(True); j = r.get_json(); assert r.status_code == 200 and j["ok"], j
vid = int(re.search(r"/verify/(\d+)/edit", j["url"]).group(1))
d = json.loads(sql("SELECT data_json FROM verifications WHERE id=?", vid)[0]["data_json"])
for k, want in [("cert_no", "CGIL/2026/0611/C-004"), ("nabl_no", "CC-2656"), ("customer_name", "Fleetguard"), ("cal_date", "11/06/2026"),
                ("instr_range", "0 To 200"), ("k_factor", "2"), ("acc_empe", "20, 30, 40, 50"), ("approver_signature", "on")]:
    assert want in d.get(k, ""), (k, d.get(k))
TRUTH = {"lab_name": "Caliber Gauges And Instruments Laboratory LLP", "receipt_date": "11/06/2026", "cal_date": "11/06/2026", "due_date": "10/06/2027",
         "issue_date": "13/06/2026", "instr_ident": "FFPL\\UL\\LV\\02", "instr_serial": "0006553", "instr_make": "Mitutoyo", "cert_no": "CGIL/2026/0611/C-004",
         "customer_name": "Fleetguard Filters Pvt. Ltd.", "env_temp": "20.1", "env_humidity": "52", "unc_value": "16", "k_factor": "2", "approver_name": "Bhagyashree Raskar"}
wrong = {k: d.get(k, "") for k, v in TRUTH.items() if d.get(k, "") != v}
print("ok  photo upload parsed from real OCR text. Fields the reader got wrong (a person fixes these on the review page):", wrong or "none")
bad_dates = [k for k in ("receipt_date", "cal_date", "due_date", "issue_date") if d.get(k) and not A.rules.pdate(d[k])]
if bad_dates: assert all(f'name="{k}"' in cl.get(j["url"]).get_data(as_text=True) for k in bad_dates)
page = cl.get(j["url"]).get_data(as_text=True)
for k in bad_dates: assert re.search(r'class="miss"><label>[^<]*</label><input type="text" name="%s"' % k, page), k
f = sql("SELECT mime, length(data) AS n FROM verification_files WHERE verification_id=?", vid)[0]; assert f["mime"] == "image/jpeg" and f["n"] > 10000
assert cl.get(f"/verify/{vid}/file").data[:3] == b"\xff\xd8\xff"
form = {k: v for k, v in d.items() if isinstance(v, str)}
form.update(TRUTH)          # the human correction
html = post(f"/verify/{vid}/edit", form).get_data(as_text=True)
assert "This lab is not added in the lab list" in html and "labSheet" in html
r1 = sql("SELECT * FROM check_results WHERE verification_id=? AND code='1'", vid)[0]; assert r1["status"] == "N/A" and r1["pending"]
print("ok  unknown lab CC-2656 -> pop-up, rule 1 pending")

# 2) add lab from pop-up (no scope any more)
html = post("/labs/quick-add", {"vid": vid, "nabl_no": "cc 2656", "name": "Caliber Gauges And Instruments Laboratory LLP", "valid_from": "2024-03-01", "valid_to": "2027-02-28", "address": "Pune"}).get_data(as_text=True)
assert "scope" not in html.lower().replace("scoped", "")
post(f"/verify/{vid}/rerun")
rows = {r["code"]: r for r in sql("SELECT * FROM check_results WHERE verification_id=?", vid)}
for c in A.rules.ORDER: print(f"     {c:>3} {rows[c]['status']:7} {rows[c]['reason'][:92]}")
assert rows["1"]["status"] == "OK" and rows["2"]["status"] == "OK" and rows["X1"]["status"] == "OK" and rows["6"]["status"] == "OK"
assert rows["3c"]["status"] == "OK"   # page 1 of 1 identifies the end of the certificate
assert sql("SELECT result FROM verifications WHERE id=?", vid)[0]["result"] == "PENDING"
print("ok  lab added -> rules 1, 2 OK; 3c NOT OK (no end marker) -> overall NOT OK")

# 3) review, sign off, change after sign-off, back to automatic
post(f"/verify/{vid}/override", {"code": "3c", "new_status": "OK", "reason": ""}); assert not sql("SELECT * FROM change_log")
for st, why in [("NOT OK", "Second look"), ("OK", "QA accepted")]:
    post(f"/verify/{vid}/override", {"code": "3c", "new_status": st, "reason": why})
for c in ("3b", "3i", "3j", "3m"):
    if rows[c]["status"] != "OK": post(f"/verify/{vid}/override", {"code": c, "new_status": "OK", "reason": "OCR missed it, checked on paper"})
post(f"/verify/{vid}/finalize", {"verifier_name": "", "verifier_remark": ""}); assert sql("SELECT status FROM verifications WHERE id=?", vid)[0]["status"] != "final"
post(f"/verify/{vid}/finalize", {"verifier_name": "A. Rasal", "verifier_remark": "Accepted"})
v = sql("SELECT * FROM verifications WHERE id=?", vid)[0]
nok = [c for c, r in {r["code"]: r for r in sql("SELECT * FROM check_results WHERE verification_id=?", vid)}.items() if r["status"] != "OK"]
assert v["status"] == "final" and v["result"] == "OK" and not nok, (v["status"], v["result"], nok)
log = sql("SELECT * FROM change_log WHERE verification_id=? ORDER BY id", vid); assert log[0]["old_status"] == "OK" and log[0]["new_status"].startswith("NOT OK")
open(f"{S}/report_{mode}_ok.pdf", "wb").write(cl.get(f"/verify/{vid}/report.pdf").data)
post(f"/verify/{vid}/override", {"code": "3j", "new_status": "NOT OK", "reason": "Statement missing"}); assert sql("SELECT result FROM verifications WHERE id=?", vid)[0]["result"] == "NOT OK"
open(f"{S}/report_{mode}_notok.pdf", "wb").write(cl.get(f"/verify/{vid}/report.pdf").data)
post(f"/verify/{vid}/override", {"code": "3j", "new_status": "AUTO", "reason": "mistake"}); assert sql("SELECT result FROM verifications WHERE id=?", vid)[0]["result"] == "OK"
print("ok  review log, sign-off needs name+remark, OK->NOT OK->OK after sign-off, report PDFs written; log entries:", len(sql("SELECT * FROM change_log")))

# 4) PDF upload (text layer), scanned-PDF handling, bad files, size
r = upload(False); j = r.get_json(); assert j["ok"]; v2 = int(re.search(r"/verify/(\d+)", j["url"]).group(1))
d2 = json.loads(sql("SELECT data_json FROM verifications WHERE id=?", v2)[0]["data_json"]); assert d2["approver_name"] == "Bhagyashree Raskar" and d2["approver_signature"] == "on" and d2["cal_date"] == "11/06/2026"
print("ok  PDF upload read directly (incl. signatory + signature)")
import io, zlib
blank = b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj 3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF"
r = cl.post("/verify/new", data={"_csrf": csrf(), "file": (io.BytesIO(blank), "scan.pdf")}, content_type="multipart/form-data", headers=H); assert r.status_code == 422 and r.get_json()["scanned_pdf"]
r = cl.post("/verify/new", data={"_csrf": csrf(), "manual": "1", "file": (io.BytesIO(blank), "scan.pdf")}, content_type="multipart/form-data", headers=H); assert r.get_json()["ok"]
r = cl.post("/verify/new", data={"_csrf": csrf(), "file": (io.BytesIO(b"hello"), "x.pdf")}, content_type="multipart/form-data", headers=H); assert r.status_code == 400 and "Unsupported" in r.get_json()["error"]
r = cl.post("/verify/new", data={"_csrf": csrf(), "file": (io.BytesIO(b"%PDF-" + b"0" * 5_000_000), "big.pdf")}, content_type="multipart/form-data", headers=H); assert r.status_code == 413, r.status_code
r = cl.post("/verify/new", data={"_csrf": csrf(), "file": (io.BytesIO(b"\xff\xd8\xff" + b"0" * 100), "p.jpg")}, content_type="multipart/form-data", headers=H); assert r.get_json()["ok"]   # OCR failed in browser -> manual
print("ok  scanned PDF, manual entry, wrong type, >4.5 MB, photo without OCR text all handled")

# 5) other pages, history filters, users, errors
assert b"CGIL/2026" in cl.get("/history?q=cgil").data and b"No verifications found" in cl.get("/history?q=zzzz").data
assert b"Instruments" in post("/instruments", {"ident": "FFPL\\UL\\LV\\02", "name": "Vernier", "range_min": "0", "range_max": "200", "unit": "mm"}).data
post("/users", {"username": "Priya", "full_name": "Priya S", "password": "longpass1", "role": "user"}); assert sql("SELECT role FROM users WHERE username='priya'")[0]["role"] == "user"
post("/settings/environment", {"nom_dimensional": "20", "tol_dimensional": "2", "rh_dimensional": "", "nom_gdt": "", "tol_gdt": "", "rh_gdt": "", "nom_electrical": "25", "tol_electrical": "4", "rh_electrical": "70", "nom_thermal": "25", "tol_thermal": "4", "rh_thermal": "70"})
assert cl.get("/verify/99999").status_code == 404 and b"does not exist" in cl.get("/verify/99999").data
c2 = app.test_client(); login(c2, "priya", "longpass1"); assert c2.get("/users").status_code == 403
lid = sql("SELECT id FROM labs")[0]["id"]
assert b"Delete lab" not in c2.get("/labs/%d" % lid).data
r = cl.get(f"/verify/{vid}/report.pdf"); assert r.data[:4] == b"%PDF"
for u in [f"/verify/{vid}", f"/verify/{v2}/edit", f"/labs/{lid}"]: assert cl.get(u).status_code == 200, u
n = sql("SELECT COUNT(*) AS n FROM verifications")[0]["n"]; post(f"/verify/{v2}/delete"); assert sql("SELECT COUNT(*) AS n FROM verifications")[0]["n"] == n - 1
for i in range(9): login(app.test_client(), "priya", "x")
assert login(app.test_client(), "priya", "longpass1").status_code == 429
print("ok  history, users/roles, 404/403 pages, delete, login lockout")
print(f"E2E PASSED on {db.backend()}")
