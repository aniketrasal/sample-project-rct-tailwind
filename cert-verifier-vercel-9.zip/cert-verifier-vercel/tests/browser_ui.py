"""Real Chrome at phone size: screenshots + the actual upload JavaScript (OCR library mocked)."""
import sys, re, json
from playwright.sync_api import sync_playwright
S = sys.argv[1]; B = "http://127.0.0.1:5066"
OCR = open(f"{S}/ocr_full.txt").read(); RIGHT = open(f"{S}/ocr_right.txt").read(); LEFT = open(f"{S}/ocr_left.txt").read()
FAKE_TESS = """window.Tesseract={createWorker:async function(l,o,opt){ return {setParameters:async()=>{}, terminate:async()=>{},
  recognize:async function(img){ if(opt&&opt.logger){opt.logger({status:'recognizing text',progress:.5});opt.logger({status:'recognizing text',progress:1});}
   const full = img.width>1500; const words = full ? [{text:'Approved',bbox:{x0:img.width*.7,y0:img.height*.9,x1:img.width*.78,y1:img.height*.915}},{text:'Calibrated',bbox:{x0:img.width*.05,y0:img.height*.9,x1:img.width*.12,y1:img.height*.915}}] : [];
   return {data:{text: full ? %s : %s, words: words}}; }}}};""" % (json.dumps(OCR), json.dumps(RIGHT))
errors = []
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    pg = ctx.new_page(); pg.on("pageerror", lambda e: errors.append(str(e))); pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    pg.goto(B + "/login"); pg.screenshot(path=f"{S}/ui_login.png")
    pg.fill("#u", "admin"); pg.fill("#p", "test-pass-123"); pg.click("button.btn"); pg.wait_for_url("**/")
    pg.goto(B + "/"); pg.screenshot(path=f"{S}/ui_home_empty.png")
    pg.goto(B + "/labs"); pg.screenshot(path=f"{S}/ui_labs_empty.png")
    pg.goto(B + "/verify/new"); pg.screenshot(path=f"{S}/ui_upload.png")
    # --- real upload JS: photo, OCR library replaced by a stub that returns real Tesseract output
    pg.route("**/tesseract.min.js", lambda r: r.fulfill(status=200, content_type="application/javascript", body=FAKE_TESS))
    pg.set_input_files("#fil", f"{S}/sample_photo.jpg")
    pg.wait_for_url("**/edit", timeout=30000); pg.wait_for_selector("form#editform")
    print("photo flow ->", pg.url); pg.screenshot(path=f"{S}/ui_edit.png")
    amber = pg.locator(".miss input").evaluate_all("els=>els.map(e=>e.name)"); print("amber fields:", amber)
    print("receipt_date value:", pg.input_value("input[name=receipt_date]"))
    pg.fill("input[name=receipt_date]", "11/06/2026")
    pg.screenshot(path=f"{S}/ui_edit_full.png", full_page=True)
    pg.click(".actionbar button"); pg.wait_for_url(re.compile(r".*/verify/\d+$")); pg.wait_for_selector("#labSheet[open] .sheet")
    print("lab pop-up open:", pg.locator("#labSheet").evaluate("d=>d.open")); pg.wait_for_timeout(500); pg.screenshot(path=f"{S}/ui_labpopup.png")
    pg.fill("#labSheet input[name=valid_from]", "2024-03-01"); pg.fill("#labSheet input[name=valid_to]", "2027-02-28"); pg.click("#labSheet button.btn")
    pg.wait_for_selector(".hero")
    pg.goto(B + "/labs"); pg.screenshot(path=f"{S}/ui_labs.png", full_page=True)
    pg.goto(B + "/history"); pg.click(".item a.grow"); pg.wait_for_selector(".hero"); pg.click("button:has-text('Re-run')"); pg.wait_for_selector(".hero")
    pg.screenshot(path=f"{S}/ui_result_notok.png")
    print("filter default:", pg.locator(".chip.on").inner_text().strip(), "| visible rules:", pg.locator(".rule:visible").count())
    pg.click("[data-filter=all]"); print("all rules:", pg.locator(".rule:visible").count()); pg.click("[data-filter=attn]")
    pg.locator("#rule-5 button[data-review]").click(); pg.wait_for_selector("#reviewSheet[open] .sheet"); pg.wait_for_timeout(500); pg.screenshot(path=f"{S}/ui_review.png")
    pg.fill("#rv_reason", "Single page certificate, accepted"); pg.click("#reviewSheet button.btn"); pg.wait_for_selector(".hero")
    print("rule 5 after review:", pg.locator("#rule-5 .badge").inner_text())
    # sign off
    pg.fill("input[name=verifier_remark]", "Accepted"); pg.click("#signoff button.btn"); pg.wait_for_selector(".hero")
    print("result:", pg.locator(".hero .verdict").inner_text())
    pg.screenshot(path=f"{S}/ui_result_ok.png"); pg.screenshot(path=f"{S}/ui_result_full.png", full_page=True)
    pg.goto(B + "/"); pg.screenshot(path=f"{S}/ui_home.png"); pg.goto(B + "/more"); pg.screenshot(path=f"{S}/ui_more.png")
    # no sideways scroll on any page at phone width
    for u in ["/", "/history", "/labs", "/instruments", "/more", "/verify/new", "/users", "/settings/environment", "/account"]:
        pg.goto(B + u); w = pg.evaluate("document.documentElement.scrollWidth"); assert w <= 390, (u, w)
    print("no horizontal scroll on 9 pages at 390px")
    # PDF upload through the same JS (no OCR needed)
    pg.goto(B + "/verify/new"); pg.set_input_files("#fil", f"{S}/sample_cert.pdf"); pg.wait_for_url("**/edit", timeout=20000)
    print("pdf flow ->", pg.url, "| fields filled:", pg.locator("input[name=cert_no]").input_value())
    # scanned PDF message
    open(f"{S}/scan.pdf", "wb").write(b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj 3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF")
    pg.goto(B + "/verify/new"); pg.set_input_files("#fil", f"{S}/scan.pdf"); pg.wait_for_selector("#problem:not(.hidden)"); print("scanned pdf message:", pg.locator("#ptext").inner_text()[:70]); pg.screenshot(path=f"{S}/ui_scanned.png")
    # OCR library cannot load (offline): upload must still work
    pg.unroute("**/tesseract.min.js"); pg.route("**/tesseract.min.js", lambda r: r.abort())
    pg.goto(B + "/verify/new"); pg.set_input_files("#fil", f"{S}/sample_photo.jpg"); pg.wait_for_url("**/edit", timeout=30000); print("reader blocked -> still reaches review page:", pg.url)
    # desktop
    d = b.new_context(viewport={"width": 1280, "height": 800}).new_page(); d.goto(B + "/login"); d.fill("#u", "admin"); d.fill("#p", "test-pass-123"); d.click("button.btn"); d.wait_for_url("**/")
    d.goto(B + "/verify/1"); d.wait_for_selector(".hero"); d.screenshot(path=f"{S}/ui_desktop_result.png"); d.goto(B + "/"); d.screenshot(path=f"{S}/ui_desktop_home.png")
    print("tab bar hidden on desktop:", not d.locator(".tabbar").is_visible(), "| top nav visible:", d.locator(".topnav").is_visible())
    b.close()
real = [e for e in errors if "tesseract" not in e.lower() and "Failed to load resource" not in e and "ERR_FAILED" not in e]
print("JS errors:", real or "none")
