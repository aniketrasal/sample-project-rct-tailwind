"""Calibration due reminders: one e-mail digest every Friday.

Who is reminded:  the people on the Reminders page (default: every user with a verified e-mail) get every instrument;
                  an instrument's own 'Responsible Email' gets its own instruments too.
What is listed:   instruments overdue or due within N days (default 30), instruments marked 'Send for Calibration'
                  that are still waiting for a certificate, and instruments whose last certificate was NOT OK.
When it stops:    when a certificate for the instrument is verified OK, its due date moves to the next cycle,
                  its 'Send for Calibration' mark is cleared and it drops out of the list - nothing to switch off.
Safety:           one digest per recipient per week (reminder_log), so repeated calls never send twice.
"""
import os
from datetime import timedelta

import instruments as I
import mailer

DEFAULT_DAYS = 30


def get_setting(c, key, default=""):
    r = c.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def set_setting(c, key, value):
    c.upsert("app_settings", ["key"], key=key, value=str(value))


def window_days(c):
    try:
        return max(1, min(180, int(get_setting(c, "reminder_days", DEFAULT_DAYS))))
    except ValueError:
        return DEFAULT_DAYS


def enabled(c):
    return get_setting(c, "reminder_enabled", "1") == "1"


def recipients(c):
    """Addresses that get the full digest."""
    raw = get_setting(c, "reminder_emails", "")
    mails = [m.strip() for m in raw.replace(";", ",").replace("\n", ",").split(",") if m.strip()]
    if not mails:
        mails = [r["email"] for r in c.execute(
            "SELECT email FROM users WHERE email IS NOT NULL AND email<>'' AND email_verified=1").fetchall()]
    seen, out = set(), []
    for m in mails:
        if m.lower() not in seen and I.EMAIL_RE.match(m):
            seen.add(m.lower())
            out.append(m)
    return out


def week_key(today):
    """The Friday of the current Monday-Sunday week: one digest per recipient per week."""
    return (today - timedelta(days=today.weekday()) + timedelta(days=4)).isoformat()


def collect(c, today, days=None):
    days = days or window_days(c)
    groups = {"overdue": [], "soon": [], "sent": [], "nok": []}
    for r in c.execute("SELECT * FROM instruments ORDER BY due_date, ident").fetchall():
        r = dict(r)
        if not I.needs_reminder(r, today, days):
            continue
        st = I.status_of(r, today, days)
        r["_days"] = st["days"]
        if r.get("sent_for_cal"):
            groups["sent"].append(r)
        elif (r.get("last_result") or "") == "NOT OK":
            groups["nok"].append(r)
        elif st["key"] == "overdue":
            groups["overdue"].append(r)
        else:
            groups["soon"].append(r)
    return groups


def _line(r):
    due = I.dmy(r.get("due_date")) or "no due date"
    bits = [r["ident"], r.get("name") or r.get("category") or ""]
    txt = "  - " + "  |  ".join(b for b in bits if b)
    extra = f"due {due}" + (f" ({I.days_text(r['_days'])})" if r.get("_days") is not None else "")
    return f"{txt}\n      {extra}" + (f"  |  S.No. {r['serial_no']}" if r.get("serial_no") else "")


def build_text(groups, today, days, app_url=""):
    n = sum(len(v) for v in groups.values())
    out = [f"Calibration reminder - {today.strftime('%d %b %Y')}", "",
           f"{n} instrument{'s' if n != 1 else ''} need attention (due within {days} days or overdue).", ""]
    parts = [("OVERDUE", groups["overdue"]), (f"DUE IN THE NEXT {days} DAYS", groups["soon"]),
             ("SENT FOR CALIBRATION - waiting for the certificate", groups["sent"]),
             ("LAST CERTIFICATE WAS NOT OK - calibrate again", groups["nok"])]
    for title, rows in parts:
        if rows:
            out += [f"{title} ({len(rows)})"] + [_line(r) for r in rows] + [""]
    out += ["What to do: send the instrument for calibration, then upload and verify its certificate in the app.",
            "Once the certificate is verified OK these reminders stop for that instrument automatically."]
    if app_url:
        out += ["", f"Open the list: {app_url.rstrip('/')}/instruments?status=attention"]
    out += ["", "Cert Verifier"]
    return "\n".join(out)


def app_url():
    u = os.environ.get("APP_URL", "").strip()
    if not u:
        u = os.environ.get("VERCEL_PROJECT_PRODUCTION_URL", "").strip() or os.environ.get("VERCEL_URL", "").strip()
        if u and not u.startswith("http"):
            u = "https://" + u
    return u


def send_digest(c, today, now_iso, force=False, kind="weekly", only_to=None, base_url=""):
    """Send this week's digest. Returns dict(sent, skipped, failed, items, problem)."""
    res = dict(sent=0, skipped=0, failed=0, items=0, problem="", recipients=[])
    if not enabled(c) and not force:
        res["problem"] = "Reminders are switched off."
        return res
    if not mailer.configured():
        res["problem"] = "E-mail sending is not set up (SMTP_* or RESEND_API_KEY)."
        return res
    days, wk = window_days(c), week_key(today)
    groups = collect(c, today, days)
    allrows = [r for g in groups.values() for r in g]
    res["items"] = len(allrows)
    base = base_url or app_url()
    plan = {}
    for m in recipients(c):
        plan[m.lower()] = (m, groups)
    # a responsible person gets his own instruments
    own = {}
    for r in allrows:
        e = (r.get("owner_email") or "").strip()
        if e and I.EMAIL_RE.match(e) and e.lower() not in plan:
            own.setdefault(e.lower(), (e, {"overdue": [], "soon": [], "sent": [], "nok": []}))
            key = "sent" if r.get("sent_for_cal") else ("nok" if (r.get("last_result") or "") == "NOT OK" else
                                                          ("overdue" if (r["_days"] or 0) < 0 else "soon"))
            own[e.lower()][1][key].append(r)
    plan.update(own)
    if only_to:
        plan = {k: v for k, v in plan.items() if k == only_to.lower()}
    for key, (mail, grp) in plan.items():
        n = sum(len(v) for v in grp.values())
        res["recipients"].append(mail)
        if n == 0:
            res["skipped"] += 1
            continue
        if kind == "weekly" and not force and c.execute(
                "SELECT 1 FROM reminder_log WHERE week_key=? AND lower(to_email)=? AND ok=1 AND kind='weekly'",
                (wk, key)).fetchone():
            res["skipped"] += 1
            continue
        subject = f"Calibration reminder: {n} instrument{'s' if n != 1 else ''} due or overdue"
        ok, err = mailer.send(mail, subject, build_text(grp, today, days, base))
        c.insert("reminder_log", sent_at=now_iso, week_key=wk, to_email=mail, items=n, ok=1 if ok else 0,
                 error=(err or "")[:300], kind=kind)
        res["sent" if ok else "failed"] += 1
        if not ok:
            res["problem"] = err
    c.commit()
    return res
