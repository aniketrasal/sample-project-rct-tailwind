# Cert Verifier - calibration certificate checker (IN REL 002) - Vercel edition

Mobile-friendly web app. Upload a photo or PDF of a calibration certificate, review what was read, and get OK / NOT OK
against the 20 rules of IN REL 002 (plus the EMPE/SMPE permissible-error check), with an editable, logged review
and a PDF report with a QR code.

**Deploy:** read `DEPLOY.md`. **Settings needed:** `SECRET_KEY`, the `SMTP_*` e-mail settings, and a Postgres `DATABASE_URL` (Neon). First sign-in is `admin` / `admin`, then you create your own login.
Missing settings show a "Setup needed" page that says exactly what to add; they never crash the site.

Local try (no Postgres needed, uses a SQLite file): `pip install -r requirements.txt` then
`CERTV_SECURE_COOKIES=0 CERTV_SQLITE=./data/local.db CERTV_MAIL_FILE=./data/mail.jsonl python3 app.py` (codes are written to `data/mail.jsonl` instead of being sent) -> http://127.0.0.1:5000

Tests: `tests/` (rules, database on Postgres + SQLite, full flow, real-browser mobile test). Not deployed (.vercelignore).


## Instruments, Excel import and reminders
- **Instruments** menu: IMTE ID, name, category, make, serial no., instrument range, operating range (used by rule 4), grade and size (optional), dates of receipt / calibration / due / issue, frequency, responsible e-mail. Search, status and category filters, sorting.
- **Excel**: download the template, fill it (or use your own sheet with similar headings), upload, check the preview, confirm. Existing IMTE IDs are updated, blank cells keep old values.
- **Certificates**: when a certificate is signed off the app finds the instrument by IMTE ID (or a unique serial number), stores the certificate and its verification report with it, and - if the result is OK - updates the calibration dates.
- **Reminders**: Friday e-mail for instruments overdue or due within 30 days (changeable). "Send for Calibration" is the only manual status. See DEPLOY.md.
- **Lab scope** was removed: rule 2 now checks that the lab's accreditation was valid on the calibration date.
