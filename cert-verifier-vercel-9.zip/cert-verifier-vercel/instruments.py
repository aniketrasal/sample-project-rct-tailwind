"""Instrument register: field cleaning, status, categories, Excel import / export.

Pure functions (no Flask, no database) so they can be tested on their own.
Dates are stored as ISO text (YYYY-MM-DD) so they sort correctly in both SQLite and Postgres.
"""
import calendar
import io
import re
from datetime import date, datetime, timedelta

SENT_LABEL = "Send for Calibration"

# the user-facing columns, in the order of the form / the Excel template
COLUMNS = [
    # key, Excel heading, aliases (lower case, no punctuation)
    ("ident", "IMTE ID", ["imteid", "imte", "id", "identification", "identificationno", "instrumentid", "idno", "tagno", "equipmentid"]),
    ("name", "Name", ["name", "instrumentname", "description", "instrument", "equipmentname", "nameofinstrument"]),
    ("category", "Category", ["category", "type", "instrumenttype", "group", "typeofinstrument"]),
    ("mfr", "Mfr.", ["mfr", "make", "manufacturer", "mfrname", "mfg", "makemodel"]),
    ("serial_no", "S. No.", ["sno", "serialno", "serial", "srno", "mfrsno", "mfrserialno", "serialnumber", "slno"]),
    ("instr_range", "Instrument Range", ["instrumentrange", "range", "capacity", "measuringrange", "fullrange"]),
    ("op_range", "Operating Range", ["operatingrange", "usedrange", "workingrange", "rangeinuse", "operatingrangeused"]),
    ("grade", "Grade", ["grade", "class", "accuracyclass"]),
    ("size", "Size", ["size", "dimensions", "dimension"]),
    ("receipt_date", "Date of Receipt", ["dateofreceipt", "receiptdate", "receivedon", "receiveddate", "datereceived"]),
    ("cal_date", "Date of Calibration", ["dateofcalibration", "calibrationdate", "caldate", "calibrationon", "lastcalibrationdate", "lastcalibrated"]),
    ("due_date", "Calibration Due", ["calibrationdue", "duedate", "calibrationduedate", "nextdue", "duedateofcalibration", "nextcalibrationdate", "caldue", "due"]),
    ("issue_date", "Issue Date of Calibration", ["issuedateofcalibration", "issuedate", "dateofissue", "certificateissuedate", "issueddate", "issue"]),
    ("freq_months", "Frequency (months)", ["frequencymonths", "frequency", "calibrationfrequency", "intervalmonths", "interval", "calfrequency", "frequencyinmonths"]),
    ("owner_email", "Responsible Email", ["responsibleemail", "email", "owneremail", "responsible", "mail", "emailid"]),
    ("notes", "Notes", ["notes", "remarks", "remark", "comment", "comments"]),
]
KEYS = [c[0] for c in COLUMNS]
DATE_KEYS = ("receipt_date", "cal_date", "due_date", "issue_date")
MAX_LEN = {"ident": 60, "name": 120, "category": 60, "mfr": 80, "serial_no": 80, "instr_range": 60, "op_range": 60,
           "grade": 20, "size": 40, "owner_email": 120, "notes": 400}

CATEGORY_HINTS = [
    ("Vernier Caliper", ["vernier", "caliper", "calliper", "digimatic caliper"]),
    ("Micrometer", ["micrometer", "micrometre", "screw gauge"]),
    ("Dial Gauge", ["dial gauge", "dial indicator", "dial test", "plunger dial", "lever dial"]),
    ("Height Gauge", ["height gauge", "height gage"]),
    ("Depth Gauge", ["depth gauge", "depth gage", "depth micrometer"]),
    ("Pressure Gauge", ["pressure gauge", "pressure gage", "manometer", "vacuum gauge"]),
    ("V Block", ["v block", "v-block", "vee block"]),
    ("Surface Plate", ["surface plate"]),
    ("Plug Gauge", ["plug gauge", "plug gage", "go no go", "go/no go"]),
    ("Ring Gauge", ["ring gauge", "ring gage"]),
    ("Thread Gauge", ["thread gauge", "thread plug", "thread ring", "pitch gauge"]),
    ("Feeler Gauge", ["feeler"]),
    ("Slip Gauge / Gauge Block", ["slip gauge", "gauge block", "gage block"]),
    ("Radius Gauge", ["radius gauge", "radius gage"]),
    ("Torque Wrench", ["torque"]),
    ("Weighing Balance", ["balance", "weighing", "weight scale", "weigh scale"]),
    ("Thermometer", ["thermometer", "temperature", "thermocouple", "rtd", "data logger", "datalogger"]),
    ("Multimeter", ["multimeter", "multi meter", "clamp meter", "voltmeter", "ammeter"]),
    ("Hardness Tester", ["hardness"]),
    ("Test Weight", ["test weight", "calibration weight", "standard weight"]),
    ("Timer / Stopwatch", ["stopwatch", "stop watch", "timer", "tachometer"]),
    ("Gauge (other)", ["gauge", "gage"]),
]


# ------------------------------------------------------------------ small helpers
def norm_key(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def norm_id(s):
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def guess_category(name):
    n = (name or "").lower()
    for cat, words in CATEGORY_HINTS:
        if any(w in n for w in words):
            return cat
    return ""


_MONTHS = {m.lower(): i for i, m in enumerate(calendar.month_abbr) if m}
_MONTHS.update({m.lower(): i for i, m in enumerate(calendar.month_name) if m})


def parse_date(v):
    """Any reasonable date (text, datetime, Excel serial) -> 'YYYY-MM-DD' or ''. Never raises."""
    if v is None or v == "":
        return ""
    try:
        if isinstance(v, datetime):
            return v.date().isoformat()
        if isinstance(v, date):
            return v.isoformat()
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            if 20000 < float(v) < 80000:                     # Excel serial day number
                return (date(1899, 12, 30) + timedelta(days=int(v))).isoformat()
            return ""
        s = str(v).strip()
        if not s:
            return ""
        if re.fullmatch(r"\d{5}(\.0+)?", s) and 20000 < float(s) < 80000:
            return (date(1899, 12, 30) + timedelta(days=int(float(s)))).isoformat()
        s = s.split(" ")[0] if re.match(r"^\d{4}-\d{2}-\d{2}[ T]", s) else s
        m = re.fullmatch(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", s)
        if m:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        m = re.fullmatch(r"(\d{1,2})[-/. ](\d{1,2})[-/. ](\d{2}|\d{4})", s)
        if m:
            y = int(m.group(3))
            y += 2000 if y < 100 else 0
            return date(y, int(m.group(2)), int(m.group(1))).isoformat()        # day first (Indian format)
        m = re.fullmatch(r"(\d{1,2})[-/. ]*([A-Za-z]{3,9})[-/., ]*(\d{2}|\d{4})", s)
        if m and m.group(2).lower() in _MONTHS:
            y = int(m.group(3))
            y += 2000 if y < 100 else 0
            return date(y, _MONTHS[m.group(2).lower()], int(m.group(1))).isoformat()
    except (ValueError, OverflowError):
        return ""
    return ""


def to_date(s):
    try:
        return date.fromisoformat(s) if s else None
    except ValueError:
        return None


def dmy(s):
    d = to_date(s)
    return d.strftime("%d/%m/%Y") if d else ""


def add_months(d, n):
    y, m = divmod(d.month - 1 + int(n), 12)
    y, m = d.year + y, m + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def parse_range_text(s):
    """'0-150 mm', '0 to 200mm', '(0~25) mm', '0–300' -> (min, max, unit) or None."""
    s = (s or "").replace("−", "-").replace(",", "")
    m = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:to|-|–|—|~)\s*(-?\d+(?:\.\d+)?)\s*([A-Za-z°%µμ/]*)", s, re.I)
    if not m:
        return None
    lo, hi = float(m.group(1)), float(m.group(2))
    if hi < lo:
        lo, hi = hi, lo
    unit = (m.group(3) or "").strip()
    if unit.lower() in ("to", ""):
        unit = ""
    return lo, hi, unit or "mm"


def clean_text(v, key=None):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = re.sub(r"\s+", " ", str(v).replace("\x00", "")).strip()
    return s[:MAX_LEN.get(key, 200)] if key else s


EMAIL_RE = re.compile(r"^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]{2,}$")


def clean_row(raw, today=None):
    """raw: {key: value} from the form or Excel -> (values, errors, warnings). values hold stored columns."""
    errors, warns = [], []
    v = {k: clean_text(raw.get(k), k) for k in KEYS if k not in DATE_KEYS and k != "freq_months"}
    if not v["ident"]:
        errors.append("IMTE ID is missing")
    for k in DATE_KEYS:
        src = raw.get(k)
        v[k] = parse_date(src)
        if clean_text(src) and not v[k]:
            errors.append(f"{dict((c[0], c[1]) for c in COLUMNS)[k]} '{clean_text(src)}' is not a date (use dd/mm/yyyy)")
    f = clean_text(raw.get("freq_months"))
    if f:
        try:
            n = int(float(f))
            if not 1 <= n <= 120:
                raise ValueError
            v["freq_months"] = n
        except ValueError:
            errors.append(f"Frequency '{f}' must be a number of months (1 to 120)")
            v["freq_months"] = 12
    else:
        v["freq_months"] = 12
    if v["owner_email"] and not EMAIL_RE.match(v["owner_email"]):
        errors.append(f"Responsible email '{v['owner_email']}' is not valid")
        v["owner_email"] = ""
    if not v["category"]:
        v["category"] = guess_category(v["name"])
    # numeric operating range (rule 4): operating range, else the instrument range
    rng = parse_range_text(v["op_range"]) or parse_range_text(v["instr_range"])
    v["range_min"], v["range_max"], v["unit"] = (rng if rng else (0.0, 0.0, "mm"))
    # due date: from the certificate or, when blank, calibration date + frequency
    cd, dd = to_date(v["cal_date"]), to_date(v["due_date"])
    if cd and not dd:
        v["due_date"] = add_months(cd, v["freq_months"]).isoformat()
        warns.append("Due date was calculated from the calibration date and frequency")
    if cd and to_date(v["due_date"]) and to_date(v["due_date"]) < cd:
        errors.append("Calibration due is before the calibration date")
    return v, errors, warns


# ------------------------------------------------------------------ status
STATUS = {
    "sent": ("Sent for calibration", "info"),
    "cert_nok": ("Certificate NOT OK", "bad"),
    "overdue": ("Overdue", "bad"),
    "due_soon": ("Due soon", "warn"),
    "in_date": ("In calibration", "good"),
    "no_due": ("No due date", "na"),
}
STATUS_ORDER = ["overdue", "due_soon", "sent", "cert_nok", "in_date", "no_due"]


def status_of(inst, today, window=30):
    """-> dict(key, label, cls, days) ; days = days until due (negative = overdue) or None."""
    due = to_date(inst.get("due_date"))
    days = (due - today).days if due else None
    if inst.get("sent_for_cal"):
        key = "sent"
    elif (inst.get("last_result") or "") == "NOT OK":
        key = "cert_nok"
    elif days is None:
        key = "no_due"
    elif days < 0:
        key = "overdue"
    elif days <= window:
        key = "due_soon"
    else:
        key = "in_date"
    label, cls = STATUS[key]
    return dict(key=key, label=label, cls=cls, days=days)


def days_text(days):
    if days is None:
        return ""
    if days < 0:
        return f"{-days} day{'s' if days != -1 else ''} overdue"
    if days == 0:
        return "due today"
    return f"due in {days} day{'s' if days != 1 else ''}"


def needs_reminder(inst, today, window=30):
    """Reminder rule: due within `window` days or overdue, or the last certificate was NOT OK.
    A verified-OK certificate moves the due date to the next cycle, which is what stops the reminders."""
    if (inst.get("last_result") or "") == "NOT OK":
        return True
    st = status_of(inst, today, window)
    return st["days"] is not None and st["days"] <= window


# ------------------------------------------------------------------ Excel
def template_xlsx():
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    ws = wb.active
    ws.title = "Instruments"
    ws.append([c[1] for c in COLUMNS])
    ws.append(["FFPL/UL/VC/01", "Vernier Caliper Digital", "Vernier Caliper", "Mitutoyo", "A1234567", "0-150 mm", "0-100 mm",
               "", "", "05/01/2026", "07/01/2026", "06/01/2027", "08/01/2026", 12, "quality@example.com", "Example row - delete it"])
    ws.append(["FFPL/UL/VB/04", "V Block", "V Block", "Taylor", "1485B", "", "", "2", "100X90X75", "", "", "", "", 12, "", ""])
    for i, c in enumerate(ws[1], 1):
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="2457E6")
        c.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = 22 if i not in (1, 2, 16) else 28
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 32
    help_ = wb.create_sheet("How to fill")
    for line in [
        "IMTE ID is required and must be unique. Everything else is optional.",
        "If an IMTE ID already exists in the app, that instrument is UPDATED; otherwise it is added.",
        "Dates: dd/mm/yyyy (Excel dates also work).",
        "Instrument Range = the full range of the instrument, e.g. 0-150 mm.",
        "Operating Range = the range you really use, e.g. 0-100 mm. Rule 4 checks that the calibration covers it.",
        "Grade and Size are for items like V blocks (grade 0, 1, 2; size 100X90X75).",
        "Calibration Due left blank = Date of Calibration + Frequency (months, default 12).",
        "Category is guessed from the Name when left blank (Vernier Caliper, Micrometer, ...).",
        "Responsible Email (optional) also receives the Friday reminders for that instrument.",
    ]:
        help_.append([line])
    help_.column_dimensions["A"].width = 110
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def export_xlsx(rows, today):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    ws = wb.active
    ws.title = "Instruments"
    ws.append([c[1] for c in COLUMNS] + ["Status", "Days to due"])
    for r in rows:
        st = status_of(r, today)
        line = []
        for k, _h, _a in COLUMNS:
            val = r.get(k)
            line.append(to_date(val) if k in DATE_KEYS and val else (val if val is not None else ""))
        ws.append(line + [st["label"], st["days"] if st["days"] is not None else ""])
    for i, c in enumerate(ws[1], 1):
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="2457E6")
        ws.column_dimensions[get_column_letter(i)].width = 20
    for row in ws.iter_rows(min_row=2):
        for c in row:
            if hasattr(c.value, "year"):
                c.number_format = "DD/MM/YYYY"
    ws.freeze_panes = "A2"
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


class ImportError_(Exception):
    pass


def read_workbook(data, max_rows=5000):
    """Excel / CSV bytes -> list of (row_number, {key: value}). Finds the heading row by itself."""
    rows = []
    if data[:2] == b"PK":
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(data), data_only=True, read_only=True)
        ws = wb["Instruments"] if "Instruments" in wb.sheetnames else wb[wb.sheetnames[0]]
        grid = [list(r) for r in ws.iter_rows(values_only=True)]
    else:
        import csv
        txt = data.decode("utf-8-sig", errors="replace")
        try:
            dialect = csv.Sniffer().sniff(txt[:2000], delimiters=",;\t")
        except csv.Error:
            dialect = csv.excel
        grid = [list(r) for r in csv.reader(io.StringIO(txt), dialect)]
    alias = {}
    for key, head, al in COLUMNS:
        for a in [norm_key(head)] + al:
            alias.setdefault(a, key)
    head_idx, colmap = None, {}
    for i, r in enumerate(grid[:15]):
        m = {}
        for j, cell in enumerate(r):
            k = alias.get(norm_key(str(cell))) if cell is not None else None
            if k and k not in m.values():
                m[j] = k
        if "ident" in m.values() and len(m) >= 2:
            head_idx, colmap = i, m
            break
    if head_idx is None:
        raise ImportError_("Could not find the heading row. The first row must contain at least 'IMTE ID' and 'Name'. "
                           "Download the template and copy your instruments into it.")
    for n, r in enumerate(grid[head_idx + 1:], start=head_idx + 2):
        rec = {k: (r[j] if j < len(r) else None) for j, k in colmap.items()}
        if not any(clean_text(v) for v in rec.values()):
            continue
        rows.append((n, rec))
        if len(rows) > max_rows:
            raise ImportError_(f"More than {max_rows} rows. Split the file and import it in parts.")
    if not rows:
        raise ImportError_("The file has headings but no instrument rows.")
    return rows, [dict((c[0], c[1]) for c in COLUMNS)[k] for k in colmap.values()]
