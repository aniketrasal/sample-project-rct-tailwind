"""Reading a calibration certificate - server side, no OCR program needed (works on Vercel).

* Text PDFs (digital certificates): text and positions are read here with pdfplumber.
* Photos / scans: the browser does the OCR (tesseract.js) and sends the text; this module parses it.
Everything is best-effort: the user reviews and corrects the fields before the checks run.
"""
import io
from datetime import datetime
import re

DATE_CORE = r"\d{1,2}[/\-.]\d{1,2}[/\-.](?:19|20)\d{2}\b"
DATE_RE = r"(?<![\d/\-.])" + DATE_CORE
SIGNATORY_FUNCS = (r"manager|director|head|incharge|in-charge|signator|officer|engineer|authori[sz]ed|"
                   r"assistant|technician|calibrator")
SIG_INK_THRESHOLD = 0.008      # share of dark pixels between 'Approved By' and the function line


# ------------------------------------------------------------------ text normalising
_DATEISH = re.compile(r"(?<![\w/])([\dOoIl|]{1,2})\s?([/.\-])\s?([\dOoIl|]{1,2})\s?([/.\-])\s?([\dOoIl|]{4})(?![\w/])")


def _fix_date(m):
    s = m.group(0)
    if not re.search(r"\d", s):
        return s
    return s.translate(str.maketrans({"O": "0", "o": "0", "I": "1", "l": "1", "|": "1", " ": ""}))


def normalize(t):
    t = _DATEISH.sub(_fix_date, t or "")
    return _normalize(t)


def _normalize(t):
    t = t.replace("−", "-").replace("–", "-").replace("—", "-")
    t = t.replace("±", "+/-").replace("μ", "µ").replace("’", "'")
    return t


def _first(pattern, text, flags=re.I, group=1):
    m = re.search(pattern, text, flags)
    return m.group(group).strip() if m else ""


def _clean(s):
    return re.sub(r"\s+", " ", (s or "").strip(" :;|\t"))


# ------------------------------------------------------------------ field parsing
def parse_fields(raw, results_text=None, bottom=None):
    """raw: all text of the certificate. results_text: OCR text for tables (line-preserving)."""
    t = normalize(raw)
    lines = [l.strip() for l in t.splitlines() if l.strip()]
    d = {}

    # title
    if re.search(r"calibration\s+certificate", t, re.I):
        d["title"] = "Calibration Certificate"
    elif re.search(r"calibration\s+report", t, re.I):
        d["title"] = "Calibration Report"
    else:
        d["title"] = ""
        import difflib
        for l in t.splitlines():
            l2 = re.sub(r"[^A-Za-z ]", "", l).strip().upper()
            if 15 <= len(l2) <= 34 and difflib.SequenceMatcher(None, l2, "CALIBRATION CERTIFICATE").ratio() >= 0.78:
                d["title"] = "Calibration Certificate"
                break

    # lab name / address (top of the page)
    stop = next((i for i, l in enumerate(lines)
                 if re.search(r"PAGE\s*\d|CERTIFICATE\s*NO|^CALIBRATION\s+(?:CERTIFICATE|REPORT)|CALIBRATED\s+FOR", l, re.I)),
                len(lines))
    head = lines[:min(14, stop)]        # only what is printed above the certificate title block
    name_lines, addr = [], ""
    NAME_WORDS = r"laborator|\blab\b|\bllp\b|pvt|\bltd\b|calibration|metrology|instruments|gauges|services|solutions|engineering|testing|enterprises"
    for l in head:
        if re.search(r"\b\d{6}\b", l) and not addr:
            addr = _clean(re.sub(r"^[^A-Za-z0-9]+", "", l))
            break
        if re.search(r"@|www\.|\+\s*91|ph(?:one)?\b|tel\b|ULR|PAGE\s*\d|CERTIFICATE\s+NO|national|accreditation|board for", l, re.I):
            continue
        # keep only lines that look like a company name; OCR junk from logos / banners is dropped
        if re.search(NAME_WORDS, l, re.I) and len(re.findall(r"[A-Za-z]{3,}", l)) >= 2 and len(name_lines) < 3:
            name_lines.append(_clean(l))
    d["lab_name"] = _clean(" ".join(name_lines[:2]))
    d["lab_address"] = addr
    d["lab_location"] = _first(r"Calibration\s+Location\s*[:;\-]*\s*([A-Za-z ]{2,20})", t)
    d["lab_location"] = re.sub(r"\s+(Condition|Standards).*$", "", d["lab_location"], flags=re.I).strip()

    # certificate identity
    d["cert_no"] = _first(r"CERTIFICATE\s*(?:NO|No\.?|Number)\s*[:\-]?\s*([A-Z0-9][A-Z0-9/\\\-_.]{5,})", t)
    d["ulr"] = _first(r"ULR\s*[:\-]?\s*([A-Z0-9]{10,})", t)
    pm = re.search(r"PAGE\s*(\d+)\s*(?:of|0f|/)\s*(\d+)", t, re.I)
    d["page_text"] = f"{pm.group(1)} of {pm.group(2)}" if pm else ""
    d["end_marker"] = "on" if re.search(r"end\s+of\s+(?:the\s+)?(?:calibration\s+)?(?:certificate|report)|\*{3}\s*end",
                                         t, re.I) else ""

    # customer
    m = re.search(r"CALIBRATED\s+FOR\s*[:\-]?\s*(.+?)\n(.*?)(?=TYPE\s+OF\s+INSTRUMENT)", t, re.I | re.S)
    if m:
        d["customer_name"] = _clean(m.group(1))
        d["customer_address"] = _clean(m.group(2).replace("\n", " "))
    else:
        d["customer_name"] = _clean(_first(r"CALIBRATED\s+FOR\s*[:\-]?\s*(.+)", t))
        d["customer_address"] = ""

    # instrument
    d["instr_name_raw"] = re.sub(r"^[\W_]+", "", _clean(_first(r"TYPE\s+OF\s+INSTRUMENT\s*[:\-]?\s*(.+)", t)))
    itype = re.sub(r"\(.*?\)", "", d["instr_name_raw"]).strip()
    d["instr_type"] = d["instr_name_raw"]
    low = (d["instr_name_raw"] + " " + t[:1500]).lower()
    if re.search(r"surface\s*plate|v[\s-]*block|angle\s*plate|gd\s*&\s*t|straight\s*edge", low):
        d["instr_class"] = "gdt"
    elif re.search(r"voltmeter|ammeter|multimeter|voltage|current|resistance|megger", low):
        d["instr_class"] = "electrical"
    elif re.search(r"thermometer|thermocouple|temperature\s+(?:indicator|controller|sensor)|rtd|oven", low):
        d["instr_class"] = "thermal"
    else:
        d["instr_class"] = "dimensional"

    d["instr_lc_applicable"] = ""
    found = False
    for i, l in enumerate(lines[:-1]):
        if re.match(r"RANGE\b", l, re.I) and re.search(r"identification|make|mf[gr]|serial", l, re.I):
            hdr = [c.strip() for c in re.split(r"\s{2,}", l) if c.strip()]
            row = [c.strip() for c in re.split(r"\s{2,}", lines[i + 1]) if c.strip()]
            if len(hdr) < 3 or len(row) != len(hdr):
                continue
            for h, v in zip(hdr, row):
                hl = h.lower()
                if hl.startswith("range"):
                    d["instr_range"] = v
                elif re.search(r"l\.?\s*c|least", hl):
                    d["instr_lc"] = v
                elif hl.startswith("ident"):
                    d["instr_ident"] = v
                elif hl.startswith("make"):
                    d["instr_make"] = v
                elif re.search(r"mf[gr]|serial|sr", hl):
                    d["instr_serial"] = v
            if not d.get("instr_lc"):
                d["instr_lc_applicable"] = "no"
            found = True
            break
    if not found:
        for i, l in enumerate(lines[:-1]):
            if re.match(r"\W*RANGE\b", l, re.I) and lines[i + 1].strip():
                row = [c.strip() for c in re.split(r"\s{2,}", lines[i + 1].strip()) if c.strip()]
                rng = re.match(r"\W*(\d+(?:\.\d+)?\s*[xX]\s*\d+(?:\.\d+)?(?:\s*[xX]\s*\d+(?:\.\d+)?)?)(.*)", row[0]) if row else None
                if rng and len(row) >= 2:
                    d["instr_range"] = re.sub(r"\s+", "", rng.group(1)).upper()
                    rest = ([rng.group(2).strip()] if rng.group(2).strip() else []) + row[1:]
                    if re.fullmatch(r"[A-Za-z0-9\-]{3,}", rest[-1]) and len(rest) >= 2:
                        d["instr_serial"] = rest[-1]
                        ids = [x for x in rest[:-1] if re.search(r"[A-Za-z]{2,}.*[/\\|]", x)]
                        d["instr_ident"] = ids[0] if ids else ""
                        mk = [x for x in rest[:-1] if x != d["instr_ident"]]
                        d["instr_make"] = mk[0] if mk else ""
                        d["instr_lc_applicable"] = "no"
                        found = True
                break
    for i, l in enumerate(lines if not found else []):
        rm = re.search(r"(\d+(?:\.\d+)?)\s*(?:to|-)\s*(\d+(?:\.\d+)?)\s*(mm|um|µm|inch|in)\b", l, re.I)
        if rm and re.search(r"\d\.\d+\s*(mm|µm|um)", l[rm.end():], re.I):
            d["instr_range"] = f"{rm.group(1)} To {rm.group(2)} {rm.group(3)}"
            rest = l[rm.end():]
            lc = re.search(r"(\d+\.\d+)\s*(mm|µm|um)", rest, re.I)
            d["instr_lc"] = f"{lc.group(1)} {lc.group(2)}" if lc else ""
            rest = rest[lc.end():] if lc else rest
            toks = rest.split()
            ident = next((x for x in toks if re.search(r"[A-Za-z]", x) and re.search(r"[\\/|]", x)), "")
            if not ident:
                ident = next((x for x in toks if re.search(r"[A-Za-z0-9]{4,}", x)), "")
            d["instr_ident"] = ident
            after = [x for x in toks if x != ident]
            d["instr_make"] = next((x for x in after if re.fullmatch(r"[A-Za-z][A-Za-z.\-]{2,}", x)), "")
            nums = [x for x in after if re.fullmatch(r"[A-Za-z0-9\-]{4,}", x) and re.search(r"\d", x)]
            d["instr_serial"] = nums[-1] if nums else ""
            break
    for k in ("instr_range", "instr_lc", "instr_ident", "instr_make", "instr_serial"):
        d.setdefault(k, "")
    dims = re.findall(r"\d+(?:\.\d+)?", d["instr_range"]) if re.fullmatch(r"\s*\d+(?:\.\d+)?(?:\s*[xX]\s*\d+(?:\.\d+)?)+\s*", d["instr_range"]) else []
    d["dim_L"] = dims[0] if dims else ""
    d["dim_h1"] = dims[2] if len(dims) > 2 else (dims[-1] if len(dims) == 2 else "")
    d["instr_model"] = _first(r"Model\s*(?:No\.?)?\s*[:\-]\s*(\S+)", t)
    d["instr_qty"] = _first(r"(?:Quantity|Qty)\s*[:\-]\s*(\S+)", t)

    # dates (the row with 4 dates: receipt, calibration, due, issue)
    d.update(receipt_date="", cal_date="", due_date="", issue_date="", challan="", wo_no="")
    for l in lines:
        ds = re.findall(DATE_RE, l)
        if len(ds) >= 4:
            d["receipt_date"], d["cal_date"], d["due_date"], d["issue_date"] = ds[:4]
            before = l[:l.find(ds[0])].split()
            d["challan"] = before[0] if before else ""
            d["wo_no"] = before[1] if len(before) > 1 else ""
            break
    else:
        for key, pat in (("receipt_date", r"Receipt\s+Date"), ("cal_date", r"Calibration\s+Date"),
                         ("due_date", r"Due\s+Date"), ("issue_date", r"Issue\s+Date")):
            d[key] = _first(pat + r"\s*(?:\(.*?\))?\s*[:\-]?\s*(" + DATE_CORE + ")", t)

    miss = [k for k in ("receipt_date", "cal_date", "due_date", "issue_date") if not d[k]]
    if miss:
        cut0 = re.search(r"Standards\s*/\s*Equipment|CALIBRATION\s+PROCEDURE", t, re.I)
        seq = re.findall(DATE_RE, t[:cut0.start()] if cut0 else t)
        if len(seq) == 4:
            for k, v in zip(("receipt_date", "cal_date", "due_date", "issue_date"), seq):
                d[k] = d[k] or v

    # NABL: header area only (the traceability table also lists other labs' CC numbers)
    cut = re.search(r"Standards\s*/\s*Equipment|TYPE\s+OF\s+INSTRUMENT", t, re.I)
    pre = t[:cut.start()] if cut else t
    m = re.search(r"(?<![A-Za-z])CC\s*[-=~:_]*\s*(\d{4,5})(?!\d)", pre)
    d["nabl_from_ulr"] = ""
    if m and not re.fullmatch(r"\s*ULR.*", pre[max(0, m.start() - 6):m.start()], re.I) and "ULR" not in pre[max(0, m.start() - 6):m.start()]:
        d["nabl_no"] = f"CC-{m.group(1)}"
    else:
        d["nabl_no"] = ""
        ulr = re.sub(r"\s", "", _first(r"ULR\s*[:\-]?\s*([A-Z0-9]{10,})", t)).upper()
        cy = re.search(r"\d{4}$", d.get("cal_date", "") or "")
        for n in (4, 5):
            um_ = re.fullmatch(r"CC(\d{%d})(\d{2})\d+F?" % n, ulr)
            if um_ and (not cy or cy.group(0)[2:] == um_.group(2)):
                d["nabl_no"], d["nabl_from_ulr"] = f"CC-{um_.group(1)}", "on"
                break
    header = "\n".join(lines[:stop])
    d["nabl_symbol"] = "on" if re.search(r"nabl|accreditation\s+board|national\s+accreditation", header, re.I) or \
        (not d["nabl_from_ulr"] and d["nabl_no"]) else ""
    d["calibration_kind"] = "nabl" if d["nabl_no"] else "internal"

    # method / environment / uncertainty
    d["method_no"] = _first(r"CALIBRATION\s+PROCEDURE\s+NO\.?\s*[:\-]?\s*([A-Za-z0-9\-/_.]+)", t)
    d["reference_std"] = _clean(_first(r"REFERENCE\s+STANDARD\s*[:\-]?\s*(.+)", t))
    d["env_temp"] = _first(r"Temperature\s*[:;=\-]*\s*(\d{1,2}(?:\.\d+)?)\s*(?:°|o|\*|º)?\s*C", t) or \
        _first(r"Temp\w*\W{0,8}(\d{2}(?:\.\d+)?)\s*(?:°|o|\*|º)?\s*[CcG]\b", t)
    d["env_humidity"] = _first(r"Humidity\s*[:;=\-]*\s*(\d{1,3}(?:\.\d+)?)\s*%", t) or \
        _first(r"Humid\w*\W{0,8}(\d{2,3}(?:\.\d+)?)\s*%", t)
    um = re.search(r"UNCERTAINTY\s+OF\s+MEASUREMENT\s*[:\-]?\s*(.*)", t, re.I)
    d.update(unc_value="", unc_unit="", unc_conf="", k_factor="")
    if um:
        seg = um.group(1)
        vm = re.search(r"(?:\+/-|[+t])?\s*(\d+(?:\.\d+)?)\s*([\u00b5u]?m)\b", seg, re.I)
        if vm:
            d["unc_value"] = vm.group(1)
            d["unc_unit"] = "mm" if vm.group(2).lower() == "mm" else "\u00b5m"
        cm = re.search(r"(\d{2}(?:\.\d+)?)\s*%", seg)
        d["unc_conf"] = cm.group(1) if cm else ""
        km = re.search(r"\bk\s*=\s*(\d(?:\.\d+)?)", seg, re.I)
        d["k_factor"] = km.group(1) if km else ""
    if not d["k_factor"]:
        d["k_factor"] = _first(r"\bk\s*=\s*(\d(?:\.\d+)?)", t)
    sm = re.search(r"[^\n]*(?:pertains|relates?)\s+only[^\n]*", t, re.I)
    d["statement_text"] = _clean(sm.group(0)) if sm else ""

    # standards table
    stds = []
    m = re.search(r"Standards\s*/\s*Equipment.*?\n(.*?)(?=CALIBRATION\s+PROCEDURE)", t, re.I | re.S)
    block = m.group(1) if m else ""
    cand = block.splitlines()
    if not any(len(re.findall(DATE_RE, l)) == 1 for l in cand):      # header line lost: look at every line with 1 date + a CC code
        cand = [l for l in lines if len(re.findall(DATE_RE, l)) == 1 and re.search(r"(?<![A-Za-z])CC\s*[-=~:_]*\s*\d{4,5}(?!\d)", l)]
    for l in cand:
        ds = re.findall(DATE_RE, l)
        if not ds or re.search(r"Valid\s+up", l, re.I):
            continue
        valid = ds[-1]
        rest = l.replace(valid, " ")
        cm = re.search(r"(?<![A-Za-z])CC\s*[-=~:_]*\s*\d{4,5}(?!\d)", rest)
        trace = ("CC-" + re.search(r"\d+", cm.group(0)).group(0)) if cm else ""
        if cm:
            rest = rest.replace(cm.group(0), " ")
        toks = rest.split()
        idx = [i for i, x in enumerate(toks) if re.search(r"[\\/]", x) or (re.search(r"\d", x) and len(x) > 4)]
        desc = " ".join(toks[:idx[0]]) if idx else " ".join(toks)
        ident = toks[idx[0]] if idx else ""
        cert = toks[idx[1]] if len(idx) > 1 else ""
        stds.append(" | ".join([_clean(desc), ident, cert, trace, valid]))
    d["standards"] = "\n".join(stds)

    # acceptance criteria
    am = re.search(r"ACCEPTANCE\s+CRITERIA(.*?)(?:Calibrated\s+By|$)", t, re.I | re.S)
    seg = am.group(1) if am else ""
    d["acc_ranges"] = d["acc_empe"] = d["acc_smpe"] = ""
    ranges = re.findall(r"(\d+)\s*-\s*(\d+)\s*mm", seg)
    d["acc_ranges"] = ", ".join(f"{a}-{b}" for a, b in ranges[:6])
    for key, tag in (("acc_empe", "EMPE"), ("acc_smpe", "SMPE")):
        ln = next((l for l in seg.splitlines() if tag in l), "")
        vals = re.findall(r"\+/-\s*(\d+)\s*[\u00b5u]?m", ln)
        d[key] = ", ".join(vals[:len(ranges[:6])])

    fm = [l for l in seg.splitlines() if re.search(r"\d\s*\+\s*\(", l)]
    hdr_line = next((l for l in seg.splitlines() if re.match(r"[\s|]*Grade\b", l, re.I)), "")
    if fm and hdr_line:
        cols = [c for c in re.split(r"[\s|_]+", hdr_line) if c and c.lower() != "grade"]
        rows = []
        for l in fm:
            g = re.match(r"\s*(\w+)\s", l)
            fs = [re.sub(r"\s+", "", x) for x in re.findall(r"\d+(?:\.\d+)?\s*\+\s*\(\s*[A-Za-z]\w*\s*/\s*\d+(?:\.\d+)?\s*\)", l)]
            if g and fs:
                rows.append(" | ".join([g.group(1)] + fs))
        if rows:
            d["acc_formulas"] = "\n".join(["Grade | " + " | ".join(cols)] + rows)

    # results tables
    d.update(results_external="", results_internal="", results_depth="", results_unit_text="")
    rt = normalize(results_text if results_text else raw)
    d["results_params"] = ""
    m = re.search(r"(?<!See )(?<!see )CALIBRATION\s+RESULTS\b(?!\s+on\s+next)(.*?)(?=ACCEPTANCE\s+CRITERIA|\Z)", rt, re.I | re.S)
    if m and re.search(r"Parameter", m.group(1), re.I):
        d["results_unit_text"] = _first(r"(Observed\s+Value.*)", rt) or "Observed Value"
        ps = []
        for l in m.group(1).splitlines():
            pm_ = re.match(r"[\s\[|]*\d+[\s|_\]\[]+([A-Za-z][A-Za-z _.\-/()]*?)[\s|_]+(-?\d+(?:\.\d+)?)[\s|_.\]]*$", l.replace("—", "-"))
            if pm_:
                ps.append(f"{_clean(pm_.group(1).replace('_', ' '))} | {pm_.group(2)}")
        d["results_params"] = "\n".join(ps)
    elif m:
        d["results_unit_text"] = _first(r"(Observed\s+Reading.*)", rt)
        ext, inn, dep = [], [], []
        for l in m.group(1).splitlines():
            toks = re.findall(r"-?\d+(?:\.\d+)?|[-_=~]+", l.replace("—", "-"))
            if len(toks) < 3 or not re.fullmatch(r"-?\d+(?:\.\d+)?", toks[0]):
                continue
            vals = [None if re.fullmatch(r"[-_=~]+", x) else x for x in toks]
            if vals[0] is not None and vals[1] is not None and vals[2] is not None:
                ext.append(f"{vals[0]}, {vals[1]}, {vals[2]}")
            if len(vals) >= 6 and vals[3] is not None and vals[4] is not None and vals[5] is not None:
                inn.append(f"{vals[3]}, {vals[4]}, {vals[5]}")
            if len(vals) >= 9 and vals[6] is not None and vals[7] is not None and vals[8] is not None:
                dep.append(f"{vals[6]}, {vals[7]}, {vals[8]}")
        d["results_external"] = "\n".join(ext)
        d["results_internal"] = "\n".join(inn)
        d["results_depth"] = "\n".join(dep)

    # signatories (from the cropped bottom area when available)
    d.update(approver_name="", approver_function="", approver_signature="", calibrator_name="",
             calibrator_function="")
    if bottom:
        d.update({k: v for k, v in bottom.items() if v})
    return d



# ------------------------------------------------------------------ signatories
def parse_signatories(right_text="", left_text=""):
    """OCR text of the 'Approved By' block (right) and 'Calibrated By' block (left)."""
    out = {}
    ls = [normalize(l).strip() for l in (right_text or "").splitlines() if l.strip()]
    ls = [l for l in ls if not re.fullmatch(r"approved\s*by:?", l, re.I)]
    func = next((l for l in ls if re.search(SIGNATORY_FUNCS, l, re.I)), "")
    name = ""
    if func:
        after = ls[ls.index(func) + 1:]
        name = after[0] if after else ""
    out["approver_function"] = _clean(func)
    out["approver_name"] = _clean(re.sub(r"[^A-Za-z .]", "", name))
    lt = [normalize(l).strip() for l in (left_text or "").splitlines() if l.strip()]
    lt = [l for l in lt if not re.fullmatch(r"calibrated\s*by:?", l, re.I)]
    lf = next((l for l in lt if re.search(r"assistant|engineer|technician|calibrator|officer", l, re.I)), "")
    ln = ""
    if lf and lt.index(lf) + 1 < len(lt):
        ln = lt[lt.index(lf) + 1]
    out["calibrator_function"] = _clean(lf)
    out["calibrator_name"] = _clean(re.sub(r"[^A-Za-z .]", "", ln))
    if out["calibrator_name"] in ("-", "--"):
        out["calibrator_name"] = ""
    return out


def merge_fields(a, b):
    """Fill what the first reading missed from a second reading."""
    out = dict(a)
    def ok_date(x):
        try:
            datetime.strptime(x.replace(".", "/").replace("-", "/"), "%d/%m/%Y"); return True
        except Exception:
            return False
    for k, v in b.items():
        if (out.get(k) in (None, "")) and v not in (None, ""):
            out[k] = v
        elif k.endswith("_date") and v and not ok_date(out.get(k) or "") and ok_date(v):
            out[k] = v                                   # first reading had an impossible date
        elif k == "results_unit_text" and v and not re.search(r"\(\s*in\s+\S+\s*\)|mm|[µμu]m", out.get(k) or "", re.I) \
                and re.search(r"\(\s*in\s+\S+\s*\)|mm|[µμu]m", v, re.I):
            out[k] = v
        elif k in ("standards", "results_params", "acc_formulas") and v and len(v.splitlines()) > len((out.get(k) or "").splitlines()):
            out[k] = v                                   # keep the more complete table
    if a.get("pages_found") is not None or b.get("pages_found") is not None:
        pf = {x for x in (a.get("pages_found", "") + "," + b.get("pages_found", "")).split(",") if x}
        out["pages_found"] = ",".join(sorted(pf))
    return out


def fields_from_ocr(text, right_text="", left_text="", sig_ink=None, head_text="", alt_text=""):
    """Browser OCR result -> form fields. Pages are separated by a form feed (\\f); head_text = OCR of the letterhead."""
    pages = [p for p in (text or "").split("\f") if p.strip()]
    hl = []
    for l in (head_text or "").splitlines():
        if re.search(r"ULR|PAGE\s*\d|CERTIFICATE", l, re.I):
            break
        hl.append(l)
    head_text = "\n".join(hl)
    text = ("\n".join(l for l in (head_text or "").splitlines() if l.strip()) + "\n" if (head_text or "").strip() else "") + "\n".join(pages)
    bottom = parse_signatories(right_text, left_text)
    try:
        if sig_ink is not None and float(sig_ink) > SIG_INK_THRESHOLD:
            bottom["approver_signature"] = "on"
    except (TypeError, ValueError):
        pass
    d = parse_fields(text, results_text=text, bottom=bottom)
    if len(pages) > 1:
        found, total = [], 0
        for n, pg in enumerate(pages, start=1):
            pm = re.search(r"PAGE\s*%d\s*(?:of|0f|/)\s*(\d+)" % n, pg, re.I)
            if pm and re.search(r"CERTIFICATE\s*N[O0o]\b|CERTIFICATE\s*N[O0o]\s*[:;.\-]", pg, re.I):
                found.append(str(n))
                total = max(total, int(pm.group(1)))
        d["pages_found"] = ",".join(found)
        d["page_total"] = str(total or len(pages))
    if (alt_text or "").strip():
        try:
            d = merge_fields(d, fields_from_ocr(alt_text, right_text, left_text, sig_ink, head_text))
        except Exception:
            pass
    return d


# ------------------------------------------------------------------ text PDFs
def _group_lines(words, tol=3.5):
    lines = []
    for w in sorted(words, key=lambda w: (w["top"], w["x0"])):
        if lines and abs(w["top"] - lines[-1]["top"]) <= tol:
            lines[-1]["words"].append(w)
        else:
            lines.append({"top": w["top"], "words": [w]})
    out = []
    for ln in lines:
        ws = sorted(ln["words"], key=lambda w: w["x0"])
        s = ws[0]["text"]
        for a, b in zip(ws, ws[1:]):
            s += ("   " if b["x0"] - a["x1"] > 12 else " ") + b["text"]
        out.append(s)
    return out


def read_pdf(data):
    """Returns (fields, text) or (None, '') when the PDF has no text layer (a scan)."""
    import pdfplumber
    page_lines, last, page_blocks = [], None, []
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for page in pdf.pages[:6]:
            words = page.extract_words(x_tolerance=1.5, y_tolerance=3, keep_blank_chars=False)
            gl = _group_lines(words)
            page_lines.extend(gl)
            page_blocks.append(normalize("\n".join(gl)))
            last = (page, words)
        text = "\n".join(page_lines)
        if len(re.sub(r"\s", "", text)) < 150 or last is None:
            return None, ""
        page, words = last
        pw, ph = float(page.width), float(page.height)
        right_text = left_text = ""
        sig = False
        appr = next((w for w in words if w["text"].lower().startswith("approved")), None)
        if appr:
            x0 = max(0, appr["x0"] - 0.06 * pw)
            rw = [w for w in words if w["x0"] >= x0 and appr["top"] - 3 <= w["top"] <= appr["top"] + 0.16 * ph]
            right_text = "\n".join(_group_lines(rw))
            func_top = next((w["top"] for w in sorted(rw, key=lambda w: w["top"])
                             if w["top"] > appr["bottom"] + 1 and re.match(r"(quality|technical|manager|director)", w["text"], re.I)),
                            appr["bottom"] + 0.06 * ph)
            top, bot = appr["bottom"] + 1, func_top - 1
            if bot - top > 8:
                reg = page.crop((x0, top, min(pw, appr["x1"] + 0.25 * pw), bot), strict=False)
                sig = bool(reg.images or reg.curves or len(reg.lines) >= 3)
        cal = next((w for w in words if w["text"].lower() == "calibrated" and w["top"] > 0.6 * ph), None)
        if cal:
            lw = [w for w in words if w["x1"] <= 0.45 * pw and cal["top"] - 3 <= w["top"] <= cal["top"] + 0.16 * ph]
            left_text = "\n".join(_group_lines(lw))
        bottom = parse_signatories(right_text, left_text)
        if sig:
            bottom["approver_signature"] = "on"
        d = parse_fields(text, results_text=text, bottom=bottom)
        cn = d.get("cert_no", "")
        found, total = [], len(pdf.pages)
        for n, pl in enumerate(page_blocks, start=1):
            if cn and cn in pl and re.search(r"PAGE\s*%d\s*(?:of|/)\s*\d+" % n, pl, re.I):
                found.append(str(n))
        d["pages_found"] = ",".join(found) if total > 1 else ""
        d["page_total"] = str(total) if total > 1 else ""
        if total > 1 and d.get("end_marker") and "end of" not in "\n".join(page_blocks[-1:]).lower():
            d["end_marker"] = ""
        return d, text
