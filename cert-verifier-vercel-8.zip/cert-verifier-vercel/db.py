"""Storage for the Calibration Certificate Verifier.

Production (Vercel): PostgreSQL, e.g. Neon - set DATABASE_URL (the Vercel Neon integration does this).
Local development / tests: SQLite file, used automatically when no database URL is set (never on Vercel).

The same SQL runs on both: "?" placeholders, ON CONFLICT upserts, no vendor-specific syntax.
Rows behave like dicts and also support row[0].
"""
import os
import re
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

BASE_DIR = Path(__file__).resolve().parent
ON_VERCEL = bool(os.environ.get("VERCEL"))
_LIBPQ_PARAMS = {"sslmode", "channel_binding", "connect_timeout", "application_name", "target_session_attrs"}


class DBUnavailable(Exception):
    """The database cannot be reached / is not configured."""


class Row(dict):
    def __getitem__(self, k):
        if isinstance(k, int):
            return list(self.values())[k]
        return super().__getitem__(k)

    __getattr__ = dict.get  # lets templates write row.name


def database_url():
    for k in ("DATABASE_URL", "POSTGRES_URL", "POSTGRES_URL_NON_POOLING", "POSTGRES_PRISMA_URL"):
        v = os.environ.get(k, "").strip()
        if v:
            return _clean_url(v)
    return ""


def _clean_url(url):
    """Vercel/Supabase/Prisma add query parameters libpq does not know; drop them."""
    u = urlsplit(url)
    scheme = "postgresql" if u.scheme in ("postgres", "postgresql") else u.scheme
    q = [(k, v) for k, v in parse_qsl(u.query) if k in _LIBPQ_PARAMS]
    if not any(k == "sslmode" for k, _ in q) and u.hostname not in ("localhost", "127.0.0.1", None):
        q.append(("sslmode", "require"))
    return urlunsplit((scheme, u.netloc, u.path, urlencode(q), ""))


def sqlite_path():
    return Path(os.environ.get("CERTV_SQLITE", BASE_DIR / "data" / "certverifier.db"))


def backend():
    """'postgres', 'sqlite' or '' (nothing configured, e.g. Vercel without a database)."""
    if database_url():
        return "postgres"
    if ON_VERCEL and not os.environ.get("CERTV_SQLITE"):
        return ""
    return "sqlite"


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id {PK},
    username TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    pw_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user'
);
CREATE TABLE IF NOT EXISTS labs(
    id {PK},
    name TEXT NOT NULL,
    nabl_no TEXT UNIQUE NOT NULL,
    address TEXT DEFAULT '',
    valid_from TEXT,
    valid_to TEXT,
    status TEXT NOT NULL DEFAULT 'Active',
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS lab_scope(
    id {PK},
    lab_id INTEGER NOT NULL REFERENCES labs(id) ON DELETE CASCADE,
    instrument_type TEXT NOT NULL,
    range_min {REAL} NOT NULL DEFAULT 0,
    range_max {REAL} NOT NULL,
    unit TEXT NOT NULL DEFAULT 'mm',
    cmc_um {REAL}
);
CREATE TABLE IF NOT EXISTS instruments(
    id {PK},
    ident TEXT UNIQUE NOT NULL,
    name TEXT DEFAULT '',
    range_min {REAL} NOT NULL DEFAULT 0,
    range_max {REAL} NOT NULL,
    unit TEXT NOT NULL DEFAULT 'mm'
);
CREATE TABLE IF NOT EXISTS email_codes(
    id {PK},
    purpose TEXT NOT NULL,
    user_id INTEGER,
    email TEXT NOT NULL,
    code_hash TEXT NOT NULL,
    payload TEXT DEFAULT '',
    created {REAL} NOT NULL,
    expires {REAL} NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS env_limits(
    key TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    temp_nom {REAL},
    temp_tol {REAL},
    rh_max {REAL}
);
CREATE TABLE IF NOT EXISTS verifications(
    id {PK},
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    file_name TEXT,
    data_json TEXT NOT NULL DEFAULT '{}',
    ocr_text TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    result TEXT DEFAULT '',
    verifier_name TEXT DEFAULT '',
    verifier_remark TEXT DEFAULT '',
    verified_at TEXT DEFAULT '',
    revision INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS verification_files(
    verification_id INTEGER PRIMARY KEY REFERENCES verifications(id) ON DELETE CASCADE,
    mime TEXT NOT NULL,
    data {BLOB} NOT NULL
);
CREATE TABLE IF NOT EXISTS check_results(
    verification_id INTEGER NOT NULL REFERENCES verifications(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    title TEXT NOT NULL,
    auto_status TEXT NOT NULL,
    status TEXT NOT NULL,
    reason TEXT DEFAULT '',
    pending INTEGER NOT NULL DEFAULT 0,
    overridden INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(verification_id, code)
);
CREATE TABLE IF NOT EXISTS login_attempts(
    ip TEXT NOT NULL,
    username TEXT NOT NULL,
    ts {REAL} NOT NULL
);
CREATE TABLE IF NOT EXISTS change_log(
    id {PK},
    verification_id INTEGER NOT NULL REFERENCES verifications(id) ON DELETE CASCADE,
    ts TEXT NOT NULL,
    by_user TEXT NOT NULL,
    code TEXT NOT NULL,
    old_status TEXT,
    new_status TEXT,
    reason TEXT
);
CREATE TABLE IF NOT EXISTS field_corrections(
    id {PK},
    verification_id INTEGER NOT NULL REFERENCES verifications(id) ON DELETE CASCADE,
    ts TEXT NOT NULL,
    by_user TEXT NOT NULL,
    field TEXT NOT NULL,
    read_value TEXT,
    new_value TEXT
)
"""

DEFAULT_ENV = [
    ("dimensional", "Dimensional gauges like Vernier, Micrometer etc.", 20, 2, None),
    ("gdt", "GD&T parameter like Surface plate, V Block etc.", None, None, None),
    ("electrical", "Electrical parameter like Voltage, Current etc.", 25, 4, 70),
    ("thermal", "Thermal parameter like Temperature", 25, 4, 70),
]


class Conn:
    """Small wrapper that gives sqlite3 and psycopg the same API."""

    def __init__(self, raw, pg):
        self.raw, self.pg = raw, pg

    def execute(self, sql, params=()):
        if self.pg:
            sql = sql.replace("?", "%s")
        try:
            return self.raw.execute(sql, tuple(params))
        except Exception as e:
            # dropped / unreachable connection (e.g. a sleeping Neon database): show the friendly page
            if type(e).__name__ in ("OperationalError", "InterfaceError", "AdminShutdown", "CannotConnectNow"):
                raise DBUnavailable(_short(e)) from e
            raise

    def insert(self, table, **cols):
        """Insert one row, return its new id."""
        names = list(cols)
        sql = f"INSERT INTO {table}({','.join(names)}) VALUES ({','.join('?' * len(names))})"
        if self.pg:
            return self.execute(sql + " RETURNING id", cols.values()).fetchone()["id"]
        return self.execute(sql, cols.values()).lastrowid

    def upsert(self, table, conflict, **cols):
        names = list(cols)
        upd = ",".join(f"{c}=excluded.{c}" for c in names if c not in conflict)
        action = f"DO UPDATE SET {upd}" if upd else "DO NOTHING"
        self.execute(f"INSERT INTO {table}({','.join(names)}) VALUES ({','.join('?' * len(names))}) "
                     f"ON CONFLICT({','.join(conflict)}) {action}", cols.values())

    def commit(self):
        self.raw.commit()

    def rollback(self):
        try:
            self.raw.rollback()
        except Exception:
            pass

    def close(self):
        try:
            self.raw.close()
        except Exception:
            pass


def connect():
    kind = backend()
    if kind == "postgres":
        try:
            import psycopg
        except ImportError as e:  # pragma: no cover
            raise DBUnavailable("The 'psycopg' package is missing - check requirements.txt.") from e

        def row_factory(cursor):
            names = [c.name for c in (cursor.description or [])]
            return lambda values: Row(zip(names, values))

        try:
            raw = psycopg.connect(database_url(), row_factory=row_factory, prepare_threshold=None, connect_timeout=15)
        except Exception as e:
            raise DBUnavailable(_short(e)) from e
        return Conn(raw, True)
    if kind == "sqlite":
        import sqlite3
        p = sqlite_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        raw = sqlite3.connect(p, timeout=30)
        raw.row_factory = lambda cur, row: Row(zip([d[0] for d in cur.description], row))
        raw.execute("PRAGMA foreign_keys = ON")
        raw.execute("PRAGMA journal_mode = WAL")
        return Conn(raw, False)
    raise DBUnavailable("No database is configured (DATABASE_URL is missing).")


def _short(e):
    """Error text without credentials."""
    return re.sub(r"(postgres(?:ql)?://)[^@\s]+@", r"\1***@", str(e)).strip()[:300]


def init_db(admin_password_hash=None, reset_admin=False):
    """Create tables (idempotent), seed Rule 6 limits, create / reset the first admin."""
    c = connect()
    try:
        if c.pg:
            c.execute("SELECT pg_advisory_xact_lock(727274)")   # concurrent cold starts wait their turn
        ddl = (SCHEMA.replace("{PK}", "SERIAL PRIMARY KEY" if c.pg else "INTEGER PRIMARY KEY AUTOINCREMENT")
               .replace("{REAL}", "DOUBLE PRECISION" if c.pg else "REAL")
               .replace("{BLOB}", "BYTEA" if c.pg else "BLOB"))
        for stmt in ddl.split(";"):
            if stmt.strip():
                c.execute(stmt)
        # upgrade: instruments.grade (V-block grade etc.)
        if c.pg:
            c.execute("ALTER TABLE instruments ADD COLUMN IF NOT EXISTS grade TEXT DEFAULT ''")
        elif "grade" not in [r[1] for r in c.execute("PRAGMA table_info(instruments)").fetchall()]:
            c.execute("ALTER TABLE instruments ADD COLUMN grade TEXT DEFAULT ''")
        for row in DEFAULT_ENV:
            c.upsert("env_limits", ["key"], key=row[0], label=row[1], temp_nom=row[2], temp_tol=row[3], rh_max=row[4]) \
                if c.execute("SELECT 1 FROM env_limits WHERE key=?", (row[0],)).fetchone() is None else None
        # upgrade: users.email / email_verified / must_setup
        for col, ddl in (("email", "TEXT DEFAULT ''"), ("email_verified", "INTEGER NOT NULL DEFAULT 0"),
                         ("must_setup", "INTEGER NOT NULL DEFAULT 0")):
            if c.pg:
                c.execute(f"ALTER TABLE users ADD COLUMN IF NOT EXISTS {col} {ddl}")
            elif col not in [r[1] for r in c.execute("PRAGMA table_info(users)").fetchall()]:
                c.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
        if admin_password_hash:
            # The first sign-in is admin / admin; the owner then chooses a real username, password and a verified email.
            n = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            if n == 0:
                c.upsert("users", ["username"], username="admin", full_name="Administrator",
                         pw_hash=admin_password_hash, role="admin", email="", email_verified=0, must_setup=1)
            else:
                # an older deployment: its admin has no email yet, so it goes through the same first-login set-up
                c.execute("UPDATE users SET pw_hash=?, must_setup=1 WHERE username='admin' AND role='admin' "
                          "AND (email IS NULL OR email='')", (admin_password_hash,))
                if reset_admin:
                    c.execute("UPDATE users SET pw_hash=?, must_setup=1, email='', email_verified=0 WHERE username='admin'",
                              (admin_password_hash,))
        c.commit()
        return c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def norm_nabl(s):
    """'cc 2656', 'CC-2656', 'CC - 2656' -> 'CC-2656'."""
    m = re.search(r"CC\s*[-–—]?\s*(\d{3,5})", (s or "").upper())
    return f"CC-{m.group(1)}" if m else (s or "").strip().upper()
