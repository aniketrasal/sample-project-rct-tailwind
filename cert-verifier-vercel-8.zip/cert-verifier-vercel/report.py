"""PDF verification report with a QR code (QR carries the result as plain text, so it works offline)."""
import io
from datetime import datetime

from reportlab.graphics import renderPDF
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (Flowable, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

GREEN, RED, AMBER, GREY = colors.HexColor("#1b7f3b"), colors.HexColor("#b3261e"), colors.HexColor("#b26a00"), \
    colors.HexColor("#555555")
COL = {"OK": GREEN, "NOT OK": RED, "N/A": GREY, "PENDING": AMBER}


def ascii_safe(s):
    """Keep QR text plain ASCII so every scanner shows it correctly."""
    return (s or "").replace("µ", "u").replace("±", "+/-").encode("ascii", "ignore").decode()


def qr_text(v, d, lab_label):
    lines = [
        f"CALIBRATION VERIFICATION V-{v['id']:05d}",
        f"Cert: {d.get('cert_no','')}",
        f"Instr: {d.get('instr_ident','')}",
        f"RESULT: {v['result']}",
        f"By: {v['verifier_name'] or '-'} {(v['verified_at'] or '')[:10]}",
    ]
    return ascii_safe("\n".join(lines))


class QR(Flowable):
    def __init__(self, text, size=38 * mm):
        super().__init__()
        self.text, self.size = text, size
        self.width = self.height = size

    def draw(self):
        w = QrCodeWidget(self.text, barLevel="L")
        b = w.getBounds()
        bw, bh = b[2] - b[0], b[3] - b[1]
        dr = Drawing(self.size, self.size, transform=[self.size / bw, 0, 0, self.size / bh, 0, 0])
        dr.add(w)
        renderPDF.draw(dr, self.canv, 0, 0)


def _u(x):
    return x.replace("\u00b5", "u").replace("\u03bc", "u") if isinstance(x, str) else x


def build_pdf(v, d, checks, log, lab_label, now=None):
    now = now or datetime.now()
    # the built-in PDF font has no micro sign: print it as "u" (um)
    d = {k: _u(x) for k, x in d.items()}
    checks = [{**c, "reason": _u(c["reason"]), "title": _u(c["title"])} for c in checks]
    log = [{**e, "reason": _u(e["reason"])} for e in log]
    v = {**v, "verified_at": (v["verified_at"] or "").replace("T", " ")}
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm, topMargin=14 * mm,
                            bottomMargin=14 * mm, title=f"Verification V-{v['id']:05d}",
                            author=v["verifier_name"] or "Calibration Certificate Verifier")
    ss = getSampleStyleSheet()
    H1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=16, alignment=0, spaceAfter=2)
    H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=11, spaceBefore=8, spaceAfter=3)
    N = ParagraphStyle("n", parent=ss["Normal"], fontSize=8.5, leading=10.5)
    S = ParagraphStyle("s", parent=N, fontSize=7.5, leading=9, textColor=GREY)

    story = [Paragraph("Calibration Certificate Verification Report", H1),
             Paragraph("Procedure: IN REL 002 Annexure REL 2.1 - Procedure for verification of calibration certificate", S),
             Spacer(1, 4)]

    result = v["result"]
    big = ParagraphStyle("big", parent=N, fontSize=22, leading=24, textColor=COL.get(result, GREY),
                         fontName="Helvetica-Bold")
    head = Table([[
        [Paragraph("RESULT", S), Paragraph(result, big),
         Paragraph(f"Report V-{v['id']:05d} &nbsp; revision {v['revision']}", N)],
        QR(qr_text(v, d, lab_label)),
    ]], colWidths=[120 * mm, 60 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                              ("BOX", (0, 0), (-1, -1), 0.6, colors.lightgrey),
                              ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8)]))
    story += [head, Paragraph("Scan the QR code to read the result.", S)]

    info = [
        ["Certificate no.", d.get("cert_no", ""), "Calibration lab", f"{d.get('lab_name','')} ({d.get('nabl_no') or 'internal'})"],
        ["Calibrated for", d.get("customer_name", ""), "Instrument", f"{d.get('instr_type','')}"],
        ["Identification", d.get("instr_ident", ""), "Range / L.C.", f"{d.get('instr_range','')} / {d.get('instr_lc','')}"],
        ["Mfr. S. No. / Make", f"{d.get('instr_serial','')} / {d.get('instr_make','')}", "Calibration date",
         d.get("cal_date", "")],
        ["Due date", d.get("due_date", ""), "Issue date", d.get("issue_date", "")],
        ["Source file", v["file_name"] or "", "Verified on", (v["verified_at"] or "not yet signed off")[:16]],
    ]
    t = Table([[Paragraph(f"<b>{a}</b>", N), Paragraph(str(b), N), Paragraph(f"<b>{c}</b>", N), Paragraph(str(e), N)]
               for a, b, c, e in info], colWidths=[30 * mm, 60 * mm, 30 * mm, 60 * mm])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.lightgrey), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
                           ("BACKGROUND", (2, 0), (2, -1), colors.whitesmoke)]))
    story += [Paragraph("Certificate details", H2), t]

    rows = [[Paragraph("<b>Rule</b>", N), Paragraph("<b>Check</b>", N), Paragraph("<b>Status</b>", N),
             Paragraph("<b>Finding</b>", N)]]
    styles = [("GRID", (0, 0), (-1, -1), 0.3, colors.lightgrey), ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke),
              ("VALIGN", (0, 0), (-1, -1), "TOP")]
    for i, c in enumerate(checks, start=1):
        code = "Extra" if c["code"] == "X1" else c["code"]
        tag = " (reviewed)" if c["overridden"] else ""
        st = ParagraphStyle("st", parent=N, textColor=COL.get(c["status"], GREY), fontName="Helvetica-Bold")
        rows.append([Paragraph(code, N), Paragraph(c["title"], N), Paragraph(c["status"] + tag, st),
                     Paragraph(c["reason"], N)])
    ct = Table(rows, colWidths=[12 * mm, 55 * mm, 22 * mm, 91 * mm], repeatRows=1)
    ct.setStyle(TableStyle(styles))
    story += [Paragraph("Checks", H2), ct]

    if log:
        lr = [[Paragraph(f"<b>{h}</b>", N) for h in ("When", "By", "Rule", "Change", "Reason")]]
        for e in log:
            lr.append([Paragraph(e["ts"][:16], N), Paragraph(e["by_user"], N), Paragraph(e["code"], N),
                       Paragraph(f"{e['old_status']} to {e['new_status']}", N), Paragraph(e["reason"] or "", N)])
        lt = Table(lr, colWidths=[28 * mm, 28 * mm, 14 * mm, 30 * mm, 80 * mm], repeatRows=1)
        lt.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.lightgrey),
                                ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        story += [Paragraph("Review changes (log)", H2), lt]

    sign = Table([[Paragraph("<b>Verified by</b>", N), Paragraph(v["verifier_name"] or "-", N),
                   Paragraph("<b>Remark</b>", N), Paragraph(v["verifier_remark"] or "-", N)],
                  [Paragraph("<b>Signature</b>", N), "", Paragraph("<b>Date</b>", N),
                   Paragraph((v["verified_at"] or "")[:10], N)]],
                 colWidths=[28 * mm, 55 * mm, 22 * mm, 75 * mm], rowHeights=[None, 14 * mm])
    sign.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.lightgrey), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [KeepTogether([Paragraph("Sign-off (rule 5)", H2), sign])]

    def footer(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(GREY)
        canvas.drawString(14 * mm, 8 * mm, f"V-{v['id']:05d} | generated {now:%d/%m/%Y %H:%M} | page {doc_.page}")
        canvas.drawRightString(A4[0] - 14 * mm, 8 * mm, "Automated check - result reflects the reviewed statuses above")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()
