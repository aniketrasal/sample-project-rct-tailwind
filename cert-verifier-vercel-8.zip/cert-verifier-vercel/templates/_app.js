(function(){
  var $=function(s,r){return (r||document).querySelector(s)},$$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
  /* toasts: close button, auto-hide the friendly ones */
  $$('.toast').forEach(function(t){
    var b=$('.x',t); if(b) b.addEventListener('click',function(){t.remove()});
    if(!t.classList.contains('error')) setTimeout(function(){t.style.transition='opacity .4s';t.style.opacity=0;setTimeout(function(){t.remove()},450)},7000);
  });
  /* dialogs (bottom sheets) */
  $$('[data-open]').forEach(function(b){b.addEventListener('click',function(){var d=document.getElementById(b.getAttribute('data-open')); if(d&&d.showModal) d.showModal();})});
  $$('[data-close]').forEach(function(b){b.addEventListener('click',function(){var d=b.closest('dialog'); if(d) d.close();})});
  $$('dialog').forEach(function(d){
    d.addEventListener('click',function(e){ if(e.target===d) d.close(); });
    if(d.hasAttribute('data-autoopen') && d.showModal) { try{ d.showModal(); }catch(e){} }
  });
  /* review sheet */
  var rv=document.getElementById('reviewSheet');
  $$('[data-review]').forEach(function(b){b.addEventListener('click',function(){
    if(!rv) return;
    $('#rv_code').value=b.getAttribute('data-code');
    $('#rv_title').textContent='Rule '+b.getAttribute('data-code');
    $('#rv_what').textContent=b.getAttribute('data-title');
    $('#rv_cur').textContent='Now: '+b.getAttribute('data-cur')+' (automatic result: '+b.getAttribute('data-auto')+')';
    var want=b.getAttribute('data-cur')==='OK'?'NOT OK':'OK';
    $$('input[name=new_status]',rv).forEach(function(r){r.checked=(r.value===want)});
    var ar=$('#rv_auto_wrap'); if(ar) ar.style.display=b.getAttribute('data-ovr')==='1'?'':'none';
    $('#rv_reason').value=''; rv.showModal();
  })});
  /* result filter chips */
  $$('[data-filter]').forEach(function(c){c.addEventListener('click',function(){
    var f=c.getAttribute('data-filter');
    $$('[data-filter]').forEach(function(x){x.classList.toggle('on',x===c)});
    $$('.rule').forEach(function(r){var s=r.getAttribute('data-status'); r.classList.toggle('hidden', f!=='all' && !(f==='attn'?s==='attn':s===f));});
  })});
  var pre=$('[data-filter][data-default]'); if(pre) pre.click();
  /* stop double submits */
  $$('form').forEach(function(f){ if(f.hasAttribute('data-nolock')) return;
    f.addEventListener('submit',function(){ var b=$('button[type=submit],button:not([type])',f); if(b && !b.disabled){ setTimeout(function(){b.disabled=true; b.setAttribute('data-t',b.textContent); b.textContent='Please wait...'},0);} });
  });
  /* confirm */
  $$('form[data-confirm]').forEach(function(f){f.addEventListener('submit',function(e){ if(!confirm(f.getAttribute('data-confirm'))) e.preventDefault(); })});
  /* close the user menu when tapping elsewhere */
  document.addEventListener('click',function(e){var m=$('.usermenu'); if(m && m.open && !m.contains(e.target)) m.open=false;});
  /* back/forward cache: re-enable buttons */
  window.addEventListener('pageshow',function(){ $$('button[data-t]').forEach(function(b){b.disabled=false; b.textContent=b.getAttribute('data-t');}); });
})();
