"""The 20 checks of IN REL 002 (Annexure REL 2.1) plus the acceptance-criteria check.

Each check returns a dict: code, title, status (OK / NOT OK / N/A), reason, pending.
 - NOT OK  : the certificate says something, and it is out of spec / wrong
 - N/A     : the information was not found on the certificate, or the rule does not apply
             (this is the owner's rule: "not ok when out of spec, N/A when you don't find it")
 - pending : the check cannot be finished yet (lab or scope not in the lab list, grade not chosen, rule 5 sign-off)
"""
import difflib
import re
from datetime import date, datetime

OK, NOK, NA = "OK", "NOT OK", "N/A"

# Rule 3f lists "Model No., Quantity" but many certificates (including the sample) carry
# neither. Only these fields are treated as mandatory; the others are reported as a note.
REQUIRED_3F = ["instr_ident", "instr_type", "instr_serial", "instr_range", "instr_lc", "instr_make"]
OPTIONAL_3F = ["instr_model", "instr_qty"]

TITLES = {
    "1": "Calibration done by NABL lab (or ISO/IEC 17025 minimum if internal)",
    "2": "Lab accreditation valid at time of calibration for all parameters measured",
    "3a": "Title - calibration certificate or report",
    "3b": "Name & address of lab, location in case of site calibration",
    "3c": "Certificate number and page numbers on each page, end of certificate identified",
    "3d": "Name & address (customer)",
    "3e": "Identification of calibration method used",
    "3f": "Adequate description of equipment (ID, name, Mfr. S. No., range, L.C., make, model, qty)",
    "3g": "Dates of receipt, calibration, due date and issue date",
    "3h": "Calibration results with appropriate units of measurement",
    "3i": "Name, function & signature of person authorizing the certificate",
    "3j": "Statement that results relate only to the items calibrated",
    "3k": "Environmental conditions",
    "3l": "Uncertainty of measurement with unit, at 95.45% or 95% confidence",
    "3m": "Coverage factor k",
    "3n": "Evidence that standards used are traceable, with valid traceability",
    "3o": "Calibrated master validity",
    "4": "Operating range of the instrument is calibrated",
    "5": "Remark with acceptance status, signed by the person who verified",
    "6": "Temperature & humidity during calibration within limits",
    "X1": "Observed results within the permitted limits printed on the certificate (EMPE/SMPE or grade formulas)",
}
ORDER = ["1", "2", "3a", "3b", "3c", "3d", "3e", "3f", "3g", "3h", "3i", "3j", "3k",
         "3l", "3m", "3n", "3o", "4", "5", "6", "X1"]


# ---------------------------------------------------------------- helpers
def pdate(s):
    """Parse dd/mm/yyyy, dd-mm-yyyy, dd.mm.yyyy or yyyy-mm-dd. Returns date or None."""
    s = (s or "").strip()
    if not s:
        return None
    m = re.match(r"^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$", s)
    try:
        if m:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", s)
        if m:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None
    return None


def fnum(s):
    try:
        return float(str(s).replace(",", ".").replace("−", "-").strip())
    except (ValueError, TypeError):
        return None


def parse_range(s):
    """'0 To 200 mm' -> (0.0, 200.0). Returns None if it cannot be read."""
    m = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:to|-|–|—)\s*(\d+(?:\.\d+)?)", s or "", re.I)
    if not m:
        return None
    return float(m.group(1)), float(m.group(2))


def parse_rows(text):
    """Lines 'nominal, observed, error' -> list of (nominal, observed|None, error|None)."""
    rows = []
    for line in (text or "").splitlines():
        parts = [p.strip() for p in re.split(r"[,;\t]+", line) if p.strip() != ""]
        if not parts:
            continue
        nums = [fnum(p) if p not in ("-", "--", "–") else None for p in parts[:3]]
        while len(nums) < 3:
            nums.append(None)
        if nums[0] is None:
            continue
        rows.append(tuple(nums))
    return rows


def parse_standards(text):
    out = []
    for line in (text or "").splitlines():
        p = [x.strip() for x in line.split("|")]
        if not any(p):
            continue
        p += [""] * (5 - len(p))
        out.append(dict(desc=p[0], ident=p[1], cert_no=p[2], trace=p[3], valid_upto=p[4]))
    return out


def similar(a, b):
    na = re.sub(r"[^a-z0-9 ]", " ", (a or "").lower()).split()
    nb = re.sub(r"[^a-z0-9 ]", " ", (b or "").lower()).split()
    if not na or not nb:
        return 0.0
    overlap = len(set(na) & set(nb)) / max(len(set(na)), len(set(nb)))
    ratio = difflib.SequenceMatcher(None, " ".join(na), " ".join(nb)).ratio()
    return max(overlap, ratio)


def norm_id(s):
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def _r(code, status, reason, pending=False):
    return dict(code=code, title=TITLES[code], status=status, reason=reason, pending=pending)


def _has(d, k):
    return bool(str(d.get(k, "")).strip())


def _flag(d, k):
    return str(d.get(k, "")).lower() in ("1", "true", "on", "yes")


# ---------------------------------------------------------------- context
class Ctx:
    """What the rules need from the database."""

    def __init__(self, labs=None, scopes=None, instruments=None, env_limits=None, today=None):
        self.labs = labs or []             # list of dict
        self.scopes = scopes or {}         # lab_id -> list of dict
        self.instruments = instruments or []
        self.env = {e["key"]: e for e in (env_limits or [])}
        self.today = today or date.today()

    def lab_by_nabl(self, nabl):
        n = norm_id(nabl)
        for lab in self.labs:
            if norm_id(lab["nabl_no"]) == n:
                return lab
        return None



def parse_params(text):
    """Lines 'parameter | value' -> list of (name, float value)."""
    out = []
    for line in (text or "").splitlines():
        p = [x.strip() for x in line.split("|")]
        if len(p) >= 2 and p[0] and fnum(p[1]) is not None:
            out.append((p[0], fnum(p[1])))
    return out


def parse_formula(s):
    """'3 + (L/250 )' -> (3.0, 'l', 250.0)   (limit = a + variable / b)"""
    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*\+\s*\(\s*([A-Za-z]\w*)\s*/\s*(\d+(?:\.\d+)?)\s*\)\s*", s or "")
    return (float(m.group(1)), m.group(2).lower(), float(m.group(3))) if m else None


# ---------------------------------------------------------------- rules 1 & 2
def rule_1(d, ctx):
    if d.get("calibration_kind") == "internal":
        if _flag(d, "wi_ok") and _flag(d, "competency_ok"):
            return _r("1", OK, "Internal calibration: calibration work instruction and competency of "
                               "calibration personnel confirmed manually (ISO/IEC 17025).")
        missing = [n for k, n in (("wi_ok", "calibration work instruction"),
                                  ("competency_ok", "competency of calibration personnel")) if not _flag(d, k)]
        return _r("1", NOK, "Internal calibration: not confirmed - " + ", ".join(missing) + ".")
    nabl = d.get("nabl_no", "")
    if not nabl.strip():
        return _r("1", NA, "NABL lab number (CC-xxxx) not found on the certificate.")
    lab = ctx.lab_by_nabl(nabl)
    if not lab:
        return _r("1", NA, f"Lab {nabl} is not in the lab list. Add this lab to finish the check.", pending=True)
    if _has(d, "lab_name") and similar(d.get("lab_name", ""), lab["name"]) < 0.55:
        return _r("1", NOK, f"{nabl} is registered as '{lab['name']}' but the certificate shows '{d.get('lab_name','')}'.")
    src = " (taken from the ULR)" if _flag(d, "nabl_from_ulr") else ""
    if not _flag(d, "nabl_symbol"):
        return _r("1", NA, f"NABL symbol not found in this file (no letterhead). Lab number {lab['nabl_no']}{src} is in the "
                           f"lab list as '{lab['name']}'. Check the symbol on the printed copy, then change to OK in Review.")
    where = f" ({d['nabl_symbol_src']})" if d.get("nabl_symbol_src") else ""
    return _r("1", OK, f"NABL symbol{where} and number {lab['nabl_no']} found; lab is in the lab list ({lab['name']}).")


def rule_2(d, ctx):
    if d.get("calibration_kind") == "internal":
        if _flag(d, "wi_ok") and _flag(d, "competency_ok"):
            return _r("2", OK, "Internal calibration - NABL accreditation not applicable.")
        return _r("2", NOK, "Internal calibration - ISO/IEC 17025 checklist not completed.")
    lab = ctx.lab_by_nabl(d.get("nabl_no", ""))
    if not lab:
        return _r("2", NA, "Lab not in the lab list, accreditation cannot be checked.", pending=True)
    cal = pdate(d.get("cal_date"))
    if not cal:
        return _r("2", NA, "Calibration date not found.")
    if lab["status"] != "Active":
        return _r("2", NOK, f"Lab status is '{lab['status']}'.")
    vf, vt = pdate(lab["valid_from"]), pdate(lab["valid_to"])
    if not vt:
        return _r("2", NA, "Accreditation validity dates are not stored for this lab.", pending=True)
    if (vf and cal < vf) or cal > vt:
        start = f"{vf:%d/%m/%Y}" if vf else "(not stored)"
        return _r("2", NOK, f"Calibration date {cal:%d/%m/%Y} is outside accreditation validity {start} to {vt:%d/%m/%Y}.")
    scopes = ctx.scopes.get(lab["id"], [])
    if not scopes:
        return _r("2", NA, f"Accreditation valid ({vt:%d/%m/%Y}), but no scope is stored for this lab. "
                           "Add the scope to finish the check.", pending=True)
    itype = (d.get("instr_type") or "").lower()
    if not itype:
        return _r("2", NA, "Instrument type not found, scope cannot be checked.")
    rng = parse_range(d.get("instr_range", ""))
    cands = []
    for s in scopes:
        words = [w for w in re.split(r"\W+", s["instrument_type"].lower()) if len(w) > 2]
        if (words and all(w in itype for w in words)) or s["instrument_type"].lower() in itype:
            cands.append(s)
    if not cands:
        return _r("2", NOK, f"'{d.get('instr_type')}' is not in the scope of lab {lab['nabl_no']}.")
    note = ""
    cover = cands
    if rng:
        cover = [s for s in cands if s["range_min"] <= rng[0] and s["range_max"] >= rng[1]]
        if not cover:
            return _r("2", NOK, f"Range {rng[0]:g}-{rng[1]:g} is outside the lab scope for this instrument.")
    else:
        note = f" The size '{d.get('instr_range','')}' is not a measuring range, so only the instrument type was compared."
    unc = fnum(d.get("unc_value"))
    unit = (d.get("unc_unit") or "").lower()
    if unc is not None and unit.startswith("mm"):
        unc *= 1000
    best = min((s["cmc_um"] for s in cover if s["cmc_um"] is not None), default=None)
    if unc is not None and best is not None and unc < best:
        return _r("2", NOK, f"Reported uncertainty {unc:g} um is better than the lab's CMC {best:g} um.")
    return _r("2", OK, f"Accreditation valid {cal:%d/%m/%Y} (expires {vt:%d/%m/%Y}); instrument is in scope." + note)


# ---------------------------------------------------------------- rule 3
def rule_3a(d, ctx):
    t = (d.get("title") or "").lower()
    if re.search(r"calibration\s+(certificate|report)", t):
        return _r("3a", OK, f"Title '{d['title']}' present.")
    return _r("3a", NA, "Title 'Calibration Certificate' / 'Calibration Report' not found.")


def rule_3b(d, ctx):
    miss = []
    if not _has(d, "lab_name"):
        miss.append("lab name")
    if len(d.get("lab_address", "").strip()) < 12:
        miss.append("lab address")
    if not _has(d, "lab_location"):
        miss.append("calibration location (in lab / site)")
    if miss:
        extra = " The lab letterhead is not in this file." if "lab name" in miss and "lab address" in miss else ""
        return _r("3b", NA, "Not found: " + ", ".join(miss) + "." + extra)
    return _r("3b", OK, f"Lab name, address and location ({d['lab_location']}) present.")


def rule_3c(d, ctx):
    miss = []
    if not _has(d, "cert_no"):
        miss.append("certificate number")
    m = re.search(r"(\d+)\s*(?:of|/)\s*(\d+)", d.get("page_text", ""), re.I)
    if not m:
        miss.append("page numbers (Page x of y)")
    pf, total = d.get("pages_found", ""), fnum(d.get("page_total"))
    if pf and total:
        have = {int(x) for x in pf.split(",") if x.strip().isdigit()}
        lack = sorted(set(range(1, int(total) + 1)) - have)
        if lack:
            miss.append(f"certificate number + page number on page {', '.join(map(str, lack))}")
    last_page = bool(m) and m.group(1) == m.group(2) and (not pf or str(m.group(2)) in pf.split(","))
    if not _flag(d, "end_marker") and not (last_page or (pf and total and str(int(total)) in pf.split(","))):
        miss.append("clear identification of the end of the certificate")
    if miss:
        return _r("3c", NA, "Not found: " + ", ".join(miss) + ".")
    tail = ""
    if m and int(m.group(2)) > 1 and not pf:
        tail = f" (only one page of {m.group(2)} was uploaded; the other pages were not checked)"
    elif pf:
        tail = f" (all {m.group(2)} pages checked)"
    how = "end of certificate marked" if _flag(d, "end_marker") else "end identified by the last page number (no separate 'End of certificate' line)"
    return _r("3c", OK, f"Certificate no. {d['cert_no']}, page {m.group(1)} of {m.group(2)}, {how}." + tail)


def rule_3d(d, ctx):
    if not _has(d, "customer_name"):
        return _r("3d", NA, "Customer name ('Calibrated for') not found.")
    if len(d.get("customer_address", "").strip()) < 8:
        return _r("3d", NA, "Customer address not found.")
    return _r("3d", OK, f"Customer: {d['customer_name']}.")


def rule_3e(d, ctx):
    if _has(d, "method_no"):
        extra = f" (reference standard: {d['reference_std']})" if _has(d, "reference_std") else ""
        return _r("3e", OK, f"Calibration procedure {d['method_no']}{extra}.")
    return _r("3e", NA, "Calibration procedure / method not found.")


def rule_3f(d, ctx):
    names = dict(instr_ident="identification", instr_type="name/type", instr_serial="Mfr. serial no.",
                 instr_range="range / size", instr_lc="least count", instr_make="make",
                 instr_model="model no.", instr_qty="quantity")
    required = [k for k in REQUIRED_3F if not (k == "instr_lc" and d.get("instr_lc_applicable") == "no")]
    miss = [names[k] for k in required if not _has(d, k)]
    if miss:
        return _r("3f", NA, "Not found: " + ", ".join(miss) + ".")
    note = [names[k] for k in OPTIONAL_3F if not _has(d, k)]
    if d.get("instr_lc_applicable") == "no":
        note.append("least count (this certificate has no L.C. column)")
    tail = f" Not stated (not mandatory here): {', '.join(note)}." if note else ""
    return _r("3f", OK, f"Instrument {d['instr_ident']} ({d['instr_make']}, S/N {d['instr_serial']}, {d['instr_range']}) described." + tail)


def rule_3g(d, ctx):
    keys = [("receipt_date", "receipt date"), ("cal_date", "calibration date"),
            ("due_date", "due date"), ("issue_date", "issue date")]
    miss = [n for k, n in keys if not pdate(d.get(k))]
    if miss:
        return _r("3g", NA, "Not found or not a valid date: " + ", ".join(miss) + ".")
    rc, cal, due, iss = (pdate(d[k]) for k, _ in keys)
    if cal < rc:
        return _r("3g", NOK, "Calibration date is before the receipt date.")
    if iss < cal:
        return _r("3g", NOK, "Issue date is before the calibration date.")
    if due <= cal:
        return _r("3g", NOK, "Due date is not after the calibration date.")
    return _r("3g", OK, f"Receipt {rc:%d/%m/%Y}, calibrated {cal:%d/%m/%Y}, due {due:%d/%m/%Y}, issued {iss:%d/%m/%Y}.")


def rule_3h(d, ctx):
    rows = parse_rows(d.get("results_external")) + parse_rows(d.get("results_internal")) + \
        parse_rows(d.get("results_depth"))
    params = parse_params(d.get("results_params"))
    if not rows and not params:
        return _r("3h", NA, "No calibration results found.")
    unit_text = " ".join([d.get("results_unit_text", ""), d.get("instr_lc", ""), d.get("instr_range", "")])
    if not re.search(r"mm|µm|μm|um|inch|\bin\b|\bV\b|\bA\b|°C", unit_text, re.I):
        return _r("3h", NA, "Units of measurement not found.")
    n = len(rows) + len(params)
    what = "calibration point(s)" if rows else "measured parameter(s)"
    return _r("3h", OK, f"{n} {what} reported with units.")


def rule_3i(d, ctx):
    miss = []
    if not _has(d, "approver_name"):
        miss.append("name")
    if not _has(d, "approver_function"):
        miss.append("function")
    if not _flag(d, "approver_signature"):
        miss.append("signature")
    if miss:
        extra = f" ({d['approver_name']}, {d['approver_function']} are present)" if not ("name" in miss or "function" in miss) is False else ""
        have = [d[k] for k in ("approver_name", "approver_function") if _has(d, k)]
        extra = f" Found: {', '.join(have)}." if have else ""
        return _r("3i", NA, "Authorising person - not found: " + ", ".join(miss) + "." + extra)
    return _r("3i", OK, f"{d['approver_name']} ({d['approver_function']}) - signature present.")


def rule_3j(d, ctx):
    if re.search(r"(relate|pertain)s?\s+only", d.get("statement_text", ""), re.I):
        return _r("3j", OK, "Statement that results relate only to the items calibrated is present.")
    return _r("3j", NA, "Statement that results relate only to the items calibrated not found.")


def rule_3k(d, ctx):
    t, h = fnum(d.get("env_temp")), fnum(d.get("env_humidity"))
    if t is None and h is None:
        return _r("3k", NA, "Environmental conditions not found.")
    parts = []
    if t is not None:
        parts.append(f"temperature {t:g} C")
    if h is not None:
        parts.append(f"humidity {h:g} %RH")
    if t is None or h is None:
        return _r("3k", NA, "Reported: " + ", ".join(parts) + ". Not found: " + ("temperature" if t is None else "humidity") + ".")
    return _r("3k", OK, "Reported: " + ", ".join(parts) + ".")


def rule_3l(d, ctx):
    u = fnum(d.get("unc_value"))
    if u is None:
        return _r("3l", NA, "Uncertainty of measurement not found.")
    if not re.search(r"mm|µm|μm|um", d.get("unc_unit", ""), re.I):
        return _r("3l", NA, "Uncertainty is given without a unit.")
    c = fnum(d.get("unc_conf"))
    if c is None:
        return _r("3l", NA, "Confidence level (95.45% / 95%) not found.")
    if abs(c - 95.45) > 0.01 and abs(c - 95) > 0.01:
        return _r("3l", NOK, f"Confidence level {d.get('unc_conf')}% is not 95.45% / 95%.")
    return _r("3l", OK, f"Uncertainty +/-{u:g} {d['unc_unit']} at {c:g}% confidence.")


def rule_3m(d, ctx):
    k = fnum(d.get("k_factor"))
    if k is None:
        return _r("3m", NA, "Coverage factor k not found.")
    return _r("3m", OK, f"Coverage factor k = {k:g}.")


def rule_3n(d, ctx):
    stds = parse_standards(d.get("standards"))
    if not stds:
        return _r("3n", NA, "No standards / equipment listed.")
    bad, missing, unknown_labs = [], [], []
    cal = pdate(d.get("cal_date"))
    for s in stds:
        name = s["ident"] or s["desc"] or "?"
        if not s["ident"]:
            missing.append(f"{name}: identification")
        if not s["cert_no"]:
            missing.append(f"{name}: calibration certificate no.")
        if not s["trace"]:
            missing.append(f"{name}: traceability")
        else:
            lab = ctx.lab_by_nabl(s["trace"])
            if lab and cal:
                vt = pdate(lab["valid_to"])
                if lab["status"] != "Active" or (vt and cal > vt):
                    bad.append(f"{name}: traceability lab {lab['nabl_no']} not valid on the calibration date")
            elif not lab and norm_id(s["trace"]) not in unknown_labs:
                unknown_labs.append(norm_id(s["trace"]))
    if bad:
        return _r("3n", NOK, "; ".join(bad) + ".")
    if missing:
        return _r("3n", NA, "Not found: " + "; ".join(missing) + ".")
    traced = sorted({s["trace"] for s in stds})
    note = ""
    if unknown_labs:
        shown = ", ".join(t for t in traced if norm_id(t) in unknown_labs)
        note = f" Traceability labs not in your lab list (their validity was not checked): {shown}."
    return _r("3n", OK, f"{len(stds)} standard(s) with ID, certificate no. and NABL traceability ({', '.join(traced)})." + note)


def rule_3o(d, ctx):
    stds = parse_standards(d.get("standards"))
    cal = pdate(d.get("cal_date"))
    if not stds or not cal:
        return _r("3o", NA, "Standards or calibration date not found.")
    bad, unknown = [], []
    for s in stds:
        v = pdate(s["valid_upto"])
        if not v:
            unknown.append(s["desc"] or s["ident"])
        elif v < cal:
            bad.append(f"{s['desc']} valid up to {v:%d/%m/%Y}")
    if bad:
        return _r("3o", NOK, "Master expired before calibration date " + f"{cal:%d/%m/%Y}: " + "; ".join(bad) + ".")
    if unknown:
        return _r("3o", NA, "Valid-up-to date not found for: " + ", ".join(unknown) + ".")
    first = min(pdate(s["valid_upto"]) for s in stds)
    return _r("3o", OK, f"All {len(stds)} masters are valid on the calibration date {cal:%d/%m/%Y} (earliest expiry {first:%d/%m/%Y}).")


# ---------------------------------------------------------------- rules 4, 5, 6
def rule_4(d, ctx):
    crange = parse_range(d.get("instr_range", ""))
    ext = parse_rows(d.get("results_external"))
    if not ext:
        if parse_params(d.get("results_params")):
            return _r("4", OK, "Default OK: this certificate reports measured parameters (no measuring range to cover). "
                               "Reviewer: confirm the operating range is covered, or change to NOT OK.")
        return _r("4", NA, "No calibration points found.")
    if not crange:
        return _r("4", NA, "Instrument range not found.")
    inst = None
    ident = norm_id(d.get("instr_ident"))
    for i in ctx.instruments:
        if norm_id(i["ident"]) == ident:
            inst = i
    if inst:
        used = (inst["range_min"], inst["range_max"])
        src = f"range in use {used[0]:g}-{used[1]:g} (instrument list)"
        if used[0] < crange[0] or used[1] > crange[1]:
            return _r("4", NOK, f"Range in use {used[0]:g}-{used[1]:g} is outside the calibrated range "
                                f"{crange[0]:g}-{crange[1]:g}.")
    else:
        used = crange
        src = f"certificate range {crange[0]:g}-{crange[1]:g} (instrument not in instrument list)"
    pts = [r[0] for r in ext]
    if max(pts) < used[1]:
        return _r("4", NOK, f"Highest calibrated point {max(pts):g} is below the top of the {src}.")
    if min(pts) > used[0]:
        return _r("4", NOK, f"Lowest calibrated point {min(pts):g} is above the bottom of the {src}.")
    return _r("4", OK, f"Calibration points {min(pts):g}-{max(pts):g} cover the {src}.")


def rule_5(d, ctx, verifier=None, finalizing=False):
    if not finalizing:
        return _r("5", NA, "Waiting for verifier remark and signature at sign-off.", pending=True)
    v = verifier or {}
    if not v.get("name") or not v.get("remark"):
        return _r("5", NOK, "Verifier name and remark are required.")
    return _r("5", OK, f"Signed off by {v['name']}: {v['remark']}")


def rule_6(d, ctx):
    key = d.get("instr_class", "dimensional")
    lim = ctx.env.get(key)
    t, h = fnum(d.get("env_temp")), fnum(d.get("env_humidity"))
    if not lim:
        return _r("6", NA, "No temperature / humidity limits defined for this instrument type.")
    if t is None:
        return _r("6", NA, "Temperature not found on the certificate.")
    msgs, bad, missing = [], [], []
    if lim["temp_nom"] is None:
        msgs.append(f"{t:g} C (ambient temperature, no numeric limit)")
    else:
        lo, hi = lim["temp_nom"] - lim["temp_tol"], lim["temp_nom"] + lim["temp_tol"]
        if lo <= t <= hi:
            msgs.append(f"{t:g} C within {lim['temp_nom']:g} +/- {lim['temp_tol']:g}")
        else:
            bad.append(f"temperature {t:g} C outside {lim['temp_nom']:g} +/- {lim['temp_tol']:g}")
    if lim["rh_max"] is None:
        msgs.append("humidity not applicable")
    elif h is None:
        missing.append("humidity")
    elif h < lim["rh_max"]:
        msgs.append(f"{h:g} %RH below {lim['rh_max']:g}")
    else:
        bad.append(f"humidity {h:g} %RH not below {lim['rh_max']:g}")
    label = lim["label"]
    if bad:
        return _r("6", NOK, f"{label}: " + "; ".join(bad) + ".")
    if missing:
        return _r("6", NA, f"{label}: " + ", ".join(missing) + " not found.")
    return _r("6", OK, f"{label}: " + "; ".join(msgs) + ".")


def _band(nominal, ranges):
    for i, (lo, hi) in enumerate(ranges):
        if (nominal > lo or (i == 0 and nominal >= lo)) and nominal <= hi:
            return i
    return None


def _x1_ranges(d, ctx):
    """Caliper style: observed error per point against EMPE / SMPE per range band."""
    def listnums(s):
        return [fnum(x) for x in re.split(r"[,;\s]+", s or "") if x.strip()]

    ranges = []
    for part in re.split(r"[,;]+", d.get("acc_ranges", "")):
        r = parse_range(part)
        if r:
            ranges.append(r)
    empe, smpe = listnums(d.get("acc_empe")), listnums(d.get("acc_smpe"))
    sections = [("external", parse_rows(d.get("results_external")), empe),
                ("internal", parse_rows(d.get("results_internal")), smpe),
                ("depth", parse_rows(d.get("results_depth")), smpe)]
    if not ranges or not empe:
        return _r("X1", NA, "Acceptance criteria (permissible error table) not found on the certificate.")
    fails, checked, mismatch = [], 0, []
    for name, rows, limits in sections:
        for nom, obs, err in rows:
            if obs is None and err is None:
                continue
            calc = round((obs - nom) * 1000) if obs is not None else None
            use = err if err is not None else calc
            if err is not None and calc is not None and abs(err - calc) > 1.5:
                mismatch.append(f"{name} {nom:g}: error {err:g} um but observed - measured = {calc:g} um")
            b = _band(nom, ranges)
            if b is None or b >= len(limits) or limits[b] is None:
                fails.append(f"{name} {nom:g} mm: no permissible error defined for this range")
                continue
            checked += 1
            if abs(use) > limits[b]:
                fails.append(f"{name} {nom:g} mm: error {use:g} um exceeds +/-{limits[b]:g} um")
    if not checked and not fails:
        return _r("X1", NA, "No observed errors to compare.")
    if fails or mismatch:
        return _r("X1", NOK, "; ".join(fails + mismatch) + ".")
    return _r("X1", OK, f"All {checked} observed errors are within the permissible error; "
                        "reported errors match observed - measured.")


def _x1_formula(d, ctx):
    """Parameter style (e.g. V-block): limit per grade is a formula such as 3 + (L/250)."""
    lines = [l for l in (d.get("acc_formulas") or "").splitlines() if l.strip()]
    header = [c.strip() for c in lines[0].split("|")]
    columns = header[1:]
    table = {}
    for l in lines[1:]:
        cells = [c.strip() for c in l.split("|")]
        if cells and cells[0]:
            table[cells[0].lower()] = cells[1:]
    params = parse_params(d.get("results_params"))
    if not columns or not table:
        return _r("X1", NA, "Acceptance table could not be read - check the 'Grade limits' field.")
    if not params:
        return _r("X1", NA, "No observed values found to compare.")
    grade = (d.get("instr_grade") or "").strip()
    ident = norm_id(d.get("instr_ident"))
    if not grade:
        for i in ctx.instruments:
            if norm_id(i["ident"]) == ident and (i.get("grade") or "").strip():
                grade = i["grade"].strip()
    grades = ", ".join(sorted(table))
    if not grade:
        return _r("X1", NA, f"The certificate gives limits for grades {grades} but does not say which grade this instrument is. "
                            "Enter the Grade in the review form (or in the Instruments list), then re-run.", pending=True)
    row = table.get(grade.lower())
    if row is None:
        return _r("X1", NA, f"Grade '{grade}' is not in the certificate's table (grades: {grades}).", pending=True)
    vars_ = {"l": fnum(d.get("dim_L")), "h1": fnum(d.get("dim_h1")), "h": fnum(d.get("dim_h1"))}
    out_ok, out_bad, skipped = [], [], []
    for name, val in params:
        idx = next((i for i, c in enumerate(columns) if c.lower()[:6] in name.lower()), None)
        if idx is None or idx >= len(row):
            skipped.append(f"{name} ({val:g} um)")
            continue
        f = parse_formula(row[idx])
        if not f:
            return _r("X1", NA, f"Could not read the limit formula '{row[idx]}'.")
        a, var, b = f
        x = vars_.get(var)
        if x is None:
            return _r("X1", NA, f"Limit '{row[idx]}' needs {var.upper()} - enter it in the review form (Instrument -> size values).", pending=True)
        limit = a + x / b
        txt = f"{name}: {val:g} um vs limit {limit:g} um ({row[idx].replace(' ', '')}, {var.upper()}={x:g})"
        (out_ok if abs(val) <= limit else out_bad).append(txt)
    if not out_ok and not out_bad:
        return _r("X1", NA, "None of the measured parameters has a limit in the certificate's table.")
    tail = f" No limit on the certificate for: {', '.join(skipped)} (not checked)." if skipped else ""
    if out_bad:
        return _r("X1", NOK, f"Grade {grade}: exceeds the limit - " + "; ".join(out_bad) + "." + (" Within limit: " + "; ".join(out_ok) + "." if out_ok else "") + tail)
    return _r("X1", OK, f"Grade {grade}: all within limit - " + "; ".join(out_ok) + "." + tail)


def rule_x1(d, ctx):
    return _x1_formula(d, ctx) if _has(d, "acc_formulas") else _x1_ranges(d, ctx)


# ---------------------------------------------------------------- engine
def evaluate(d, ctx, verifier=None, finalizing=False):
    fns = {"1": rule_1, "2": rule_2, "3a": rule_3a, "3b": rule_3b, "3c": rule_3c, "3d": rule_3d,
           "3e": rule_3e, "3f": rule_3f, "3g": rule_3g, "3h": rule_3h, "3i": rule_3i, "3j": rule_3j,
           "3k": rule_3k, "3l": rule_3l, "3m": rule_3m, "3n": rule_3n, "3o": rule_3o, "4": rule_4,
           "6": rule_6, "X1": rule_x1}
    out = []
    for code in ORDER:
        if code == "5":
            out.append(rule_5(d, ctx, verifier, finalizing))
        else:
            try:
                out.append(fns[code](d, ctx))
            except Exception as e:  # never let one bad field crash the whole check
                out.append(_r(code, NA, f"Could not be checked automatically ({e}).", pending=True))
    return out


def overall(results):
    """results: iterable of dicts with status / pending. -> 'NOT OK' | 'PENDING' | 'OK'"""
    results = list(results)
    if any(r["status"] == NOK for r in results):
        return NOK
    if any(r.get("pending") and r["status"] == NA for r in results):
        return "PENDING"
    return OK
