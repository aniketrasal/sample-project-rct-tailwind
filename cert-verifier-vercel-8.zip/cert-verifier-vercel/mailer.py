"""Sending e-mail (verification codes). Works on Vercel: SMTP (e.g. Gmail app password) or the Resend HTTPS API."""
import json
import os
import smtplib
import ssl
import urllib.request
from email.message import EmailMessage


def _env(k, d=""):
    return os.environ.get(k, d).strip()


def configured():
    return bool(_env("CERTV_MAIL_FILE") or _env("RESEND_API_KEY") or (_env("SMTP_HOST") and _env("SMTP_USER") and _env("SMTP_PASSWORD")))


def sender():
    return _env("MAIL_FROM") or _env("SMTP_FROM") or _env("SMTP_USER") or "onboarding@resend.dev"


def send(to, subject, text):
    """Returns (ok, error text)."""
    try:
        if _env("CERTV_MAIL_FILE"):                       # test hook: write the mail to a file instead of sending
            with open(_env("CERTV_MAIL_FILE"), "a", encoding="utf-8") as f:
                f.write(json.dumps({"to": to, "subject": subject, "text": text}) + "\n")
            return True, ""
        if _env("RESEND_API_KEY"):
            req = urllib.request.Request(
                "https://api.resend.com/emails", method="POST",
                data=json.dumps({"from": sender(), "to": [to], "subject": subject, "text": text}).encode(),
                headers={"Authorization": "Bearer " + _env("RESEND_API_KEY"), "Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=15).read()
            return True, ""
        if not configured():
            return False, "E-mail sending is not set up."
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = sender(), to, subject
        msg.set_content(text)
        host, port = _env("SMTP_HOST"), int(_env("SMTP_PORT", "587") or 587)
        if _env("SMTP_SECURITY").lower() == "ssl" or port == 465:
            srv = smtplib.SMTP_SSL(host, port, timeout=15, context=ssl.create_default_context())
        else:
            srv = smtplib.SMTP(host, port, timeout=15)
            if _env("SMTP_SECURITY").lower() != "none":
                srv.starttls(context=ssl.create_default_context())
        with srv:
            srv.login(_env("SMTP_USER"), "".join(_env("SMTP_PASSWORD").split()))   # Gmail shows app passwords with spaces
            srv.send_message(msg)
        return True, ""
    except Exception as e:                                 # never crash the page because of a mail problem
        return False, f"{type(e).__name__}: {str(e)[:150]}"
