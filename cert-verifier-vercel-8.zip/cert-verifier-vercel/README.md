# Cert Verifier - calibration certificate checker (IN REL 002) - Vercel edition

Mobile-friendly web app. Upload a photo or PDF of a calibration certificate, review what was read, and get OK / NOT OK
against the 20 rules of IN REL 002 (plus the EMPE/SMPE permissible-error check), with an editable, logged review
and a PDF report with a QR code.

**Deploy:** read `DEPLOY.md`. **Settings needed:** `SECRET_KEY`, the `SMTP_*` e-mail settings, and a Postgres `DATABASE_URL` (Neon). First sign-in is `admin` / `admin`, then you create your own login.
Missing settings show a "Setup needed" page that says exactly what to add; they never crash the site.

Local try (no Postgres needed, uses a SQLite file): `pip install -r requirements.txt` then
`CERTV_SECURE_COOKIES=0 CERTV_SQLITE=./data/local.db CERTV_MAIL_FILE=./data/mail.jsonl python3 app.py` (codes are written to `data/mail.jsonl` instead of being sent) -> http://127.0.0.1:5000

Tests: `tests/` (rules, database on Postgres + SQLite, full flow, real-browser mobile test). Not deployed (.vercelignore).
