"""TEST ONLY. Stand-in for the 'psycopg' driver (not installable offline) that sends the app's SQL to a real
PostgreSQL server through the psql command. It lets the tests exercise db.py's Postgres code path
(%s placeholders, RETURNING, ON CONFLICT, BYTEA, SERIAL, DOUBLE PRECISION) against real Postgres semantics.
"""
import json
import re
import subprocess
from urllib.parse import urlsplit


def _lit(v):
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return repr(v)
    if isinstance(v, (bytes, bytearray, memoryview)):
        return "'\\x" + bytes(v).hex() + "'::bytea"
    return "'" + str(v).replace("'", "''") + "'"


class OperationalError(Exception):
    pass


class _Col:
    def __init__(self, name):
        self.name = name


class Cursor:
    def __init__(self, rows, names, row_factory):
        self.description = [_Col(n) for n in names] if names else None
        mk = row_factory(self) if (row_factory and names) else None
        self._rows = [mk(tuple(r)) for r in rows] if mk else []

    def fetchone(self):
        return self._rows.pop(0) if self._rows else None

    def fetchall(self):
        r, self._rows = self._rows, []
        return r


class Connection:
    def __init__(self, url, row_factory):
        u = urlsplit(url)
        self.args = ["psql", "-X", "-q", "-t", "-A", "-v", "ON_ERROR_STOP=1", "-h", u.hostname or "127.0.0.1",
                     "-p", str(u.port or 5432), "-U", u.username or "postgres", "-d", u.path.lstrip("/")]
        self.rf = row_factory
        r = subprocess.run(self.args + ["-c", "SELECT 1"], capture_output=True, text=True)   # real psycopg connects eagerly
        if r.returncode != 0:
            raise OperationalError(r.stderr.strip())

    def execute(self, sql, params=()):
        parts = sql.split("%s")
        assert len(parts) - 1 == len(params), f"placeholder count mismatch in: {sql}"
        stmt = parts[0] + "".join(_lit(p) + parts[i + 1] for i, p in enumerate(params))
        up = stmt.lstrip().upper()
        returns = (up.startswith("SELECT") and "PG_ADVISORY" not in up) or " RETURNING " in up
        run = f"WITH t AS ({stmt}) SELECT row_to_json(t) FROM t" if returns else stmt
        r = subprocess.run(self.args, input=run, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"PG error: {r.stderr.strip()}\nSQL: {stmt[:300]}")
        rows, names = [], None
        for line in r.stdout.splitlines():
            if not line.strip():
                continue
            d = json.loads(line)
            names = names or list(d)
            vals = []
            for v in d.values():
                if isinstance(v, str) and re.fullmatch(r"\\x[0-9a-f]*", v):
                    v = bytes.fromhex(v[2:])
                vals.append(v)
            rows.append(vals)
        if returns and names is None:
            names = []
        return Cursor(rows, names, self.rf)

    def commit(self): pass
    def rollback(self): pass
    def close(self): pass


def connect(url, row_factory=None, **kw):
    return Connection(url, row_factory)
