#!/bin/sh
# usage: run_browser.sh <sample_dir>   - fresh server + empty database, then the real-browser test
S=$1; D=$(mktemp -d /tmp/claude-0/-home-claude/d0d99fd1-25f7-5a2c-9db4-8e3d75267d9a/scratchpad/srv.XXXX); echo $D > /tmp/claude-0/srvdir
pkill -f "python3 app.py" 2>/dev/null; sleep 1
cd /home/claude/cert-verifier-vercel
export CERTV_SQLITE=$D/t.db; python3 -c "import app,db;db.init_db(app.generate_password_hash('x'));c=db.connect();c.execute(\"UPDATE users SET pw_hash=?,must_setup=0,email='t@x.io' WHERE username='admin'\",(app.generate_password_hash('test-pass-123'),));c.commit()"
SECRET_KEY=$(printf 'k%.0s' $(seq 40)) CERTV_SECURE_COOKIES=0 PORT=5066 python3 app.py > $D/log 2>&1 &
sleep 3; python3 -I tests/browser_ui.py $S
