import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import extract
base = open("/tmp/claude-0/sc/jsout-1.txt").read() if os.path.exists("/tmp/claude-0/sc/jsout-1.txt") else ""
ok = ["CC - 2656\n\nULR : CC265626000017387F", "CC-2656", "CC 2656", "CC—2656", "CC_2656", "Le\nCC = 2656\nPRL", "National Accreditation Board For Testing & Calibration Laboratory",
      "NABL"]
bad = ["ULR : CC265626000017387F", "", "ooratory.co.in\nPune - 411052.", "CC-26"]
n = 0
for t in ok:
    d = extract.apply_logo({}, t); assert d.get("nabl_symbol") == "on", t; n += 1
for t in bad:
    d = extract.apply_logo({}, t); assert not d.get("nabl_symbol"), t; n += 1
d = extract.fields_from_ocr(base, logo_text="CC - 2656\nULR : CC265626000017387F") if base else {}
if base:
    assert d["nabl_symbol"] == "on" and d["nabl_no"] == "CC-2656", d.get("nabl_symbol")
print("LOGO TESTS PASSED", n)
