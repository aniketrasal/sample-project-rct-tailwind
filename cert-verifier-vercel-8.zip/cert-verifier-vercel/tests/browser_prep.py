"""Run the page's own JavaScript image clean-up in real Chrome, then OCR the result with Tesseract."""
import sys, base64, subprocess, re
from playwright.sync_api import sync_playwright
S = sys.argv[1]
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    pg.goto("http://127.0.0.1:5066/login"); pg.fill("#u", "admin"); pg.fill("#p", "test-pass-123"); pg.click("button.btn"); pg.wait_for_url("**/")
    pg.goto("http://127.0.0.1:5066/verify/new")
    data = base64.b64encode(open(f"{S}/sample_photo.jpg", "rb").read()).decode()
    url = pg.evaluate("""async (b64)=>{ const bin=atob(b64), u=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
        const L=await window.__loadImage(new Blob([u],{type:'image/jpeg'})); const c=window.__toCanvas(L.im,2400,true); return c.toDataURL('image/png'); }""", data)
    open(f"{S}/js_prep.png", "wb").write(base64.b64decode(url.split(",")[1])); b.close()
out = subprocess.run(["tesseract", f"{S}/js_prep.png", "-", "--psm", "6"], capture_output=True, text=True).stdout
open(f"{S}/ocr_full.txt", "w").write(out)
for pat in ["Receipt Date", "P01/", "100.00|400.00", "UNCERT", "ULR", "Caliper Checker"]:
    for l in out.splitlines():
        if re.search(pat, l): print(repr(l)); break
