"""OCR slips seen on real scans: stray separators, table borders left as '|', typos in parameter names."""
import sys
sys.path.insert(0, "/home/claude/cert-verifier-vercel")
import extract
p1 = """Sample Gauges And Instruments
Laboratory LLP
S. No. 1, Some Colony, Pune - 411052.
CC =2656
ULR : CC265626000017387F
PAGE 1 of 2        CERTIFICATE NO: AB/2026/1010/H-002
CALIBRATION CERTIFICATE
CALIBRATED FOR : Customer Pvt. Ltd.
87/1 & 87/2, Village, Pune 412202
TYPE OF INSTRUMENT : V-Block
RANGE                  Identification        Make       Mfg. Sr. No.
100X90X75              AA/UL/VB/04           Crystal    1485B
Challan No. W.O. No. Receipt Date Calibration Date Due Date Issue Date
P01 1010/H 10/10/2026 12/10/2026 11/10/2027 13/10/2026
Condition of Item : Ok     Calibration Location ; In Lab
Standards / Equipment are traceable
Description   Identification No.   Certificate No.   Traceability | Valid up to
Plain Mandrel _     CGIL/STD/30     P/60/250067     CC-2082_    28/11/2027
CALIBRATION PROCEDURE NO. : CGIL-CP-23
ENVIRONMENTAL CONDITION : Temperature  ; 20.1°C Humidity : 52 %Rh
UNCERTAINTY OF MEASUREMENT : + 3.5 um Symetricity ( At 95.45% Confidence Level i.e. k=2 )"""
p2 = """ULR : CC265626000017387F
PAGE 2of2          CERTIFICATE NO: AB/2026/1010/H-002
CALIBRATION RESULTS
Sr. No.   Parameter   Observed Value (in pm)   |
1   Parallelism of aixs of V Block to base      14    |
2   Parallism of axis of V Blaock to Side       14    |
3   Symmetricity     11
ACCEPTANCE CRITERIA AS PER REFERENCE STANDARD :
| Grade     | Parallism   | Squareness |
0     3 + (L/250 )     :     2+(h1/100)  |
2     12 + (L/50 )     10+(h1/25)"""
d = extract.fields_from_ocr(p1 + "\f" + p2, head_text="Sample Gauges And Instruments\nLaboratory LLP\nS. No. 1, Pune - 411052.\nULR : CC2651")
exp = dict(nabl_no="CC-2656", nabl_symbol="on", lab_location="In Lab", env_temp="20.1", lab_name="Sample Gauges And Instruments Laboratory LLP",
           instr_ident="AA/UL/VB/04", pages_found="1,2", page_total="2", cert_no="AB/2026/1010/H-002")
for k, v in exp.items(): assert d[k] == v, (k, d[k])
assert d["standards"].endswith("CC-2082 | 28/11/2027"), d["standards"]
assert d["results_params"].count("\n") == 2 and d["results_params"].splitlines()[1].endswith("| 14"), d["results_params"]
assert d["acc_formulas"].splitlines()[0] == "Grade | Parallism | Squareness", d["acc_formulas"]
# garbage must never crash the reader
import random
random.seed(3)
for i in range(300):
    t = "\n".join(l for l in (p1 + "\f" + p2).splitlines() if random.random() > .4)
    extract.fields_from_ocr(t, head_text=t[:50])
print("OCR PARSER TESTS PASSED")
