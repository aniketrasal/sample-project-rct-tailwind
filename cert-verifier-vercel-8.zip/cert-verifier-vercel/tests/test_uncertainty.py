import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import extract

CASES = [  # (text, value, unit, conf, k)
 ("UNCERTAINTY OF MEASUREMENT : + 3.5 um Symetricity ( At 95.45% Confidence Level i.e. k=2 )\n+ 3.5 um Parallelism\n+ 4.1 um Squareness\nSee Calibration Results on Next Page(s).", "3.5", "µm", "95.45", "2"),
 ("UNCERTAINTY OF MEASUREMENT : + 3.5 pm Symetricity ( At 95.45% Confidence Level i.e. k=2 )", "3.5", "µm", "95.45", "2"),
 ("UNCERTAINTY OF MEASUREMENT\n: ± 3.5 µm Symetricity ( At 95.45 % Confidence Level i.e. k = 2 )", "3.5", "µm", "95.45", "2"),
 ("UNCERTAINTY OF MEASUREMENT : £ 3,5 jum ( At 9545% Confidence Level i.e. k=2 )", "3.5", "µm", "95.45", "2"),
 ("UNCERTAINTY OF MEASURENENT : t 3.5 ym ( At 95.45% Confidence Level ie. k=2 )", "3.5", "µm", "95.45", "2"),
 ("+ 3.5 um Symetricity ( At 95.45% Confidence Level i.e. k=2 )\n+ 4.1 um Squareness", "3.5", "µm", "95.45", "2"),
 ("UNCERTAINTY OF MEASUREMENT : +/- 16 µm (At 95% Confidence Level k=2)", "16", "µm", "95", "2"),
 ("UNCERTAINTY OF MEASUREMENT : 0.0035 mm (At 95.45% Confidence Level k=2)", "0.0035", "mm", "95.45", "2"),
 ("UNCERTAINTY OF MEASUREMENT : + 4.1 um Squareness\n+ 3.5 um Parallelism ( At 95.45% Confidence Level i.e. k=2 )", "3.5", "µm", "95.45", "2"),
]
bad = 0
for t, v, u, c, k in CASES:
    r = extract.find_uncertainty(t)
    got = (r["unc_value"], r["unc_unit"], r["unc_conf"], r["k_factor"])
    if got != (v, u, c, k):
        bad += 1
        print("FAIL", got, "expected", (v, u, c, k), "|", t[:60])
assert not extract.find_uncertainty("CALIBRATION RESULTS\n1 | 100.00 | 100.002")["unc_value"]
print("uncertainty tests:", len(CASES) - bad, "/", len(CASES))
sys.exit(1 if bad else 0)
