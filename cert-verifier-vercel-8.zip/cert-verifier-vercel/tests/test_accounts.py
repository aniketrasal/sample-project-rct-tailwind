"""First-login set-up (admin/admin -> own username/password -> e-mailed code), forgot password / username."""
import json, os, re, sys, tempfile
sys.path.insert(0, "/home/claude/cert-verifier-vercel")
T = tempfile.mkdtemp()
MAIL = T + "/mail.jsonl"
os.environ.update(SECRET_KEY="k" * 40, CERTV_SQLITE=T + "/t.db", CERTV_MAIL_FILE=MAIL, CERTV_SECURE_COOKIES="0")
import app as A, db, mailer
cl = A.app.test_client()
tok = lambda h: re.search(r'name="_csrf" value="([^"]+)"', h).group(1)
def page(u): return cl.get(u, follow_redirects=True).get_data(as_text=True)
def post(u, **d):
    d["_csrf"] = tok(cl.get("/login").get_data(as_text=True)) if "_csrf" not in d else d["_csrf"]
    return cl.post(u, data=d, follow_redirects=True).get_data(as_text=True)
def mails(): return [json.loads(l) for l in open(MAIL)] if os.path.exists(MAIL) else []
def last_code(): return re.search(r"code is (\d{6})", mails()[-1]["text"]).group(1)
def sql(q, *a): c = db.connect(); r = c.execute(q, a).fetchall(); c.close(); return r

# fresh install: login page tells the owner to use admin/admin; CSRF is enforced on the public forms
h = page("/login"); assert "admin" in h and "First time here" in h
assert cl.post("/login", data={"username": "admin", "password": "admin"}).status_code == 400
assert "Wrong username or password" in post("/login", username="admin", password="nope")
# admin/admin -> forced to the set-up page; the app is locked until it is finished
h = post("/login", username="admin", password="admin"); assert "Create your account" in h, h[:400]
assert "Create your account" in page("/") and "Create your account" in page("/labs") and cl.get("/healthz").status_code == 200
# bad inputs
def setup(**k):
    d = dict(full_name="Aniket Rasal", username="aniket", email="rasalaniket00@gmail.com", password="Strong#Pass1", password2="Strong#Pass1"); d.update(k)
    return post("/setup", **d)
assert "different username than" in setup(username="admin")
assert "not the same" in setup(password2="x" * 9)
assert "harder to guess" in setup(password="password", password2="password")
assert "at least 8" in setup(password="abc", password2="abc")
assert "valid e-mail" in setup(email="nope")
assert "3-30 letters" in setup(username="a b")
assert not mails()
# good set-up sends the code
h = setup(); assert "Check your e-mail" in h and "rasalaniket00@gmail.com" in h
m = mails(); assert len(m) == 1 and m[0]["to"] == "rasalaniket00@gmail.com" and re.search(r"\d{6}", m[0]["text"])
code = last_code()
# wrong code, then the right one
assert "not correct" in post("/setup/verify", code="000000" if code != "000000" else "111111")
h = post("/setup/verify", code=code); assert "Your account is ready" in h or "Calibration certificates" in h, h[:300]
u = sql("SELECT * FROM users")[0]; assert u["username"] == "aniket" and u["email_verified"] == 1 and u["must_setup"] == 0
assert len(mails()) == 2 and "ready" in mails()[1]["subject"]
assert "Calibration certificates" in page("/")
# old admin/admin no longer works; new credentials do (also by e-mail)
cl.get("/logout"); assert "Wrong username or password" in post("/login", username="admin", password="admin")
assert "Calibration certificates" in post("/login", username="aniket", password="Strong#Pass1")
cl.get("/logout"); assert "Calibration certificates" in post("/login", username="RasalAniket00@gmail.com", password="Strong#Pass1")
cl.get("/logout")
# forgot password
n = len(mails())
assert "Choose a new password" in post("/forgot", who="aniket")
assert len(mails()) == n + 1; c1 = last_code()
assert "not correct" in post("/forgot/reset", code="123456" if c1 != "123456" else "654321", password="New#Pass9999", password2="New#Pass9999")
h = post("/forgot/reset", code=c1, password="New#Pass9999", password2="New#Pass9999"); assert "Password changed" in h
assert "Wrong username or password" in post("/login", username="aniket", password="Strong#Pass1")
assert "Calibration certificates" in post("/login", username="aniket", password="New#Pass9999"); cl.get("/logout")
# unknown user -> same answer, no mail
n = len(mails()); assert "Choose a new password" in post("/forgot", who="nobody"); assert len(mails()) == n
# code lockout after 5 wrong tries
post("/forgot", who="aniket")   # cooldown applies -> no new code, old code still valid
import time; db_c = db.connect(); db_c.execute("UPDATE email_codes SET created=created-100"); db_c.commit(); db_c.close()
post("/forgot", who="aniket"); good = last_code()
for _ in range(5): post("/forgot/reset", code="000000", password="Another#Pass1", password2="Another#Pass1")
h = post("/forgot/reset", code=good, password="Another#Pass1", password2="Another#Pass1")
assert "Password changed" not in h and ("Too many wrong attempts" in h or "expired" in h or "not correct" in h), "code must be locked after 5 wrong tries"
assert "Wrong username or password" in post("/login", username="aniket", password="Another#Pass1")
# forgot username
n = len(mails()); assert "we sent the username" in post("/forgot-username", email="rasalaniket00@gmail.com")
assert len(mails()) == n + 1 and "aniket" in mails()[-1]["text"]
n = len(mails()); post("/forgot-username", email="nobody@example.com"); assert len(mails()) == n
# admin adds a user with e-mail, account page changes e-mail with a code
post("/login", username="aniket", password="New#Pass9999")
t = tok(cl.get("/users").get_data(as_text=True))
post("/users", _csrf=t, username="priya", full_name="Priya", password="Priya#Pass12", role="user", email="priya@example.com")
assert sql("SELECT email FROM users WHERE username='priya'")[0]["email"] == "priya@example.com"
t = tok(cl.get("/account").get_data(as_text=True))
post("/account/email", _csrf=t, email="new@example.com"); c2 = last_code()
assert mails()[-1]["to"] == "new@example.com"
post("/account/email/verify", _csrf=t, code=c2)
assert sql("SELECT email FROM users WHERE username='aniket'")[0]["email"] == "new@example.com"
# mail not configured -> clear message and nothing is stored
cl.get("/logout"); os.environ.pop("CERTV_MAIL_FILE")
h = page("/forgot"); assert "not set up" in h
# upgrade path: an old database whose admin has no e-mail goes through the same first-login set-up
import sqlite3
p = T + "/old.db"; os.environ["CERTV_SQLITE"] = p
c = sqlite3.connect(p); c.executescript("create table users(id integer primary key autoincrement, username text unique not null, full_name text not null, pw_hash text not null, role text not null default 'user');"); c.execute("insert into users(username,full_name,pw_hash,role) values('admin','Administrator','old','admin')"); c.commit(); c.close()
db.init_db(A.generate_password_hash("admin"))
r = sqlite3.connect(p).execute("select must_setup,email from users").fetchone(); assert r == (1, ""), r
print("ACCOUNT TESTS PASSED")
