"""Reviewer corrections are logged and exportable."""
import json, os, sys, tempfile, re
sys.path.insert(0, "/home/claude/cert-verifier-vercel")
T = tempfile.mkdtemp()
os.environ.update(SECRET_KEY="k" * 40, CERTV_SQLITE=T + "/t.db", CERTV_SECURE_COOKIES="0")
import app as A, db
from werkzeug.security import generate_password_hash
db.init_db(generate_password_hash('x'))
c = db.connect()
c.execute("UPDATE users SET pw_hash=?, must_setup=0, email='t@x.io' WHERE username='admin'", (generate_password_hash("test-pass-123"),))
c.commit(); c.close()
cl = A.app.test_client()
tok = lambda h: re.search(r'name="_csrf" value="([^"]+)"', h).group(1)
cl.post("/login", data=dict(username="admin", password="test-pass-123", _csrf=tok(cl.get("/login").get_data(as_text=True))))
c = db.connect()
c.insert("verifications", created_at="2026-01-01T00:00:00", created_by="x", status="checked", data_json=json.dumps({"unc_value": "", "cal_date": "01/01/2026"}), ocr_text="UNCERTAINTY ...")
vid = c.execute("SELECT id FROM verifications").fetchone()["id"]; c.commit(); c.close()
page = cl.get(f"/verify/{vid}/edit").get_data(as_text=True)
form = {k: v for k, v in re.findall(r'name="([^"]+)"[^>]*?(?:value="([^"]*)")', page) if k != "_csrf"}
form["_csrf"] = tok(page); form["unc_value"] = "3.5"
r = cl.post(f"/verify/{vid}/edit", data=form)
assert r.status_code in (302, 303), r.status_code
l = cl.get("/learn").get_data(as_text=True)
assert "unc_value" in l and "3.5" in l, l[:500]
j = json.loads(cl.get("/learn/export.json").get_data(as_text=True))
assert j[0]["ocr_text"].startswith("UNCERTAINTY") and any(x["field"] == "unc_value" and x["new_value"] == "3.5" for x in j[0]["corrections"])
print("LEARN TESTS PASSED")
