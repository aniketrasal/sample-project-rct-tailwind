"""Builds a sample certificate (same values as the user's Caliber Gauges certificate) as PDF + a 'phone photo' PNG."""
import sys, subprocess, random
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
pdf = out / "sample_cert.pdf"
c = canvas.Canvas(str(pdf), pagesize=A4); W, H = A4
def T(x, y, s, size=9, bold=False):
    c.setFont("Helvetica-Bold" if bold else "Helvetica", size); c.drawString(x * mm, H - y * mm, s)
c.setFillColorRGB(.7, .8, .93); c.rect(10*mm, H-48*mm, 190*mm, 36*mm, fill=1, stroke=1); c.setFillColorRGB(0, 0, 0)
T(30, 24, "Caliber Gauges And Instruments", 18, True); T(52, 32, "Laboratory LLP", 18, True)
T(18, 40, "S. No. 14/1, Dattadigamber Colony B, Old Warje Jakat Naka, Pune - 411052.", 8.5)
T(18, 45, "+ 91 9422311121  caliberlab@yahoo.co.in   www.caliberlaboratory.co.in", 8.5)
T(160, 40, "CC-2656", 9, True)
T(20, 58, "PAGE  1 of 1", 10, True); T(110, 58, "CERTIFICATE NO :  CGIL/2026/0611/C-004", 10, True); T(118, 52, "ULR : CC265626000010486F", 8)
T(78, 66, "CALIBRATION CERTIFICATE", 14, True)
T(20, 76, "CALIBRATED FOR", 10, True); T(65, 76, ": Fleetguard Filters Pvt. Ltd.", 10, True)
T(70, 81, "87/1 & 87/2, 86, Village Nandur,Daund,Pune, Nandur 412202", 9)
T(20, 90, "TYPE OF INSTRUMENT", 10, True); T(65, 90, ": Vernier Caliper (Digital )", 10, True)
T(20, 100, "RANGE       L.C.       Identification       Make       Mfr. Sr. No.", 8, True)
T(20, 106, "0 To 200 mm   0.01 mm   FFPL\\UL\\LV\\02   Mitutoyo   0006553", 9)
T(20, 114, "Challan No.   W. O. No.   Receipt Date   Calibration Date   Due Date   Issue Date", 8, True)
T(20, 120, "P01/26-27/3811   0611/C   11/06/2026   11/06/2026   10/06/2027   13/06/2026", 9)
T(20, 127, "Condition of Item : Ok            Calibration Location : In Lab", 8.5)
T(20, 134, "Standards / Equipment are traceable to the National Standard", 9, True)
T(20, 139, "Description   Identification No.   Certificate No.   Traceability   Valid up to", 8, True)
T(20, 144, "Caliper Checker   CGIL/STD/02   CGIL/2025/0904/D-003   CC-2656   04/09/2027", 9)
T(20, 154, "CALIBRATION PROCEDURE NO.   : CGIL-CP-04", 10, True)
T(20, 160, "REFERENCE STANDARD   : IS 16491 (I) - 2024", 10, True)
T(20, 166, "ENVIRONMENTAL CONDITION   : Temperature  : 20.1 C   Humidity : 52 %Rh", 10, True)
T(20, 172, "UNCERTAINTY OF MEASUREMENT   : +/- 16 \xb5m  (At 95.45% Confidence Level i.e. k=2 )", 10, True)
T(20, 180, "Mechanical Calibration: Dimension (Basic-Measuring Instrument)", 9)
T(20, 186, "Observed Reading in mm & Error in \xb5m    CALIBRATION RESULTS", 11, True)
T(20, 193, "External Measurement          Internal Measurement          Depth Measurement", 8, True)
rows = [("0.00","0.00","0"),("20.00","19.99","-10"),("50.00","49.99","-10"),("100.00","99.99","-10"),("150.00","149.99","-10"),("200.00","199.99","-10")]
for i, (a, b, e) in enumerate(rows):
    y = 200 + i * 6
    T(22, y, f"{a}     {b}     {e}", 9)
    T(80, y, f"{a if a != '0.00' else '-'}     -     -" if a != "0.00" else "-     -     -", 9)
    T(140, y, "20.00     -     -" if a == "20.00" else "-     -     -", 9)
T(20, 242, "ACCEPTANCE CRITERIA AS PER REFERENCE STANDARD :", 9, True)
T(20, 248, "Range    0-50mm    50-200mm    200-400mm    400-600mm", 9)
T(20, 253, "Max.Permissible Error EMPE    +/-20\xb5m    +/-30\xb5m    +/-40\xb5m    +/-50\xb5m", 9)
T(20, 258, "Max.Permissible Error SMPE    +/-30\xb5m    +/-50\xb5m    +/-60\xb5m    +/-70\xb5m", 9)
T(20, 270, "Calibrated By", 10, True); T(20, 282, "Technical Assistant", 9); T(20, 287, "Atul Sathe", 9)
T(150, 270, "Approved By", 10, True); T(150, 282, "Quality Manager", 9); T(150, 287, "Bhagyashree Raskar", 9)
# a scribbled 'signature'
c.setLineWidth(1.4); c.setStrokeColorRGB(.1, .1, .6)
p = c.beginPath(); p.moveTo(152*mm, H-278*mm)
for k in range(1, 14): p.lineTo((152 + k*3)*mm, H-(278 + (-5 if k % 2 else 1))*mm)
c.drawPath(p, stroke=1, fill=0); c.setStrokeColorRGB(0, 0, 0)
T(20, 293, "1. This certificate pertains only to the items calibrated at CGIL Laboratory.", 7.5)
c.save()
subprocess.run(["pdftoppm", "-r", "150", "-png", "-singlefile", str(pdf), str(out / "flat")], check=True)
import cv2, numpy as np
im = cv2.imread(str(out / "flat.png")); h, w = im.shape[:2]
# 'phone photo': small rotation, shadow gradient, noise, JPEG compression, lower resolution
m = cv2.getRotationMatrix2D((w/2, h/2), 2.2, 1.0); im = cv2.warpAffine(im, m, (w, h), borderValue=(215, 215, 215))
grad = np.tile(np.linspace(0.78, 1.0, w), (h, 1))[:, :, None]; im = (im * grad).astype(np.uint8)
im = np.clip(im + np.random.default_rng(1).normal(0, 6, im.shape), 0, 255).astype(np.uint8)
im = cv2.resize(im, (1170, int(1170 * h / w)))
cv2.imwrite(str(out / "sample_photo.jpg"), im, [cv2.IMWRITE_JPEG_QUALITY, 70])
print("made", list(p.name for p in out.iterdir()))
