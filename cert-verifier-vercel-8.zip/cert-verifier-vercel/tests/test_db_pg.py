"""db.py against real PostgreSQL (via the stand-in driver) and SQLite: same assertions on both."""
import os, sys, tempfile
sys.path.insert(0, "/home/claude/cert-verifier-vercel")
mode = sys.argv[1]
if mode == "pg":
    sys.path.insert(0, "/home/claude/cert-verifier-vercel/tests/fakepsycopg")
    os.environ["DATABASE_URL"] = "postgres://pgtest@127.0.0.1:5433/certv?supa=x&pgbouncer=true"
else:
    os.environ["CERTV_SQLITE"] = tempfile.mkdtemp() + "/t.db"
import db
from werkzeug.security import generate_password_hash
assert db.backend() == ("postgres" if mode == "pg" else "sqlite")
n = db.init_db(generate_password_hash("a")); assert n == 1
assert db.init_db(generate_password_hash("b")) == 1           # idempotent
c = db.connect()
lid = c.insert("labs", name="Lab", nabl_no="CC-2656", valid_from="2024-03-01", valid_to="2027-02-28"); assert isinstance(lid, int)
c.insert("lab_scope", lab_id=lid, instrument_type="Vernier", range_min=0, range_max=300.5, unit="mm", cmc_um=10)
c.upsert("instruments", ["ident"], ident="A\\B", name="x", range_min=0, range_max=200, unit="mm")
c.upsert("instruments", ["ident"], ident="A\\B", name="y", range_min=0, range_max=250, unit="mm")
vid = c.insert("verifications", created_by="O'Brien", created_at="2026-11-09T01:00:00", file_name="c.jpg", data_json='{"a": "µm é"}')
blob = bytes(range(256)) * 3
c.insert  # noqa
c.upsert("verification_files", ["verification_id"], verification_id=vid, mime="image/jpeg", data=blob)
c.upsert("check_results", ["verification_id", "code"], verification_id=vid, code="1", title="t", auto_status="OK", status="OK", reason="r", pending=0, overridden=0)
c.upsert("check_results", ["verification_id", "code"], verification_id=vid, code="1", title="t", auto_status="NOT OK", status="NOT OK", reason="r2", pending=1, overridden=0)
c.insert("change_log", verification_id=vid, ts="t", by_user="u", code="1", old_status="OK", new_status="NOT OK", reason="because")
c.execute("UPDATE verifications SET revision=revision+1, status=CASE WHEN status='final' THEN 'final' ELSE 'checked' END WHERE id=?", (vid,))
c.commit()
v = c.execute("SELECT * FROM verifications WHERE id=?", (vid,)).fetchone()
assert v["id"] == vid and v["created_by"] == "O'Brien" and v["revision"] == 1 and v["status"] == "checked" and "µm é" in v["data_json"], v
f = c.execute("SELECT data, mime FROM verification_files WHERE verification_id=?", (vid,)).fetchone()
assert bytes(f["data"]) == blob and f["mime"] == "image/jpeg"
rows = c.execute("SELECT * FROM check_results WHERE verification_id=?", (vid,)).fetchall()
assert len(rows) == 1 and rows[0]["status"] == "NOT OK" and rows[0]["pending"] == 1
i = c.execute("SELECT * FROM instruments").fetchall(); assert len(i) == 1 and i[0]["range_max"] == 250 and i[0]["ident"] == "A\\B"
s = c.execute("SELECT * FROM lab_scope WHERE lab_id=?", (lid,)).fetchone(); assert s["range_max"] == 300.5
assert c.execute("SELECT COUNT(*) FROM env_limits").fetchone()[0] == 4
e = c.execute("SELECT * FROM env_limits WHERE key=?", ("gdt",)).fetchone(); assert e["temp_nom"] is None
g = c.execute("SELECT result, COUNT(*) FROM verifications WHERE status='checked' GROUP BY result").fetchall(); assert g[0][1] == 1
c.execute("INSERT INTO login_attempts(ip, username, ts) VALUES (?,?,?)", ("1.2.3.4", "x", 1.5e9))
assert c.execute("SELECT COUNT(*) FROM login_attempts WHERE ip=? OR username=?", ("1.2.3.4", "q")).fetchone()[0] == 1
# unique violation + cascade
try:
    c.insert("labs", name="dup", nabl_no="CC-2656"); raise SystemExit("unique not enforced")
except SystemExit: raise
except Exception as ex:
    assert "unique" in str(ex).lower() or "UNIQUE" in str(ex) or "duplicate" in str(ex).lower(), ex
c.rollback()
c.execute("DELETE FROM verifications WHERE id=?", (vid,)); c.commit()
assert c.execute("SELECT COUNT(*) FROM check_results").fetchone()[0] == 0
assert c.execute("SELECT COUNT(*) FROM verification_files").fetchone()[0] == 0
assert c.execute("SELECT COUNT(*) FROM change_log").fetchone()[0] == 0
print(f"db.py OK on {db.backend()}: schema, idempotent init, insert/RETURNING, upsert, BYTEA round-trip, floats, NULLs, unique, cascade")
