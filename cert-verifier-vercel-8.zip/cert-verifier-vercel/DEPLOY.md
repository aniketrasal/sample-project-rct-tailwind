# Put Cert Verifier on Vercel (about 15 minutes)

Vercel does not accept a zip file directly. It deploys from a **GitHub repository** (or the Vercel command line).
Follow these steps in order.

## 1. Put the files on GitHub
1. Unzip `cert-verifier-vercel.zip` on your computer.
2. On github.com: **New repository** -> name it `cert-verifier` -> Private -> Create.
3. Click **uploading an existing file**. Open the unzipped folder and drag **everything inside it** into the page
   (`app.py`, `requirements.txt`, the `templates` folder, ...). Click **Commit changes**.
   **Important:** `app.py` must be at the top level of the repository, not inside another folder.

## 2. Create the Vercel project
1. vercel.com -> **Add New -> Project** -> choose the `cert-verifier` repository -> **Import**.
2. Framework Preset should say **Flask**. Leave everything else as it is. Click **Deploy**.
3. The first deploy shows a page called **Setup needed**. That is normal: the settings are not added yet.

## 3. Add the database (free)
1. In the Vercel project: **Storage -> Create Database -> Neon (Postgres)**.
2. Choose the region closest to you (for India: **Asia Pacific - Mumbai**), accept the free plan,
   and **connect it to the project** for all environments. Vercel adds `DATABASE_URL` for you.

## 4. Add the settings
Project -> **Settings -> Environment Variables**, add:

| Name | Value |
|---|---|
| `SECRET_KEY` | a long random text, e.g. from `python3 -c "import secrets;print(secrets.token_hex(32))"` or any 40+ random characters |
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `587` |
| `SMTP_USER` | your Gmail address, e.g. `yourname@gmail.com` |
| `SMTP_PASSWORD` | a Gmail **App password** (16 letters). Create it at https://myaccount.google.com/apppasswords (2-step verification must be on). Not your normal Gmail password. |
| `ADMIN_EMAIL` | *(recommended)* your e-mail address. Only this address can finish the first-login set-up. |

### E-mail
The app e-mails 6-digit codes (first-login confirmation, forgot password, forgot username).
Use Gmail as above, or any SMTP provider (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, optional `MAIL_FROM`).
Alternative: a free https://resend.com account -> set `RESEND_API_KEY` (and `MAIL_FROM`; without your own domain Resend only delivers to your own address, which is fine for the admin).

## 5. Redeploy
**Deployments -> the latest one -> "..." -> Redeploy.** Open `/healthz` on your site: it should say `"status":"ok"`.

## 6. First login (do this right after deploying)
1. Open your site and sign in with username **admin** and password **admin**.
2. Choose your own name, username, password and e-mail. A 6-digit code is e-mailed to you.
3. Type the code. Done - the app is now yours. `admin/admin` stops working.

Until step 3 is finished, anybody who opens the site could claim the admin account, so do it immediately
(`ADMIN_EMAIL` limits that to your own address).
Forgot your username or password later? Use the links on the sign-in page - the codes go to your e-mail.

## 7. First use
Labs (add the labs you accept, with their NABL validity and scope) -> Instruments (optional) -> Rule 6 limits and Users (admin) -> **Verify**.

---
## How it works on Vercel
* **Reading photos:** done inside the phone/computer browser with a free OCR library (tesseract.js, loaded from the jsDelivr CDN).
  The first photo downloads about 10 MB once, then it is cached. Reading takes 15-40 seconds.
* **Reading PDFs:** PDFs that have selectable text are read on the server. A scanned PDF (picture only): upload a photo of the page instead.
* **Saving:** everything (labs, results, uploaded certificates, change log) is in the Neon Postgres database. Nothing is kept on the Vercel server.
* **Limits:** files up to 4 MB (large photos are shrunk automatically). Neon free plan: 0.5 GB of storage, which is thousands of certificates.
* **Vercel Hobby plan** is meant for personal, non-commercial use. For company use, check Vercel's terms and use a paid plan.

## Problems
| You see | Do this |
|---|---|
| **Setup needed** page | Add the setting it names (step 3 or 4), then Redeploy. |
| **Database not reachable** | Neon database asleep or `DATABASE_URL` wrong. Wait 10 seconds and reload; check Settings -> Environment Variables. |
| Cannot sign in and cannot get an e-mail code | Add `RESET_ADMIN_PASSWORD` = `1`, Redeploy: the admin account goes back to `admin` / `admin` and the first-login set-up (e-mail is cleared). Sign in, finish the set-up, then **delete** that setting. |
| The code e-mail does not arrive | Check `SMTP_*` settings (Gmail needs an App password), look in Spam, and read the red message on the page. |
| Photo is not read / wrong numbers | Take it straight from above in good light. Wrong or missing values are shown in amber on the review page: correct them there. |
| iPhone photo "cannot be opened" | Use the Take photo button, or set Camera -> Formats -> Most Compatible. |
| Any other error | Vercel -> your project -> **Logs**. The page shows a reference code that appears in the log. |
| Build error | Check that `app.py` and `requirements.txt` are at the top level of the repository. |

## Upgrading an existing deployment (V-block fix)
Just redeploy this folder to the same Vercel project. The database upgrades itself on first start
(adds the `grade` column to instruments) - no data is lost.
